package pl.ziomsigiemka.butteros.client.apps;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import pl.ziomsigiemka.butteros.client.App;
import pl.ziomsigiemka.butteros.client.ClientData;
import pl.ziomsigiemka.butteros.client.Photos;
import pl.ziomsigiemka.butteros.client.Ui;

public class CameraApp extends App {
    private String last = null;

    @Override
    protected void render(GuiGraphics g, int mx, int my, float pt) {
        g.fill(x, y, x + w, y + h, 0xFF000000);
        int pw = w - 8, ph = pw * 9 / 16;
        if (ph > h - 40) { ph = h - 40; pw = ph * 16 / 9; }
        int px = x + (w - pw) / 2;
        if (last == null && !ClientData.get().gallery.isEmpty()) last = ClientData.get().gallery.get(0);
        if (last != null) Photos.draw(g, Photos.photo(last), px, y + 4, pw, ph);
        else {
            g.fill(px, y + 4, px + pw, y + 4 + ph, 0xFF1A1A20);
            Ui.center(g, "Kliknij spust, żeby zrobić zdjęcie świata", x + w / 2, y + 4 + ph / 2, 0xFFAAAAAA);
        }
        int cx = x + w / 2, cy = y + h - 18;
        boolean hover = inside(mx, my, cx - 12, cy - 12, 24, 24);
        Ui.round2(g, cx - 12, cy - 12, cx + 12, cy + 12, 0xFFFFFFFF);
        Ui.round2(g, cx - 9, cy - 9, cx + 9, cy + 9, hover ? 0xFFE04040 : 0xFFDDDDDD);
        area("shot", cx - 12, cy - 12, 24, 24);
        Ui.text(g, "Zdjęcia: " + ClientData.get().gallery.size(), x + 6, y + h - 14, 0xFFAAAAAA);
    }

    @Override
    protected void onButton(String id, int button) {
        Photos.capture(Minecraft.getInstance().screen, name -> { if (name != null) last = name; });
    }
}
