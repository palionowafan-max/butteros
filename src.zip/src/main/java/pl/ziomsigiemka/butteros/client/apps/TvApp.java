package pl.ziomsigiemka.butteros.client.apps;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import pl.ziomsigiemka.butteros.client.App;
import pl.ziomsigiemka.butteros.client.Ui;

import java.util.Random;

/** Telewizja: 15 animowanych programów. */
public class TvApp extends App {
    private static final String[] NAMES = {
            "TVB Wiadomości", "Bajka o Guciu", "Sport Plus", "Pogoda TV", "Gotujemy z Kasią",
            "Przyroda", "Muzyka Hit", "Kosmos", "Wyścigi", "Milion Marchewek",
            "Rysowanki", "Bajka o Creeperze", "Taniec Disco", "Zwierzaki", "Kanał Masło"
    };
    private int channel = 1;
    private int osd = 60, noise = 0, ticks = 0;
    private boolean list = false;
    private String typed = "";
    private int typedTimer = 0;
    private GuiGraphics g;
    private float t;

    @Override
    public void tick() {
        ticks++;
        if (osd > 0) osd--;
        if (noise > 0) noise--;
        if (typedTimer > 0 && --typedTimer == 0 && !typed.isEmpty()) {
            setChannel(Integer.parseInt(typed));
            typed = "";
        }
    }

    private void setChannel(int c) {
        if (c < 1 || c > 15) return;
        channel = c;
        osd = 60;
        noise = 6;
        os.sound(SoundEvents.UI_BUTTON_CLICK.value(), 2.0F, 0.3F);
    }

    // wirtualny ekran 160x90
    private void r(float x0, float y0, float x1, float y1, int c) {
        g.fill(x + (int) (x0 * w / 160f), y + (int) (y0 * h / 90f), x + (int) Math.ceil(x1 * w / 160f), y + (int) Math.ceil(y1 * h / 90f), c);
    }

    private void txt(String s, float vx, float vy, int color, boolean center) {
        float scale = Math.max(0.5F, w / 320f);
        int sx = x + (int) (vx * w / 160f), sy = y + (int) (vy * h / 90f);
        Ui.scaledText(g, s, sx, sy, scale, color, center);
    }

    private void circle(float cx, float cy, float rad, int c) {
        for (float yy = -rad; yy <= rad; yy += 0.5f) {
            float half = (float) Math.sqrt(Math.max(0, rad * rad - yy * yy));
            r(cx - half, cy + yy, cx + half, cy + yy + 0.6f, c);
        }
    }

    @Override
    protected void render(GuiGraphics gg, int mx, int my, float pt) {
        this.g = gg;
        this.t = ticks + pt;
        g.fill(x, y, x + w, y + h, 0xFF000000);
        if (noise > 0) {
            Random rnd = new Random(ticks * 31L);
            for (int yy = 0; yy < 90; yy += 2) for (int xx = 0; xx < 160; xx += 2) {
                int v = rnd.nextInt(255);
                r(xx, yy, xx + 2, yy + 2, 0xFF000000 | v << 16 | v << 8 | v);
            }
        } else {
            switch (channel) {
                case 1 -> news();
                case 2 -> gucio();
                case 3 -> sport();
                case 4 -> weather();
                case 5 -> cooking();
                case 6 -> nature();
                case 7 -> music();
                case 8 -> space();
                case 9 -> racing();
                case 10 -> quiz();
                case 11 -> drawing();
                case 12 -> creeper();
                case 13 -> disco();
                case 14 -> animals();
                default -> butter();
            }
            // logo kanału
            txt(String.valueOf(channel), 152, 3, 0xAAFFFFFF, true);
        }
        if (osd > 0 || !typed.isEmpty()) {
            Ui.round(g, x + 6, y + 6, x + 6 + font().width(NAMES[channel - 1]) + 34, y + 22, 0xC0000000);
            Ui.scaledText(g, typed.isEmpty() ? String.valueOf(channel) : typed + "_", x + 16, y + 10, 1.0F, 0xFF55FF55, true);
            Ui.text(g, NAMES[channel - 1], x + 28, y + 10, 0xFFFFFFFF);
        }
        // pilot
        boolean showBar = my > y + h - 26 && my < y + h && mx >= x && mx < x + w;
        if (showBar || list) {
            g.fill(x, y + h - 18, x + w, y + h, 0xC0000000);
            button(g, "prev", x + 4, y + h - 16, 30, 14, "CH-", 0xFF3A3A48, mx, my);
            button(g, "next", x + 36, y + h - 16, 30, 14, "CH+", 0xFF3A3A48, mx, my);
            button(g, "list", x + 68, y + h - 16, 50, 14, "Programy", 0xFFC0392B, mx, my);
            Ui.text(g, "Strzałki / cyfry 1-15", x + 124, y + h - 13, 0xFFAAAAAA);
        } else Ui.text(g, "§7▼ pilot", x + w - 40, y + h - 10, 0xFFFFFFFF);
        if (list) {
            int cols = 3, cw = (w - 20) / cols, ch = 14;
            Ui.round(g, x + 6, y + 6, x + w - 6, y + 12 + ch * 5 + 6, 0xE0101018);
            for (int i = 0; i < 15; i++) {
                int bx = x + 10 + (i % cols) * cw, by = y + 10 + (i / cols) * (ch + 1);
                button(g, "ch" + (i + 1), bx, by, cw - 4, ch, (i + 1) + ". " + NAMES[i], i + 1 == channel ? 0xFFC0392B : 0xFF2E2E38, mx, my);
            }
        }
    }

    @Override
    protected void onButton(String id, int button) {
        switch (id) {
            case "prev" -> setChannel(channel == 1 ? 15 : channel - 1);
            case "next" -> setChannel(channel == 15 ? 1 : channel + 1);
            case "list" -> list = !list;
            default -> { if (id.startsWith("ch")) { setChannel(Integer.parseInt(id.substring(2))); list = false; } }
        }
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (key == 265 || key == 262) { setChannel(channel == 15 ? 1 : channel + 1); return true; }
        if (key == 264 || key == 263) { setChannel(channel == 1 ? 15 : channel - 1); return true; }
        if (key >= 48 && key <= 57) {
            typed += (char) key;
            if (typed.length() >= 2 || Integer.parseInt(typed) > 1) { setChannel(Integer.parseInt(typed)); typed = ""; }
            else typedTimer = 25;
            return true;
        }
        return false;
    }

    // ================================================================= PROGRAMY
    private void ticker(String text, int bg) {
        r(0, 80, 160, 90, bg);
        float scale = Math.max(0.5F, w / 320f);
        int width = (int) (font().width(text) * scale);
        int sx = x + w - (int) ((t * 1.5f * scale) % (width + w));
        g.enableScissor(x, y + (int) (80 * h / 90f), x + w, y + h);
        Ui.scaledText(g, text, sx, y + (int) (82.5f * h / 90f), scale, 0xFFFFFFFF, false);
        g.disableScissor();
    }

    private void person(float cx, float cy, int suit, int skin, int hair, float bob) {
        r(cx - 9, cy + 6 + bob, cx + 9, cy + 26, suit);
        r(cx - 1, cy + 6 + bob, cx + 1, cy + 16, 0xFFFFFFFF);
        r(cx - 6, cy - 6 + bob, cx + 6, cy + 6 + bob, skin);
        r(cx - 6, cy - 8 + bob, cx + 6, cy - 4 + bob, hair);
        boolean blink = (int) (t / 4) % 25 == 0;
        r(cx - 4, cy - 2 + bob, cx - 2, cy + (blink ? -1.5f : 0) + bob, 0xFF202020);
        r(cx + 2, cy - 2 + bob, cx + 4, cy + (blink ? -1.5f : 0) + bob, 0xFF202020);
        float mouth = Math.abs(Mth.sin(t * 0.6f)) * 1.5f;
        r(cx - 2, cy + 3 + bob, cx + 2, cy + 3.5f + mouth + bob, 0xFF8A2A2A);
    }

    private void news() {
        g.fillGradient(x, y, x + w, y + h, 0xFF0A2A6A, 0xFF1A4AAA);
        for (int i = 0; i < 6; i++) r(100 + i * 10, 10, 104 + i * 10, 60, 0x20FFFFFF);
        r(4, 4, 34, 13, 0xFFE03030);
        txt("NA ŻYWO", 19, 6, 0xFFFFFFFF, true);
        person(55, 38, 0xFF22223A, 0xFFE8B898, 0xFF3A2A1A, Mth.sin(t * 0.05f));
        r(20, 60, 100, 80, 0xFF2A3A6A);
        r(20, 60, 100, 62, 0xFF5A7ACA);
        r(110, 20, 154, 55, 0xFF000000);
        r(111, 21, 153, 54, 0xFF3A8EE0);
        circle(132, 40, 7, 0xFF4CD964);
        txt("Gucio", 132, 47, 0xFFFFFFFF, true);
        txt("bohaterem!", 132, 23, 0xFFFFFFFF, true);
        ticker("PILNE: Królik Gucio uratował wioskę przed creeperami • Nowy ButterOS 1.0 już dostępny w sklepie Masło • Jutro słonecznie, 22 stopnie • ", 0xFFB01E1E);
    }

    private void gucio() {
        g.fillGradient(x, y, x + w, y + (int) (55 * h / 90f), 0xFF7EC8FF, 0xFFCFEFFF);
        r(0, 55, 160, 90, 0xFF5DAA3A);
        circle(135, 15, 8, 0xFFFFE860);
        r(20 + (t * 0.2f) % 180 - 20, 12, 45 + (t * 0.2f) % 180 - 20, 18, 0xFFFFFFFF);
        for (int i = 0; i < 5; i++) { r(15 + i * 30, 60, 17 + i * 30, 66, 0xFF2E8B3A); r(13 + i * 30, 66, 19 + i * 30, 68, 0xFFFF8A20); }
        float gx = (t * 0.8f) % 200 - 20;
        float hop = Math.abs(Mth.sin(t * 0.25f)) * 10;
        float gy = 50 - hop;
        r(gx - 7, gy - 6, gx + 7, gy + 4, 0xFFF2F0EA);         // ciało
        r(gx - 7, gy - 6, gx - 1, gy, 0xFFD67A30);              // ruda łata
        r(gx + 3, gy - 2, gx + 7, gy + 2, 0xFF262222);          // czarna łata
        r(gx + 5, gy - 12, gx + 12, gy - 4, 0xFFD67A30);        // głowa
        r(gx + 6, gy - 20, gx + 8, gy - 12, 0xFF262222);        // uszy
        r(gx + 9, gy - 20, gx + 11, gy - 12, 0xFFD67A30);
        r(gx + 6, gy - 14, gx + 10, gy - 11, 0xFF262222);       // czupryna
        r(gx + 10, gy - 9, gx + 11, gy - 8, 0xFF000000);        // oko
        r(gx - 9, gy - 4, gx - 6, gy - 1, 0xFFFFFFFF);          // ogonek
        String[] subs = {"Dawno temu żył sobie królik Gucio...", "Gucio uwielbiał marchewki i skakanie!", "Pewnego dnia znalazł magiczną marchewkę...", "...i wyruszył w wielką przygodę!"};
        String s = subs[(int) (t / 80) % subs.length];
        r(0, 76, 160, 90, 0x90000000);
        txt(s, 80, 80, 0xFFFFFFFF, true);
    }

    private void sport() {
        for (int i = 0; i < 8; i++) r(i * 20, 10, i * 20 + 20, 90, i % 2 == 0 ? 0xFF3A9A3A : 0xFF348A34);
        r(0, 0, 160, 10, 0xFF101018);
        txt("POL 2 : 1 GER   67'", 80, 2, 0xFFFFFFFF, true);
        r(79, 10, 81, 90, 0xFFFFFFFF);
        for (float a = 0; a < 6.28f; a += 0.1f) r(80 + Mth.cos(a) * 12, 50 + Mth.sin(a) * 12, 81 + Mth.cos(a) * 12, 51 + Mth.sin(a) * 12, 0xFFFFFFFF);
        r(0, 35, 8, 65, 0xFFFFFFFF); r(152, 35, 160, 65, 0xFFFFFFFF);
        float bx = 80 + Mth.sin(t * 0.04f) * 60, by = 50 + Mth.sin(t * 0.07f) * 25;
        for (int i = 0; i < 4; i++) {
            float px = 40 + i * 25 + Mth.sin(t * 0.05f + i) * 10, py = 25 + i * 15 + Mth.cos(t * 0.04f + i) * 8;
            r(px - 2, py - 5, px + 2, py + 3, i % 2 == 0 ? 0xFFE03030 : 0xFFF0F0F0);
            r(px - 2, py - 8, px + 2, py - 5, 0xFFE8B898);
        }
        circle(bx, by, 2, 0xFFFFFFFF);
    }

    private void weather() {
        g.fillGradient(x, y, x + w, y + h, 0xFF2A6AC0, 0xFF6AAEF0);
        // mapa
        int land = 0xFF4CAF50;
        r(40, 15, 120, 75, land); r(35, 25, 45, 65, land); r(115, 20, 128, 70, land); r(55, 10, 105, 16, land); r(50, 74, 110, 80, land);
        String[][] cities = {{"Gdańsk", "60", "18", "17"}, {"Warszawa", "90", "40", "21"}, {"Kraków", "85", "68", "23"}, {"Poznań", "55", "38", "20"}, {"Wrocław", "52", "58", "22"}};
        for (int i = 0; i < cities.length; i++) {
            float cx = Float.parseFloat(cities[i][1]), cy = Float.parseFloat(cities[i][2]);
            if (i % 2 == 0) circle(cx, cy - 4, 3 + Mth.sin(t * 0.1f + i) * 0.4f, 0xFFFFD84A);
            else { circle(cx - 2, cy - 4, 3, 0xFFFFFFFF); circle(cx + 2, cy - 4, 3, 0xFFFFFFFF); }
            txt(cities[i][3] + "°", cx, cy, 0xFFFFFFFF, true);
        }
        person(140, 45, 0xFFC0392B, 0xFFE8B898, 0xFFF2C230, 0);
        ticker("Prognoza na jutro: słonecznie w całym kraju • Weekend z deszczem na północy • Uważajcie na creepery w nocy! • ", 0xFF1A4A8A);
    }

    private void cooking() {
        for (int i = 0; i < 16; i++) for (int j = 0; j < 6; j++) r(i * 10, j * 10, i * 10 + 10, j * 10 + 10, (i + j) % 2 == 0 ? 0xFFF0F0F0 : 0xFFD8E8F0);
        r(0, 60, 160, 90, 0xFF8B5E3C);
        r(0, 60, 160, 62, 0xFFA57A50);
        r(55, 45, 105, 70, 0xFF505058);
        r(52, 45, 108, 48, 0xFF707078);
        r(50, 50, 55, 53, 0xFF303030); r(105, 50, 110, 53, 0xFF303030);
        for (int i = 0; i < 6; i++) {
            float bx = 60 + i * 8, by = 45 - ((t * 0.8f + i * 13) % 30);
            circle(bx + Mth.sin(t * 0.1f + i) * 2, by, 2 + i % 2, 0x60FFFFFF);
        }
        r(60, 70, 100, 74, 0xFFE03030);
        person(130, 30, 0xFFFFFFFF, 0xFFE8B898, 0xFF8A4A2A, 0);
        r(124, 18, 136, 24, 0xFFFFFFFF);
        r(0, 76, 160, 90, 0x90000000);
        txt("Dziś gotujemy: zupę marchewkową dla Gucia!", 80, 80, 0xFFFFFFFF, true);
    }

    private void nature() {
        g.fillGradient(x, y, x + w, y + h, 0xFF1A7AB0, 0xFF0A2A5A);
        r(0, 82, 160, 90, 0xFFD8C890);
        for (int i = 0; i < 8; i++) {
            float sx = 10 + i * 20;
            for (int k = 0; k < 6; k++) r(sx + Mth.sin(t * 0.08f + k * 0.5f + i) * 2, 82 - k * 4, sx + 2 + Mth.sin(t * 0.08f + k * 0.5f + i) * 2, 86 - k * 4, 0xFF2E8B3A);
        }
        int[] fishC = {0xFFFF8A20, 0xFFFFE040, 0xFF40D0FF, 0xFFFF5080};
        for (int i = 0; i < 4; i++) {
            float fx = (t * (0.5f + i * 0.2f) + i * 50) % 200 - 20, fy = 20 + i * 14 + Mth.sin(t * 0.05f + i) * 5;
            r(fx - 6, fy - 3, fx + 4, fy + 3, fishC[i]);
            r(fx - 10, fy - 4, fx - 6, fy + 4, fishC[i]);
            r(fx + 1, fy - 1, fx + 2, fy, 0xFF000000);
        }
        for (int i = 0; i < 10; i++) {
            float bx = (i * 37) % 160, by = 90 - (t * 0.6f + i * 20) % 90;
            circle(bx + Mth.sin(t * 0.1f + i) * 2, by, 1, 0x80FFFFFF);
        }
        txt("Przyroda: tajemnice oceanu", 80, 3, 0xFFFFFFFF, true);
    }

    private void music() {
        r(0, 0, 160, 90, 0xFF0A0A14);
        for (int i = 0; i < 20; i++) {
            float hgt = 10 + Math.abs(Mth.sin(t * 0.3f + i * 0.7f) * Mth.cos(t * 0.13f + i)) * 50;
            int c = Ui.mix(0xFFFF3A8A, 0xFF3AD0FF, i / 20f);
            r(8 + i * 7.5f, 75 - hgt, 13 + i * 7.5f, 75, c);
        }
        r(0, 76, 160, 90, 0xFF1A1A2A);
        txt("♫ Teraz gra: Gucio - Marchewkowy Rap", 80, 80, 0xFFFFD84A, true);
        txt("MUZYKA HIT", 80, 4, 0xFFFF3A8A, true);
    }

    private void space() {
        r(0, 0, 160, 90, 0xFF02020A);
        Random rnd = new Random(5);
        for (int i = 0; i < 70; i++) {
            float ax = rnd.nextFloat() * 2 - 1, ay = rnd.nextFloat() * 2 - 1;
            float d = ((t * 0.01f + rnd.nextFloat()) % 1f);
            float sx = 80 + ax * d * 100, sy = 45 + ay * d * 60;
            r(sx, sy, sx + 0.5f + d, sy + 0.5f + d, 0xFFFFFFFF);
        }
        circle(115, 50, 16, 0xFFD08A3A);
        circle(110, 45, 5, 0xFFE0A050);
        r(92, 49, 138, 51, 0xFFE8C88A);
        txt("Kosmos: podróż do Saturna", 80, 80, 0xFFFFFFFF, true);
    }

    private void racing() {
        r(0, 0, 160, 25, 0xFF8AC8FF);
        r(0, 25, 160, 90, 0xFF3A9A3A);
        r(0, 35, 160, 80, 0xFF404048);
        for (int i = 0; i < 10; i++) { float sx = (i * 20 - t * 3) % 200; if (sx < -20) sx += 200; r(sx, 56, sx + 10, 58, 0xFFFFFFFF); }
        int[] cars = {0xFFE03030, 0xFF3060E0, 0xFFF0D020};
        for (int i = 0; i < 3; i++) {
            float cx = (t * (1.0f + i * 0.15f) + i * 40) % 200 - 20, cy = 40 + i * 13;
            r(cx, cy, cx + 18, cy + 7, cars[i]);
            r(cx + 5, cy - 3, cx + 13, cy, cars[i]);
            r(cx + 6, cy - 2, cx + 12, cy, 0xFFAADDFF);
            r(cx + 2, cy + 6, cx + 6, cy + 9, 0xFF101010); r(cx + 12, cy + 6, cx + 16, cy + 9, 0xFF101010);
        }
        txt("Wielkie Wyścigi • okrążenie 3/5", 80, 4, 0xFF202020, true);
    }

    private void quiz() {
        g.fillGradient(x, y, x + w, y + h, 0xFF0A0A40, 0xFF2A1A7A);
        Ui.round(g, x + (int) (10 * w / 160f), y + (int) (10 * h / 90f), x + (int) (150 * w / 160f), y + (int) (32 * h / 90f), 0xFF1A2A8A);
        txt("Co najbardziej lubi jeść królik Gucio?", 80, 18, 0xFFFFFFFF, true);
        String[] ans = {"A: Pizzę", "B: Marchewki", "C: Kamienie", "D: Lody"};
        for (int i = 0; i < 4; i++) {
            float ax = 10 + (i % 2) * 72, ay = 40 + (i / 2) * 18;
            boolean blink = i == 1 && (int) (t / 10) % 2 == 0 && (t % 200) > 120;
            r(ax, ay, ax + 68, ay + 14, blink ? 0xFF2EAE4E : 0xFF1A2A8A);
            txt(ans[i], ax + 34, ay + 4, 0xFFFFD84A, true);
        }
        txt("MILION MARCHEWEK", 80, 80, 0xFFFFD84A, true);
    }

    private void drawing() {
        r(0, 0, 160, 90, 0xFFF8F4E8);
        float p = (t % 300) / 200f;
        float[][] lines = {{50, 60, 110, 60}, {50, 60, 50, 35}, {110, 60, 110, 35}, {50, 35, 80, 15}, {80, 15, 110, 35}, {50, 35, 110, 35}, {72, 60, 72, 45}, {88, 60, 88, 45}, {72, 45, 88, 45}, {95, 40, 105, 40}, {95, 40, 95, 50}, {105, 40, 105, 50}, {95, 50, 105, 50}};
        int total = lines.length;
        for (int i = 0; i < total; i++) {
            float lp = Mth.clamp(p * total - i, 0, 1);
            if (lp <= 0) break;
            float[] l = lines[i];
            int steps = 40;
            for (int s = 0; s <= steps * lp; s++) {
                float px = l[0] + (l[2] - l[0]) * s / steps, py = l[1] + (l[3] - l[1]) * s / steps;
                r(px, py, px + 1.2f, py + 1.2f, 0xFF202020);
            }
        }
        circle(130, 20, 6, p > 1.1f ? 0xFFFFD84A : 0x00000000);
        txt("Rysowanki: rysujemy domek krok po kroku", 80, 80, 0xFF404040, true);
    }

    private void creeper() {
        float cycle = t % 240;
        if (cycle > 200 && cycle < 215) { r(0, 0, 160, 90, 0xFFFFFFFF); txt("BUM!", 80, 40, 0xFFE03030, true); return; }
        r(0, 0, 160, 90, 0xFF6EB8E8);
        r(0, 70, 160, 90, 0xFF5DAA3A);
        float s = cycle > 150 ? 1 + (cycle - 150) / 100f : 1;
        float cx = 80, cy = 40;
        int body = cycle > 150 && (int) (cycle / 4) % 2 == 0 ? 0xFFFFFFFF : 0xFF4CAF50;
        r(cx - 15 * s, cy - 25 * s, cx + 15 * s, cy + 5 * s, body);
        r(cx - 10 * s, cy + 5 * s, cx + 10 * s, cy + 30 * s, body);
        r(cx - 10 * s, cy - 17 * s, cx - 3 * s, cy - 10 * s, 0xFF101010);
        r(cx + 3 * s, cy - 17 * s, cx + 10 * s, cy - 10 * s, 0xFF101010);
        r(cx - 3 * s, cy - 10 * s, cx + 3 * s, cy - 3 * s, 0xFF101010);
        r(cx - 6 * s, cy - 6 * s, cx + 6 * s, cy + 1 * s, 0xFF101010);
        if (cycle > 150) txt("Ssssssss...", 80, 80, 0xFF202020, true);
        else txt("Creeper szuka przyjaciela...", 80, 80, 0xFF202020, true);
    }

    private void disco() {
        int[] cols = {0xFFFF3A8A, 0xFF3AD0FF, 0xFFFFE040, 0xFF4CD964, 0xFFA040FF};
        for (int i = 0; i < 16; i++) for (int j = 0; j < 4; j++)
            r(i * 10, 50 + j * 10, i * 10 + 10, 60 + j * 10, cols[(i + j + (int) (t / 8)) % cols.length]);
        r(0, 0, 160, 50, 0xFF101020);
        circle(80, 10, 6, 0xFFC0C0C0);
        for (int i = 0; i < 5; i++) {
            float dx = 20 + i * 30, bob = Math.abs(Mth.sin(t * 0.3f + i)) * 6;
            r(dx - 1, 30 - bob, dx + 1, 45 - bob, 0xFFFFFFFF);
            circle(dx, 27 - bob, 3, 0xFFFFFFFF);
            float arm = Mth.sin(t * 0.3f + i) * 6;
            r(dx - 6, 33 - bob + arm, dx + 6, 34 - bob - arm, 0xFFFFFFFF);
            r(dx - 4, 45 - bob, dx - 2, 52, 0xFFFFFFFF); r(dx + 2, 45 - bob, dx + 4, 52, 0xFFFFFFFF);
        }
        txt("TANIEC DISCO", 80, 2, cols[(int) (t / 5) % cols.length], true);
    }

    private void animals() {
        boolean dog = (int) (t / 200) % 2 == 1;
        r(0, 0, 160, 90, dog ? 0xFFBFE6A8 : 0xFFF7D9E8);
        int fur = dog ? 0xFFB07A40 : 0xFFE8923A;
        circle(80, 45, 25, fur);
        if (dog) { r(52, 25, 62, 55, 0xFF7A4A20); r(98, 25, 108, 55, 0xFF7A4A20); }
        else { r(58, 15, 68, 30, fur); r(92, 15, 102, 30, fur); }
        boolean blink = (int) (t / 3) % 30 == 0;
        r(68, 38, 74, blink ? 39 : 44, 0xFF202020);
        r(86, 38, 92, blink ? 39 : 44, 0xFF202020);
        circle(80, 52, 3, dog ? 0xFF202020 : 0xFFF08AA0);
        if (dog) r(76, 58 + Mth.sin(t * 0.4f) * 1, 84, 64 + Mth.sin(t * 0.4f) * 2, 0xFFF06080);
        txt(dog ? "Zwierzaki: pies Burek" : "Zwierzaki: kot Filemon", 80, 80, 0xFF404040, true);
    }

    private void butter() {
        g.fillGradient(x, y, x + w, y + h, 0xFFFFF3B0, 0xFFF2C230);
        float bob = Mth.sin(t * 0.1f) * 3;
        r(55, 35 + bob, 105, 60 + bob, 0xFFFFE680);
        r(55, 35 + bob, 105, 39 + bob, 0xFFFFF6C8);
        r(62, 25 + bob, 112, 35 + bob, 0xFFFFEE9A);
        txt("MASŁO", 80, 44 + bob, 0xFFC08A00, true);
        for (int i = 0; i < 6; i++) {
            float a = t * 0.05f + i;
            float sx = 80 + Mth.cos(a) * 45, sy = 45 + Mth.sin(a) * 30;
            r(sx - 1, sy - 3, sx + 1, sy + 3, 0xFFFFFFFF); r(sx - 3, sy - 1, sx + 3, sy + 1, 0xFFFFFFFF);
        }
        txt("Masło - najlepsze do chleba!", 80, 8, 0xFF7A5A00, true);
        txt("Teraz tylko 3,99 zł!", 80, 72, 0xFFE03030, true);
    }
}
