package pl.ziomsigiemka.butteros.client.apps;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.sounds.SoundEvents;
import pl.ziomsigiemka.butteros.client.App;
import pl.ziomsigiemka.butteros.client.ClientData;
import pl.ziomsigiemka.butteros.client.Ui;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Random;

public class SnakeApp extends App {
    private static final int GW = 24, GH = 16;
    private final Deque<int[]> snake = new ArrayDeque<>();
    private int dx = 1, dy = 0, ndx = 1, ndy = 0;
    private int foodX, foodY, score = 0, timer = 0;
    private boolean dead = false, started = false;
    private final Random rnd = new Random();

    @Override
    protected void onOpen() { reset(); }

    private void reset() {
        snake.clear();
        for (int i = 0; i < 4; i++) snake.addLast(new int[]{8 - i, 8});
        dx = 1; dy = 0; ndx = 1; ndy = 0; score = 0; dead = false; started = false;
        food();
    }

    private void food() {
        while (true) {
            foodX = rnd.nextInt(GW);
            foodY = rnd.nextInt(GH);
            boolean on = false;
            for (int[] s : snake) if (s[0] == foodX && s[1] == foodY) on = true;
            if (!on) return;
        }
    }

    @Override
    public void tick() {
        if (!started || dead) return;
        int speed = Math.max(2, 5 - score / 5);
        if (++timer < speed) return;
        timer = 0;
        dx = ndx; dy = ndy;
        int[] head = snake.peekFirst();
        int nx = head[0] + dx, ny = head[1] + dy;
        if (nx < 0 || ny < 0 || nx >= GW || ny >= GH) { die(); return; }
        for (int[] s : snake) if (s[0] == nx && s[1] == ny) { die(); return; }
        snake.addFirst(new int[]{nx, ny});
        if (nx == foodX && ny == foodY) {
            score++;
            os.sound(SoundEvents.GENERIC_EAT, 1.4F, 0.6F);
            food();
        } else snake.removeLast();
    }

    private void die() {
        dead = true;
        os.sound(SoundEvents.VILLAGER_HURT, 1.0F, 0.6F);
        ClientData d = ClientData.get();
        if (score > d.snakeBest) { d.snakeBest = score; d.save(); }
    }

    @Override
    protected void render(GuiGraphics g, int mx, int my, float pt) {
        g.fill(x, y, x + w, y + h, 0xFF14301C);
        int cell = Math.max(2, Math.min((w - 8) / GW, (h - 20) / GH));
        int bx = x + (w - cell * GW) / 2, by = y + 16;
        g.fill(bx - 1, by - 1, bx + cell * GW + 1, by + cell * GH + 1, 0xFF6ACF6A);
        g.fill(bx, by, bx + cell * GW, by + cell * GH, 0xFF0E2414);
        for (int i = 0; i < GW; i++) for (int j = 0; j < GH; j++)
            if ((i + j) % 2 == 0) g.fill(bx + i * cell, by + j * cell, bx + (i + 1) * cell, by + (j + 1) * cell, 0xFF112A18);
        g.fill(bx + foodX * cell + 1, by + foodY * cell + 1, bx + (foodX + 1) * cell - 1, by + (foodY + 1) * cell - 1, 0xFFE03A3A);
        int i = 0;
        for (int[] s : snake) {
            int c = i == 0 ? 0xFF9CFF6A : (i % 2 == 0 ? 0xFF4CD964 : 0xFF3DBA55);
            g.fill(bx + s[0] * cell, by + s[1] * cell, bx + (s[0] + 1) * cell, by + (s[1] + 1) * cell, c);
            i++;
        }
        Ui.text(g, "Wynik: " + score + "   Rekord: " + ClientData.get().snakeBest, x + 4, y + 4, 0xFFFFFFFF);
        if (!started || dead) {
            Ui.round(g, x + w / 2 - 80, y + h / 2 - 16, x + w / 2 + 80, y + h / 2 + 16, 0xE0000000);
            Ui.center(g, dead ? "§cKoniec gry! Wynik: " + score : "§aSnake", x + w / 2, y + h / 2 - 11, 0xFFFFFFFF);
            Ui.center(g, "Strzałki/WASD - start", x + w / 2, y + h / 2 + 3, 0xFFCCCCCC);
        }
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        int ndxN = ndx, ndyN = ndy;
        if (key == 265 || key == 87) { ndxN = 0; ndyN = -1; }
        else if (key == 264 || key == 83) { ndxN = 0; ndyN = 1; }
        else if (key == 263 || key == 65) { ndxN = -1; ndyN = 0; }
        else if (key == 262 || key == 68) { ndxN = 1; ndyN = 0; }
        else return false;
        if (dead) reset();
        started = true;
        if (ndxN != -dx || ndyN != -dy) { ndx = ndxN; ndy = ndyN; }
        return true;
    }
}
