package pl.ziomsigiemka.butteros.client.apps;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.sounds.SoundEvents;
import pl.ziomsigiemka.butteros.client.App;
import pl.ziomsigiemka.butteros.client.ClientData;
import pl.ziomsigiemka.butteros.client.Ui;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/** Flappy Gucio - wirtualny ekran 100x150 (współrzędne gry), skalowany do okna. */
public class FlappyApp extends App {
    private float by = 60, vy = 0;
    private final List<float[]> pipes = new ArrayList<>(); // x, gapY
    private int score = 0, timer = 0;
    private boolean started = false, dead = false;
    private final Random rnd = new Random();
    private float prevBy = 60;

    private void reset() {
        by = prevBy = 60; vy = 0; pipes.clear(); score = 0; timer = 0; dead = false; started = false;
    }

    private void flap() {
        if (dead) { reset(); return; }
        started = true;
        vy = -2.6F;
        os.sound(SoundEvents.RABBIT_JUMP, 1.4F, 0.5F);
    }

    @Override
    public void tick() {
        prevBy = by;
        if (!started || dead) return;
        vy += 0.32F;
        by += vy;
        if (++timer % 38 == 0) pipes.add(new float[]{110, 30 + rnd.nextInt(70)});
        for (float[] p : pipes) {
            float old = p[0];
            p[0] -= 1.6F;
            if (old >= 25 && p[0] < 25) { score++; os.sound(SoundEvents.EXPERIENCE_ORB_PICKUP, 1.5F, 0.4F); }
            if (p[0] < 30 && p[0] > 10 && (by - 4 < p[1] - 18 || by + 4 > p[1] + 18)) die();
        }
        pipes.removeIf(p -> p[0] < -20);
        if (by > 140 || by < 0) die();
    }

    private void die() {
        if (dead) return;
        dead = true;
        os.sound(SoundEvents.VILLAGER_HURT, 1.2F, 0.5F);
        if (score > ClientData.get().flappyBest) { ClientData.get().flappyBest = score; ClientData.get().save(); }
    }

    @Override
    protected void render(GuiGraphics g, int mx, int my, float pt) {
        float s = Math.min(w / 100f, h / 150f);
        int gw = (int) (100 * s), gh = (int) (150 * s), gx = x + (w - gw) / 2, gy = y + (h - gh) / 2;
        g.fill(x, y, x + w, y + h, 0xFF4EC0CA);
        g.fillGradient(gx, gy, gx + gw, gy + gh, 0xFF6EC6FF, 0xFFC8F0FF);
        for (float[] p : pipes) {
            int px = gx + (int) ((p[0] - 10) * s), pw = (int) (20 * s);
            g.fill(px, gy, px + pw, gy + (int) ((p[1] - 18) * s), 0xFF5DBE3A);
            g.fill(px, gy + (int) ((p[1] + 18) * s), px + pw, gy + gh - (int) (10 * s), 0xFF5DBE3A);
            g.fill(px - 2, gy + (int) ((p[1] - 22) * s), px + pw + 2, gy + (int) ((p[1] - 18) * s), 0xFF3E9A2A);
            g.fill(px - 2, gy + (int) ((p[1] + 18) * s), px + pw + 2, gy + (int) ((p[1] + 22) * s), 0xFF3E9A2A);
        }
        g.fill(gx, gy + gh - (int) (10 * s), gx + gw, gy + gh, 0xFFDED895);
        // Gucio
        float b = prevBy + (by - prevBy) * pt;
        int cx = gx + (int) (20 * s), cy = gy + (int) (b * s), u = Math.max(1, (int) (s * 1.5f));
        g.fill(cx - 3 * u, cy - 2 * u, cx + 3 * u, cy + 2 * u, 0xFFF2F0EA);
        g.fill(cx - 3 * u, cy - 2 * u, cx, cy, 0xFFD67A30);
        g.fill(cx + 1 * u, cy - 4 * u, cx + 4 * u, cy, 0xFFD67A30);
        g.fill(cx + 1 * u, cy - 7 * u, cx + 2 * u, cy - 4 * u, 0xFF262222);
        g.fill(cx + 3 * u, cy - 7 * u, cx + 4 * u, cy - 4 * u, 0xFFD67A30);
        g.fill(cx + 3 * u, cy - 3 * u, cx + 4 * u, cy - 2 * u, 0xFF000000);
        Ui.scaledText(g, String.valueOf(score), gx + gw / 2, gy + 8, 2.0F, 0xFFFFFFFF, true);
        if (!started || dead) {
            Ui.round(g, gx + 6, gy + gh / 2 - 22, gx + gw - 6, gy + gh / 2 + 22, 0xD0000000);
            Ui.center(g, dead ? "§cKoniec! Wynik: " + score : "§eFlappy Gucio", gx + gw / 2, gy + gh / 2 - 16, 0xFFFFFFFF);
            Ui.center(g, "Rekord: " + ClientData.get().flappyBest, gx + gw / 2, gy + gh / 2 - 4, 0xFFFFFFFF);
            Ui.center(g, "Kliknij / spacja", gx + gw / 2, gy + gh / 2 + 8, 0xFFAAAAAA);
        }
    }

    @Override
    protected boolean click(double mx, double my, int button) { flap(); return true; }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (key == 32 || key == 265 || key == 87) { flap(); return true; }
        return false;
    }
}
