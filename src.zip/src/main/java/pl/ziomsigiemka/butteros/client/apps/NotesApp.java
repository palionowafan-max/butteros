package pl.ziomsigiemka.butteros.client.apps;

import net.minecraft.client.gui.GuiGraphics;
import pl.ziomsigiemka.butteros.client.App;
import pl.ziomsigiemka.butteros.client.ClientData;
import pl.ziomsigiemka.butteros.client.Ui;

import java.util.ArrayList;
import java.util.List;

public class NotesApp extends App {
    private int open = -1;
    private final Ui.TextInput title = new Ui.TextInput(40, false);
    private final Ui.TextInput body = new Ui.TextInput(4000, true);
    private int scroll = 0;

    private List<ClientData.Note> notes() { return ClientData.get().notes; }

    @Override
    protected void render(GuiGraphics g, int mx, int my, float pt) {
        g.fill(x, y, x + w, y + h, 0xFFFFF8DC);
        if (open < 0) {
            button(g, "new", x + 4, y + 4, 90, 14, "+ Nowa notatka", 0xFFE8B400, mx, my);
            int yy = y + 22 - scroll;
            if (notes().isEmpty()) Ui.center(g, "Brak notatek. Kliknij + Nowa notatka", x + w / 2, y + h / 2, 0xFF8A7A50);
            for (int i = 0; i < notes().size(); i++) {
                ClientData.Note n = notes().get(i);
                if (yy > y + 18 && yy < y + h - 4) {
                    boolean hover = inside(mx, my, x + 4, yy, w - 8, 26);
                    Ui.round(g, x + 4, yy, x + w - 4, yy + 26, hover ? 0xFFFFE9A8 : 0xFFFFF0C0);
                    Ui.text(g, Ui.trim(n.title, w - 40), x + 8, yy + 3, 0xFF3A3020);
                    String first = n.text.replace('\n', ' ');
                    Ui.text(g, Ui.trim(first.isEmpty() ? "(pusta)" : first, w - 40), x + 8, yy + 14, 0xFF8A7A50);
                    area("note" + i, x + 4, yy, w - 30, 26);
                    button(g, "del" + i, x + w - 22, yy + 6, 14, 14, "x", 0xFFD04040, mx, my);
                }
                yy += 30;
            }
        } else {
            button(g, "back", x + 4, y + 4, 40, 14, "< Lista", 0xFFB09020, mx, my);
            title.render(g, x + 48, y + 4, w - 52, 14, "Tytuł");
            area("title", x + 48, y + 4, w - 52, 14);
            Ui.round(g, x + 4, y + 22, x + w - 4, y + h - 4, 0xFFFFFFF0);
            area("body", x + 4, y + 22, w - 8, h - 26);
            // zawijanie tekstu
            List<String> lines = wrap(body.get() + (body.focused && (System.currentTimeMillis() / 500) % 2 == 0 ? "_" : ""), w - 16);
            int maxLines = (h - 30) / 10;
            int start = Math.max(0, lines.size() - maxLines);
            for (int i = start; i < lines.size(); i++) Ui.text(g, lines.get(i), x + 8, y + 26 + (i - start) * 10, 0xFF202020);
            if (body.get().isEmpty() && !body.focused) Ui.text(g, "Kliknij i pisz...", x + 8, y + 26, 0xFFA0A0A0);
        }
    }

    private List<String> wrap(String text, int width) {
        List<String> out = new ArrayList<>();
        for (String para : text.split("\n", -1)) {
            String line = "";
            for (String word : para.split(" ", -1)) {
                String t = line.isEmpty() ? word : line + " " + word;
                if (font().width(t) > width && !line.isEmpty()) { out.add(line); line = word; }
                else line = t;
                while (font().width(line) > width) {
                    String cut = font().plainSubstrByWidth(line, width);
                    out.add(cut);
                    line = line.substring(cut.length());
                }
            }
            out.add(line);
        }
        return out;
    }

    private void saveOpen() {
        if (open >= 0 && open < notes().size()) {
            notes().get(open).title = title.get().isBlank() ? "Bez tytułu" : title.get();
            notes().get(open).text = body.get();
            ClientData.get().save();
        }
    }

    @Override
    protected void onButton(String id, int button) {
        if (id.equals("new")) {
            ClientData.Note n = new ClientData.Note();
            notes().add(0, n);
            ClientData.get().save();
            openNote(0);
        } else if (id.equals("back")) {
            saveOpen();
            open = -1;
        } else if (id.equals("title")) {
            title.focused = true; body.focused = false;
        } else if (id.equals("body")) {
            body.focused = true; title.focused = false;
        } else if (id.startsWith("note")) {
            openNote(Integer.parseInt(id.substring(4)));
        } else if (id.startsWith("del")) {
            notes().remove(Integer.parseInt(id.substring(3)));
            ClientData.get().save();
        }
        os.click();
    }

    private void openNote(int i) {
        open = i;
        title.set(notes().get(i).title);
        body.set(notes().get(i).text);
        body.focused = true;
        title.focused = false;
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double d) {
        scroll = Math.max(0, scroll - (int) (d * 15));
        return true;
    }

    @Override
    public boolean charTyped(char c, int mods) {
        if (open < 0) return false;
        boolean r = title.charTyped(c) || body.charTyped(c);
        saveOpen();
        return r;
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (open < 0) return false;
        boolean r = title.keyPressed(key) || body.keyPressed(key);
        if (title.enterPressed) { title.focused = false; body.focused = true; }
        saveOpen();
        return r;
    }

    @Override
    public void close() { saveOpen(); }
}
