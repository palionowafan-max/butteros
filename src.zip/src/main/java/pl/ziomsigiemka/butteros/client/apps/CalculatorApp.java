package pl.ziomsigiemka.butteros.client.apps;

import net.minecraft.client.gui.GuiGraphics;
import pl.ziomsigiemka.butteros.client.App;
import pl.ziomsigiemka.butteros.client.Ui;

public class CalculatorApp extends App {
    private static final String[][] KEYS = {
            {"C", "±", "%", "÷"}, {"7", "8", "9", "×"}, {"4", "5", "6", "-"}, {"1", "2", "3", "+"}, {"0", ".", "<", "="}
    };
    private String entry = "0";
    private double acc = 0;
    private String op = null;
    private boolean fresh = true;
    private String history = "";

    @Override
    protected void render(GuiGraphics g, int mx, int my, float pt) {
        g.fill(x, y, x + w, y + h, 0xFF1C1C22);
        int dh = Math.max(30, h / 4);
        Ui.text(g, history, x + w - 6 - font().width(history), y + 4, 0xFF8A8A95);
        String shown = entry;
        float scale = 2.0F;
        while (font().width(shown) * scale > w - 12 && scale > 1.0F) scale -= 0.25F;
        Ui.scaledText(g, shown, x + w - 6 - (int) (font().width(shown) * scale), y + dh - (int) (10 * scale), scale, 0xFFFFFFFF, false);

        int bw = (w - 10) / 4, bh = (h - dh - 8) / 5;
        for (int r = 0; r < 5; r++) {
            for (int c = 0; c < 4; c++) {
                String k = KEYS[r][c];
                int color = c == 3 ? 0xFFF29A1E : (r == 0 ? 0xFF6E6E78 : 0xFF3A3A44);
                if (k.equals(op) && fresh) color = 0xFFFFFFFF;
                button(g, k, x + 4 + c * (bw + 1), y + dh + 4 + r * (bh + 1), bw, bh, k, color, mx, my);
            }
        }
    }

    private double value() {
        try { return Double.parseDouble(entry); } catch (Exception e) { return 0; }
    }

    private static String fmt(double d) {
        if (Double.isNaN(d) || Double.isInfinite(d)) return "Błąd";
        if (d == Math.rint(d) && Math.abs(d) < 1e15) return String.valueOf((long) d);
        String s = String.format(java.util.Locale.ROOT, "%.8f", d);
        s = s.replaceAll("0+$", "").replaceAll("\\.$", "");
        return s;
    }

    private void compute() {
        double v = value();
        if (op != null) {
            acc = switch (op) {
                case "+" -> acc + v;
                case "-" -> acc - v;
                case "×" -> acc * v;
                case "÷" -> v == 0 ? Double.NaN : acc / v;
                default -> v;
            };
        } else acc = v;
        entry = fmt(acc);
    }

    private void press(String k) {
        switch (k) {
            case "C" -> { entry = "0"; acc = 0; op = null; fresh = true; history = ""; }
            case "±" -> { if (!entry.equals("0")) entry = entry.startsWith("-") ? entry.substring(1) : "-" + entry; }
            case "%" -> entry = fmt(value() / 100.0);
            case "<" -> { entry = entry.length() > 1 ? entry.substring(0, entry.length() - 1) : "0"; if (entry.equals("-")) entry = "0"; }
            case "+", "-", "×", "÷" -> {
                if (!fresh) compute();
                else acc = value();
                op = k;
                history = fmt(acc) + " " + k;
                fresh = true;
            }
            case "=" -> {
                if (op != null) {
                    history = fmt(acc) + " " + op + " " + entry + " =";
                    compute();
                    op = null;
                    fresh = true;
                }
            }
            case "." -> {
                if (fresh) { entry = "0."; fresh = false; }
                else if (!entry.contains(".")) entry += ".";
            }
            default -> {
                if (fresh || entry.equals("0") || entry.equals("Błąd")) { entry = k; fresh = false; }
                else if (entry.length() < 15) entry += k;
            }
        }
    }

    @Override
    protected void onButton(String id, int button) {
        press(id);
        os.click();
    }

    @Override
    public boolean charTyped(char c, int mods) {
        String s = String.valueOf(c);
        if ("0123456789.+-".contains(s)) { press(s); return true; }
        if (c == '*') { press("×"); return true; }
        if (c == '/') { press("÷"); return true; }
        if (c == '=') { press("="); return true; }
        return false;
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (key == 257 || key == 335) { press("="); return true; }
        if (key == 259) { press("<"); return true; }
        return false;
    }
}
