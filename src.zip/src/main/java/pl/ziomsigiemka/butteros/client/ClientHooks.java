package pl.ziomsigiemka.butteros.client;

import net.minecraft.client.Minecraft;
import pl.ziomsigiemka.butteros.network.OpenDevicePacket;

public class ClientHooks {
    public static void openDevice(OpenDevicePacket pkt) {
        Minecraft.getInstance().setScreen(new ButterScreen(pkt));
    }
}
