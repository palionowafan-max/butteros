package pl.ziomsigiemka.butteros.client;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;

import java.util.ArrayList;
import java.util.List;

/** Bazowa klasa aplikacji ButterOS. Pozycje myszy są w pikselach ekranu GUI. */
public abstract class App {
    protected ButterScreen os;
    protected int x, y, w, h;
    private final List<Btn> btns = new ArrayList<>();

    private record Btn(String id, int x, int y, int w, int h) {}

    public void open(ButterScreen os) {
        this.os = os;
        onOpen();
    }

    protected void onOpen() {}

    /** Wywoływane gdy zamykamy tablet/komputer albo aplikację. */
    public void close() {}

    public final void renderApp(GuiGraphics g, int x, int y, int w, int h, int mx, int my, float pt) {
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
        btns.clear();
        render(g, mx, my, pt);
    }

    protected abstract void render(GuiGraphics g, int mx, int my, float pt);

    public boolean mouseClicked(double mx, double my, int button) {
        for (int i = btns.size() - 1; i >= 0; i--) {
            Btn b = btns.get(i);
            if (mx >= b.x && mx < b.x + b.w && my >= b.y && my < b.y + b.h) {
                onButton(b.id, button);
                return true;
            }
        }
        return click(mx, my, button);
    }

    protected boolean click(double mx, double my, int button) { return false; }
    protected void onButton(String id, int button) {}
    public boolean mouseReleased(double mx, double my, int button) { return false; }
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) { return false; }
    public boolean mouseScrolled(double mx, double my, double delta) { return false; }
    public void mouseMoved(double mx, double my) {}
    public boolean keyPressed(int key, int scan, int mods) { return false; }
    public boolean keyReleased(int key, int scan, int mods) { return false; }
    public boolean charTyped(char c, int mods) { return false; }
    public void tick() {}

    protected Font font() { return Ui.font(); }

    protected boolean inside(double mx, double my, int bx, int by, int bw, int bh) {
        return mx >= bx && mx < bx + bw && my >= by && my < by + bh;
    }

    /** Rysuje przycisk i zapamiętuje go do klikania. */
    protected boolean button(GuiGraphics g, String id, int bx, int by, int bw, int bh, String label, int color, int mx, int my) {
        boolean hover = inside(mx, my, bx, by, bw, bh);
        Ui.round(g, bx, by, bx + bw, by + bh, hover ? Ui.lighten(color, 30) : color);
        g.fill(bx + 1, by + bh - 1, bx + bw - 1, by + bh, Ui.darken(color, 40));
        Ui.center(g, Ui.trim(label, bw - 2), bx + bw / 2, by + (bh - 8) / 2 + 1, 0xFFFFFFFF);
        btns.add(new Btn(id, bx, by, bw, bh));
        return hover;
    }

    /** Niewidzialny obszar do klikania. */
    protected void area(String id, int bx, int by, int bw, int bh) {
        btns.add(new Btn(id, bx, by, bw, bh));
    }
}
