package pl.ziomsigiemka.butteros.client.apps;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.sounds.SoundEvents;
import pl.ziomsigiemka.butteros.client.App;
import pl.ziomsigiemka.butteros.client.Ui;

import java.util.Random;

public class SaperApp extends App {
    private static final int N = 9, MINES = 10;
    private final boolean[][] mine = new boolean[N][N], open = new boolean[N][N], flag = new boolean[N][N];
    private boolean placed = false, lost = false, won = false;
    private long start = 0, end = 0;

    private void reset() {
        for (int i = 0; i < N; i++) for (int j = 0; j < N; j++) { mine[i][j] = open[i][j] = flag[i][j] = false; }
        placed = lost = won = false;
    }

    private void place(int sx, int sy) {
        Random r = new Random();
        int c = 0;
        while (c < MINES) {
            int i = r.nextInt(N), j = r.nextInt(N);
            if (mine[i][j] || (Math.abs(i - sx) <= 1 && Math.abs(j - sy) <= 1)) continue;
            mine[i][j] = true;
            c++;
        }
        placed = true;
        start = System.currentTimeMillis();
    }

    private int around(int i, int j) {
        int c = 0;
        for (int di = -1; di <= 1; di++) for (int dj = -1; dj <= 1; dj++) {
            int a = i + di, b = j + dj;
            if (a >= 0 && b >= 0 && a < N && b < N && mine[a][b]) c++;
        }
        return c;
    }

    private void reveal(int i, int j) {
        if (i < 0 || j < 0 || i >= N || j >= N || open[i][j] || flag[i][j]) return;
        open[i][j] = true;
        if (!mine[i][j] && around(i, j) == 0)
            for (int di = -1; di <= 1; di++) for (int dj = -1; dj <= 1; dj++) reveal(i + di, j + dj);
    }

    private void checkWin() {
        int closed = 0;
        for (int i = 0; i < N; i++) for (int j = 0; j < N; j++) if (!open[i][j]) closed++;
        if (closed == MINES && !lost) { won = true; end = System.currentTimeMillis(); os.sound(SoundEvents.PLAYER_LEVELUP, 1.2F, 0.5F); }
    }

    private static final int[] NUM = {0, 0xFF1976D2, 0xFF388E3C, 0xFFD32F2F, 0xFF7B1FA2, 0xFFFF8F00, 0xFF0097A7, 0xFF424242, 0xFF9E9E9E};

    @Override
    protected void render(GuiGraphics g, int mx, int my, float pt) {
        g.fill(x, y, x + w, y + h, 0xFFC6C6C6);
        int cell = Math.max(8, Math.min((w - 10) / N, (h - 30) / N));
        int bx = x + (w - cell * N) / 2, by = y + 24;
        long secs = placed ? ((won || lost ? end : System.currentTimeMillis()) - start) / 1000 : 0;
        int flags = 0;
        for (boolean[] row : flag) for (boolean f : row) if (f) flags++;
        Ui.text(g, "Miny: " + (MINES - flags), x + 6, y + 8, 0xFFB00000);
        Ui.text(g, "Czas: " + secs + " s", x + w - 60, y + 8, 0xFF202020);
        button(g, "reset", x + w / 2 - 12, y + 4, 24, 16, lost ? "X(" : won ? "B)" : ":)", 0xFFF2C230, mx, my);
        for (int i = 0; i < N; i++) for (int j = 0; j < N; j++) {
            int cx = bx + i * cell, cy = by + j * cell;
            if (open[i][j]) {
                g.fill(cx, cy, cx + cell, cy + cell, mine[i][j] ? 0xFFE04040 : 0xFFE0E0E0);
                Ui.border(g, cx, cy, cx + cell, cy + cell, 0xFFA0A0A0);
                if (mine[i][j]) Ui.center(g, "✸", cx + cell / 2, cy + (cell - 8) / 2, 0xFF000000);
                else { int n = around(i, j); if (n > 0) Ui.center(g, "§l" + n, cx + cell / 2, cy + (cell - 8) / 2, NUM[n]); }
            } else {
                g.fill(cx, cy, cx + cell, cy + cell, 0xFFB8B8B8);
                g.fill(cx, cy, cx + cell - 1, cy + 1, 0xFFFFFFFF); g.fill(cx, cy, cx + 1, cy + cell - 1, 0xFFFFFFFF);
                g.fill(cx + 1, cy + cell - 1, cx + cell, cy + cell, 0xFF7A7A7A); g.fill(cx + cell - 1, cy + 1, cx + cell, cy + cell, 0xFF7A7A7A);
                if (flag[i][j]) Ui.center(g, "⚑", cx + cell / 2, cy + (cell - 8) / 2, 0xFFE00000);
                if (lost && mine[i][j]) Ui.center(g, "✸", cx + cell / 2, cy + (cell - 8) / 2, 0xFF000000);
            }
            area("c" + i + "_" + j, cx, cy, cell, cell);
        }
        if (won) Ui.center(g, "§2Wygrana! Brawo!", x + w / 2, by + cell * N + 3, 0xFFFFFFFF);
        if (lost) Ui.center(g, "§4Bum! Spróbuj jeszcze raz", x + w / 2, by + cell * N + 3, 0xFFFFFFFF);
    }

    @Override
    protected void onButton(String id, int button) {
        if (id.equals("reset")) { reset(); os.click(); return; }
        if (lost || won) return;
        String[] p = id.substring(1).split("_");
        int i = Integer.parseInt(p[0]), j = Integer.parseInt(p[1]);
        if (button == 1) { if (!open[i][j]) flag[i][j] = !flag[i][j]; os.click(); return; }
        if (flag[i][j]) return;
        if (!placed) place(i, j);
        if (mine[i][j]) {
            open[i][j] = true;
            lost = true;
            end = System.currentTimeMillis();
            os.sound(SoundEvents.GENERIC_EXPLODE, 1.2F, 0.4F);
            return;
        }
        reveal(i, j);
        os.click();
        checkWin();
    }
}
