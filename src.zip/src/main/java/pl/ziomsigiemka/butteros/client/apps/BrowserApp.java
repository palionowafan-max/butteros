package pl.ziomsigiemka.butteros.client.apps;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.GameRenderer;
import org.joml.Matrix4f;
import pl.ziomsigiemka.butteros.client.App;
import pl.ziomsigiemka.butteros.client.Ui;

import java.lang.reflect.Method;

/**
 * Prawdziwa przeglądarka - korzysta z moda MCEF (com.cinemamod.mcef), jeśli jest zainstalowany.
 * Używamy refleksji, więc mod działa też bez MCEF (wtedy pokazuje informację).
 */
public class BrowserApp extends App {
    private static final String HOME = "https://www.google.com";
    private Object browser;
    private String error = null;
    private int bw = -1, bh = -1;
    private final Ui.TextInput url = new Ui.TextInput(500, false);
    private boolean mouseDown = false;

    // ------------------------------------------------------------ refleksja
    private static final Object DONE = new Object();

    private static Object call(Object target, String name, Object... args) {
        if (target == null) return null;
        for (Class<?> c = target.getClass(); c != null; c = c.getSuperclass()) {
            for (Method m : c.getMethods()) {
                if (!m.getName().equals(name) || m.getParameterCount() != args.length) continue;
                try {
                    Class<?>[] types = m.getParameterTypes();
                    Object[] conv = new Object[args.length];
                    for (int i = 0; i < args.length; i++) conv[i] = convert(args[i], types[i]);
                    Object res = m.invoke(target, conv);
                    return res == null ? DONE : res;
                } catch (Throwable ignored) {}
            }
        }
        return null;
    }

    private static Object convert(Object v, Class<?> t) {
        if (v instanceof Number n) {
            if (t == int.class || t == Integer.class) return n.intValue();
            if (t == long.class || t == Long.class) return n.longValue();
            if (t == double.class || t == Double.class) return n.doubleValue();
            if (t == float.class || t == Float.class) return n.floatValue();
        }
        return v;
    }

    public static boolean mcefAvailable() {
        try {
            Class<?> c = Class.forName("com.cinemamod.mcef.MCEF");
            Object ok = c.getMethod("isInitialized").invoke(null);
            return ok instanceof Boolean b && b;
        } catch (Throwable t) {
            return false;
        }
    }

    @Override
    protected void onOpen() {
        url.set(HOME);
        try {
            if (!mcefAvailable()) { error = "nomcef"; return; }
            Class<?> c = Class.forName("com.cinemamod.mcef.MCEF");
            browser = c.getMethod("createBrowser", String.class, boolean.class).invoke(null, HOME, false);
            if (browser == null) error = "Nie udało się uruchomić przeglądarki.";
        } catch (Throwable t) {
            error = "Błąd MCEF: " + t.getClass().getSimpleName();
        }
    }

    private double scale() { return Minecraft.getInstance().getWindow().getGuiScale(); }

    private int px(double mx) { return (int) ((mx - x) * scale()); }
    private int py(double my) { return (int) ((my - (y + 18)) * scale()); }

    // ------------------------------------------------------------ rysowanie
    @Override
    protected void render(GuiGraphics g, int mx, int my, float pt) {
        g.fill(x, y, x + w, y + h, 0xFFFFFFFF);
        // pasek adresu
        g.fill(x, y, x + w, y + 18, 0xFFE8EAED);
        button(g, "back", x + 2, y + 2, 14, 14, "<", 0xFF9AA0A6, mx, my);
        button(g, "fwd", x + 17, y + 2, 14, 14, ">", 0xFF9AA0A6, mx, my);
        button(g, "reload", x + 32, y + 2, 14, 14, "↻", 0xFF9AA0A6, mx, my);
        button(g, "home", x + 47, y + 2, 14, 14, "⌂", 0xFF9AA0A6, mx, my);
        if (!url.focused && browser != null) {
            Object u = call(browser, "getURL");
            if (u instanceof String s && !s.isEmpty()) url.set(s);
        }
        url.render(g, x + 64, y + 2, w - 68, 14, "Wpisz adres albo szukaj w Google");
        area("url", x + 64, y + 2, w - 68, 14);

        if (error != null) {
            int cx = x + w / 2, cy = y + h / 2;
            if (error.equals("nomcef")) {
                Ui.center(g, "§lPrzeglądarka potrzebuje moda MCEF", cx, cy - 20, 0xFF202124);
                Ui.center(g, "Pobierz MCEF (Forge 1.20.1) z Modrinth lub CurseForge", cx, cy - 6, 0xFF5F6368);
                Ui.center(g, "i wrzuć go do folderu mods. Przy pierwszym", cx, cy + 6, 0xFF5F6368);
                Ui.center(g, "uruchomieniu MCEF pobiera pliki - poczekaj chwilę.", cx, cy + 18, 0xFF5F6368);
            } else Ui.center(g, error, cx, cy, 0xFFD93025);
            return;
        }
        if (browser == null) return;

        int vw = (int) (w * scale()), vh = (int) ((h - 18) * scale());
        if (vw != bw || vh != bh) {
            bw = vw; bh = vh;
            call(browser, "resize", Math.max(1, vw), Math.max(1, vh));
        }
        Object renderer = call(browser, "getRenderer");
        Object texId = call(renderer, "getTextureID");
        if (!(texId instanceof Integer id) || id == 0) {
            Ui.center(g, "Ładowanie...", x + w / 2, y + h / 2, 0xFF5F6368);
            return;
        }
        RenderSystem.disableDepthTest();
        RenderSystem.setShader(GameRenderer::getPositionTexColorShader);
        RenderSystem.setShaderTexture(0, id);
        Matrix4f m = g.pose().last().pose();
        Tesselator t = Tesselator.getInstance();
        BufferBuilder b = t.getBuilder();
        b.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_TEX_COLOR);
        float x0 = x, y0 = y + 18, x1 = x + w, y1 = y + h;
        b.vertex(m, x0, y1, 0).uv(0, 1).color(255, 255, 255, 255).endVertex();
        b.vertex(m, x1, y1, 0).uv(1, 1).color(255, 255, 255, 255).endVertex();
        b.vertex(m, x1, y0, 0).uv(1, 0).color(255, 255, 255, 255).endVertex();
        b.vertex(m, x0, y0, 0).uv(0, 0).color(255, 255, 255, 255).endVertex();
        t.end();
        RenderSystem.setShaderTexture(0, 0);
        RenderSystem.enableDepthTest();
    }

    private void go(String text) {
        String s = text.trim();
        if (s.isEmpty()) return;
        if (!s.contains("://")) {
            if (s.contains(".") && !s.contains(" ")) s = "https://" + s;
            else s = "https://www.google.com/search?q=" + java.net.URLEncoder.encode(s, java.nio.charset.StandardCharsets.UTF_8);
        }
        call(browser, "loadURL", s);
        url.focused = false;
    }

    @Override
    protected void onButton(String id, int button) {
        switch (id) {
            case "back" -> call(browser, "goBack");
            case "fwd" -> call(browser, "goForward");
            case "reload" -> call(browser, "reload");
            case "home" -> call(browser, "loadURL", HOME);
            case "url" -> url.focused = true;
        }
    }

    // ------------------------------------------------------------ wejście
    private boolean inView(double mx, double my) { return mx >= x && mx < x + w && my >= y + 18 && my < y + h; }

    @Override
    protected boolean click(double mx, double my, int button) {
        if (browser == null || !inView(mx, my)) return false;
        url.focused = false;
        call(browser, "setFocus", true);
        call(browser, "sendMousePress", px(mx), py(my), button);
        mouseDown = true;
        return true;
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        if (browser == null || !mouseDown) return false;
        call(browser, "sendMouseRelease", px(mx), py(my), button);
        mouseDown = false;
        return true;
    }

    @Override
    public void mouseMoved(double mx, double my) {
        if (browser != null && inView(mx, my)) call(browser, "sendMouseMove", px(mx), py(my));
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (browser != null && inView(mx, my)) call(browser, "sendMouseMove", px(mx), py(my));
        return browser != null;
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double delta) {
        if (browser != null && inView(mx, my)) call(browser, "sendMouseWheel", px(mx), py(my), delta, 0);
        return true;
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (url.focused) {
            boolean r = url.keyPressed(key);
            if (url.enterPressed) go(url.get());
            return r;
        }
        if (browser == null || key == 256) return false;
        call(browser, "sendKeyPress", key, (long) scan, mods);
        return true;
    }

    @Override
    public boolean keyReleased(int key, int scan, int mods) {
        if (url.focused || browser == null) return false;
        call(browser, "sendKeyRelease", key, (long) scan, mods);
        return true;
    }

    @Override
    public boolean charTyped(char c, int mods) {
        if (url.focused) return url.charTyped(c);
        if (browser == null) return false;
        call(browser, "sendKeyTyped", c, mods);
        return true;
    }

    @Override
    public void close() {
        if (browser != null) {
            if (call(browser, "close", true) == null) call(browser, "close");
            browser = null;
        }
    }
}
