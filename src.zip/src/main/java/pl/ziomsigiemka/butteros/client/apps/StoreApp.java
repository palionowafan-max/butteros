package pl.ziomsigiemka.butteros.client.apps;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.sounds.SoundEvents;
import pl.ziomsigiemka.butteros.client.App;
import pl.ziomsigiemka.butteros.client.AppRegistry;
import pl.ziomsigiemka.butteros.client.ButterScreen;
import pl.ziomsigiemka.butteros.client.Ui;

import java.util.ArrayList;
import java.util.List;

/** Sklep Masło - pobieranie aplikacji i gier. */
public class StoreApp extends App {
    private int tab = 0; // 0 = wszystko, 1 = gry, 2 = aplikacje
    private String downloading = null;
    private float progress = 0;
    private int scroll = 0;

    private List<AppRegistry.Info> list() {
        List<AppRegistry.Info> out = new ArrayList<>();
        int bit = AppRegistry.bit(os.device);
        for (AppRegistry.Info i : AppRegistry.APPS.values()) {
            if ((i.devices() & bit) == 0 || i.id().equals("store")) continue;
            if (tab == 1 && !i.game()) continue;
            if (tab == 2 && i.game()) continue;
            out.add(i);
        }
        return out;
    }

    @Override
    public void tick() {
        if (downloading != null) {
            AppRegistry.Info info = AppRegistry.APPS.get(downloading);
            progress += 1.5F / Math.max(1, info.sizeMb() / 10F + 1);
            if (progress >= 1) {
                AppRegistry.install(os.device, downloading);
                os.sound(SoundEvents.PLAYER_LEVELUP, 1.6F, 0.4F);
                downloading = null;
                progress = 0;
            }
        }
    }

    @Override
    protected void render(GuiGraphics g, int mx, int my, float pt) {
        g.fill(x, y, x + w, y + h, 0xFFFFFBEA);
        // nagłówek
        g.fillGradient(x, y, x + w, y + 26, 0xFFFFD84A, 0xFFF2B21A);
        Ui.round2(g, x + 4, y + 4, x + 22, y + 22, 0xFFFFF3B0);
        Ui.text(g, "M", x + 10, y + 9, 0xFFC08A00);
        Ui.text(g, "§lSklep Masło", x + 26, y + 5, 0xFF4A3300);
        Ui.text(g, "Najlepsze aplikacje dla ButterOS", x + 26, y + 15, 0xFF7A5A10);
        String[] tabs = {"Wszystko", "Gry", "Aplikacje"};
        int tx = x + 4;
        for (int i = 0; i < 3; i++) {
            int tw = font().width(tabs[i]) + 10;
            button(g, "tab" + i, tx, y + 29, tw, 13, tabs[i], tab == i ? 0xFFC08A00 : 0xFFD8C890, mx, my);
            tx += tw + 3;
        }

        g.enableScissor(x, y + 45, x + w, y + h);
        int yy = y + 46 - scroll;
        for (AppRegistry.Info info : list()) {
            int ih = 34;
            if (yy + ih > y + 45 && yy < y + h) {
                Ui.round(g, x + 4, yy, x + w - 4, yy + ih, 0xFFFFFFFF);
                ButterScreen.drawIcon(g, info, x + 7, yy + 3, 28);
                Ui.text(g, "§l" + info.name(), x + 40, yy + 4, 0xFF222222);
                Ui.text(g, Ui.trim(info.desc(), w - 110), x + 40, yy + 14, 0xFF707070);
                Ui.text(g, (info.game() ? "Gra" : "Aplikacja") + " • " + info.sizeMb() + " MB • ★★★★★", x + 40, yy + 24, 0xFFB08A20);
                boolean inst = AppRegistry.isInstalled(os.device, info.id());
                boolean pre = (info.preinstalled() & AppRegistry.bit(os.device)) != 0;
                int bx = x + w - 62;
                if (info.id().equals(downloading)) {
                    g.fill(bx, yy + 12, bx + 54, yy + 20, 0xFFE0E0E0);
                    g.fill(bx, yy + 12, bx + (int) (54 * progress), yy + 20, 0xFF4CD964);
                    Ui.center(g, (int) (progress * 100) + "%", bx + 27, yy + 24, 0xFF404040);
                } else if (inst) {
                    if (pre) Ui.center(g, "§2Zainstalowana", bx + 27, yy + 13, 0xFFFFFFFF);
                    else {
                        button(g, "open:" + info.id(), bx, yy + 4, 54, 12, "Otwórz", 0xFF3A8EE0, mx, my);
                        button(g, "del:" + info.id(), bx, yy + 18, 54, 12, "Usuń", 0xFFB0B0B0, mx, my);
                    }
                } else {
                    button(g, "get:" + info.id(), bx, yy + 10, 54, 14, "Pobierz", 0xFF2EAE4E, mx, my);
                }
            }
            yy += ih + 4;
        }
        g.disableScissor();
    }

    @Override
    protected void onButton(String id, int button) {
        if (id.startsWith("tab")) { tab = id.charAt(3) - '0'; scroll = 0; }
        else if (id.startsWith("get:")) { if (downloading == null) { downloading = id.substring(4); progress = 0; } }
        else if (id.startsWith("open:")) os.openApp(id.substring(5));
        else if (id.startsWith("del:")) AppRegistry.uninstall(os.device, id.substring(4));
        os.click();
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double d) {
        scroll = Math.max(0, Math.min(scroll - (int) (d * 20), Math.max(0, list().size() * 38 - (h - 50))));
        return true;
    }
}
