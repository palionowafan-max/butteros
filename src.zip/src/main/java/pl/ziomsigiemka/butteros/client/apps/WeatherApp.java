package pl.ziomsigiemka.butteros.client.apps;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import pl.ziomsigiemka.butteros.client.App;
import pl.ziomsigiemka.butteros.client.Ui;
import pl.ziomsigiemka.butteros.network.OpenDevicePacket;

/** Pogoda z gry: teraz + prognoza na cały dzień w grze. */
public class WeatherApp extends App {
    private static final int SUN = 0, RAIN = 1, STORM = 2, NIGHT = 3, CLOUD = 4;

    /** Pogoda za "ticks" ticków od teraz, liczona z liczników pogody serwera. */
    private int weatherAt(OpenDevicePacket p, int ticks) {
        if (p.clearTime > 0) return ticks < p.clearTime ? SUN : CLOUD;
        boolean rain = p.raining ? ticks < p.rainTime : ticks >= p.rainTime;
        boolean thunder = p.thundering ? ticks < p.thunderTime : (ticks >= p.thunderTime && rain);
        if (rain && thunder) return STORM;
        if (rain) return RAIN;
        return SUN;
    }

    private static boolean night(long dayTime) {
        long t = dayTime % 24000L;
        return t > 13000 && t < 23000;
    }

    private static String hour(long dayTime) {
        long t = (dayTime + 6000L) % 24000L;
        return String.format("%02d:00", t / 1000);
    }

    private static String name(int w) {
        return switch (w) {
            case RAIN -> "Deszcz";
            case STORM -> "Burza";
            case CLOUD -> "Zmienna";
            case NIGHT -> "Pogodna noc";
            default -> "Słonecznie";
        };
    }

    private static int temp(int w, long dayTime) {
        int base = night(dayTime) ? 12 : 22;
        return base - (w == RAIN ? 5 : w == STORM ? 7 : w == CLOUD ? 2 : 0);
    }

    private void icon(GuiGraphics g, int w, boolean isNight, int cx, int cy, int s, float time) {
        if (w == SUN || w == CLOUD) {
            if (isNight) {
                Ui.round(g, cx - s, cy - s, cx + s, cy + s, 0xFFEFEFC8);
                Ui.round(g, cx - s / 3, cy - s - 1, cx + s + 1, cy + s / 3, 0xFF1A2A5A);
            } else {
                for (int i = 0; i < 8; i++) {
                    double a = i * Math.PI / 4 + time * 0.02;
                    int rx = cx + (int) (Math.cos(a) * s * 1.5), ry = cy + (int) (Math.sin(a) * s * 1.5);
                    g.fill(rx - 1, ry - 1, rx + 2, ry + 2, 0xFFFFD84A);
                }
                Ui.round(g, cx - s, cy - s, cx + s, cy + s, 0xFFFFC21A);
            }
        }
        if (w == CLOUD || w == RAIN || w == STORM) {
            int c = w == STORM ? 0xFF5A5A6A : 0xFFE8ECF4;
            Ui.round(g, cx - s - 2, cy, cx + s + 4, cy + s, c);
            Ui.round(g, cx - s / 2, cy - s / 2, cx + s / 2 + 2, cy + s / 2, c);
        }
        if (w == RAIN || w == STORM) {
            for (int i = 0; i < 4; i++) {
                int ox = cx - s + i * s / 2 + 1, oy = cy + s + 2 + (int) ((time * 0.5 + i * 3) % 6);
                g.fill(ox, oy, ox + 1, oy + 3, 0xFF5AB0FF);
            }
        }
        if (w == STORM) {
            g.fill(cx, cy + s, cx + 2, cy + s + 4, 0xFFFFE040);
            g.fill(cx - 2, cy + s + 3, cx + 1, cy + s + 7, 0xFFFFE040);
        }
    }

    @Override
    protected void render(GuiGraphics g, int mx, int my, float pt) {
        OpenDevicePacket p = os.weather;
        Minecraft mc = Minecraft.getInstance();
        long now = mc.level != null ? mc.level.getDayTime() : p.dayTime;
        boolean nightNow = night(now);
        int cur = mc.level != null ? (mc.level.isThundering() ? STORM : mc.level.isRaining() ? RAIN : SUN) : weatherAt(p, 0);
        float time = (mc.level != null ? mc.level.getGameTime() : 0) + pt;

        int top = nightNow ? 0xFF0E1A40 : (cur == SUN ? 0xFF3A9AF0 : 0xFF566578);
        int bot = nightNow ? 0xFF2A3A70 : (cur == SUN ? 0xFF9AD4FF : 0xFF8A98AA);
        g.fillGradient(x, y, x + w, y + h, top, bot);

        boolean narrow = w < 200;
        int iconS = Math.max(8, Math.min(w, h) / 10);
        int cx = narrow ? x + w / 2 : x + w / 4;
        int cy = y + 12 + iconS * 2;
        icon(g, cur, nightNow, cx, cy, iconS, time);
        int tx = narrow ? x + w / 2 : x + w / 2 + 10;
        int ty = narrow ? cy + iconS * 3 : y + 14;
        Ui.scaledText(g, temp(cur, now) + "°C", narrow ? tx : tx + 30, ty, 2.5F, 0xFFFFFFFF, narrow);
        Ui.centerShadow(g, (nightNow && cur == SUN ? name(NIGHT) : name(cur)), narrow ? tx : tx + 42, ty + 26, 0xFFFFFF);
        Ui.centerShadow(g, "§7Świat Minecrafta • " + hour(now), narrow ? tx : tx + 42, ty + 38, 0xFFFFFF);

        // prognoza godzinowa na cały dzień
        int slots = narrow ? 4 : 8;
        int stripY = y + h - 62;
        Ui.round(g, x + 4, stripY - 12, x + w - 4, y + h - 4, 0x40000000);
        Ui.text(g, "Prognoza na cały dzień", x + 8, stripY - 9, 0xFFFFFFFF);
        int sw = (w - 8) / slots;
        for (int i = 0; i < slots; i++) {
            int ticks = (i + 1) * (24000 / slots);
            long t = now + ticks;
            int wt = weatherAt(p, ticks);
            int sxx = x + 4 + i * sw + sw / 2;
            Ui.center(g, hour(t), sxx, stripY + 2, 0xFFFFFFFF);
            icon(g, wt, night(t), sxx, stripY + 20, 5, time);
            Ui.center(g, temp(wt, t) + "°", sxx, stripY + 36, 0xFFFFFFFF);
        }
    }
}
