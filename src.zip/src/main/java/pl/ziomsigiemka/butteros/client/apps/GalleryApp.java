package pl.ziomsigiemka.butteros.client.apps;

import net.minecraft.client.gui.GuiGraphics;
import pl.ziomsigiemka.butteros.client.App;
import pl.ziomsigiemka.butteros.client.ClientData;
import pl.ziomsigiemka.butteros.client.Photos;
import pl.ziomsigiemka.butteros.client.Ui;

import java.util.List;

public class GalleryApp extends App {
    private int view = -1, scroll = 0;

    private List<String> pics() { return ClientData.get().gallery; }

    @Override
    protected void render(GuiGraphics g, int mx, int my, float pt) {
        g.fill(x, y, x + w, y + h, 0xFF0E0E12);
        if (view >= 0 && view < pics().size()) {
            int pw = w - 8, ph = pw * 9 / 16;
            if (ph > h - 26) { ph = h - 26; pw = ph * 16 / 9; }
            Photos.draw(g, Photos.photo(pics().get(view)), x + (w - pw) / 2, y + 4, pw, ph);
            button(g, "back", x + 4, y + h - 18, 50, 14, "< Wróć", 0xFF3A3A48, mx, my);
            button(g, "del", x + w - 54, y + h - 18, 50, 14, "Usuń", 0xFFD04040, mx, my);
            Ui.center(g, (view + 1) + " / " + pics().size(), x + w / 2, y + h - 14, 0xFFAAAAAA);
            return;
        }
        if (pics().isEmpty()) {
            Ui.center(g, "Brak zdjęć.", x + w / 2, y + h / 2 - 10, 0xFFAAAAAA);
            Ui.center(g, "Zrób zdjęcie w Kamerze, Instagramie albo narysuj coś w Paint!", x + w / 2, y + h / 2 + 2, 0xFF77777F);
            return;
        }
        int cols = Math.max(2, w / 80);
        int tw = (w - 4) / cols - 4, th = tw * 9 / 16;
        for (int i = 0; i < pics().size(); i++) {
            int tx = x + 4 + (i % cols) * (tw + 4), ty = y + 4 + (i / cols) * (th + 4) - scroll;
            if (ty + th < y || ty > y + h) continue;
            Photos.draw(g, Photos.photo(pics().get(i)), tx, ty, tw, th);
            if (inside(mx, my, tx, ty, tw, th)) Ui.border(g, tx, ty, tx + tw, ty + th, 0xFFFFFFFF);
            area("pic" + i, tx, ty, tw, th);
        }
    }

    @Override
    protected void onButton(String id, int button) {
        if (id.equals("back")) view = -1;
        else if (id.equals("del")) {
            pics().remove(view);
            ClientData.get().save();
            view = -1;
        } else if (id.startsWith("pic")) view = Integer.parseInt(id.substring(3));
        os.click();
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double d) {
        scroll = Math.max(0, scroll - (int) (d * 20));
        return true;
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (view >= 0) {
            if (key == 262 && view < pics().size() - 1) { view++; return true; }
            if (key == 263 && view > 0) { view--; return true; }
        }
        return false;
    }
}
