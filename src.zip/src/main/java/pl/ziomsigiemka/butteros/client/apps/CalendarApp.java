package pl.ziomsigiemka.butteros.client.apps;

import net.minecraft.client.gui.GuiGraphics;
import pl.ziomsigiemka.butteros.client.App;
import pl.ziomsigiemka.butteros.client.Ui;

import java.time.LocalDate;

public class CalendarApp extends App {
    private static final String[] MONTHS = {"Styczeń", "Luty", "Marzec", "Kwiecień", "Maj", "Czerwiec", "Lipiec", "Sierpień", "Wrzesień", "Październik", "Listopad", "Grudzień"};
    private static final String[] DAYS = {"Pn", "Wt", "Śr", "Cz", "Pt", "So", "Nd"};
    private int offset = 0;

    @Override
    protected void render(GuiGraphics g, int mx, int my, float pt) {
        g.fill(x, y, x + w, y + h, 0xFFFFFFFF);
        LocalDate today = LocalDate.now();
        LocalDate first = today.withDayOfMonth(1).plusMonths(offset);
        g.fill(x, y, x + w, y + 20, 0xFFE04848);
        button(g, "prev", x + 4, y + 3, 14, 14, "<", 0xFFB03030, mx, my);
        button(g, "next", x + w - 18, y + 3, 14, 14, ">", 0xFFB03030, mx, my);
        Ui.center(g, "§l" + MONTHS[first.getMonthValue() - 1] + " " + first.getYear(), x + w / 2, y + 6, 0xFFFFFFFF);
        int cw = (w - 8) / 7, ch = Math.max(10, (h - 36) / 7);
        for (int i = 0; i < 7; i++) Ui.center(g, DAYS[i], x + 4 + i * cw + cw / 2, y + 24, i >= 5 ? 0xFFE04848 : 0xFF707070);
        int startCol = first.getDayOfWeek().getValue() - 1;
        int len = first.lengthOfMonth();
        for (int d = 1; d <= len; d++) {
            int idx = startCol + d - 1;
            int cx = x + 4 + (idx % 7) * cw, cy = y + 34 + (idx / 7) * ch;
            boolean isToday = first.withDayOfMonth(d).equals(today);
            if (isToday) Ui.round(g, cx + cw / 2 - 8, cy - 2, cx + cw / 2 + 8, cy + 9, 0xFFE04848);
            Ui.center(g, String.valueOf(d), cx + cw / 2, cy, isToday ? 0xFFFFFFFF : (idx % 7 >= 5 ? 0xFFE04848 : 0xFF222222));
        }
        Ui.center(g, "Dziś: " + today.getDayOfMonth() + " " + MONTHS[today.getMonthValue() - 1].toLowerCase() + " " + today.getYear(), x + w / 2, y + h - 11, 0xFF707070);
    }

    @Override
    protected void onButton(String id, int button) {
        offset += id.equals("prev") ? -1 : 1;
        os.click();
    }
}
