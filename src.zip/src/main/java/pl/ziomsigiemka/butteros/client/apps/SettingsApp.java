package pl.ziomsigiemka.butteros.client.apps;

import net.minecraft.client.gui.GuiGraphics;
import pl.ziomsigiemka.butteros.client.App;
import pl.ziomsigiemka.butteros.client.AppRegistry;
import pl.ziomsigiemka.butteros.client.ButterScreen;
import pl.ziomsigiemka.butteros.client.ClientData;
import pl.ziomsigiemka.butteros.client.Ui;

public class SettingsApp extends App {
    @Override
    protected void render(GuiGraphics g, int mx, int my, float pt) {
        g.fill(x, y, x + w, y + h, 0xFFF0F0F4);
        Ui.text(g, "§lTapeta", x + 8, y + 6, 0xFF222222);
        int n = ButterScreen.WALLPAPERS.length;
        int bw = Math.min(40, (w - 16) / n - 4);
        for (int i = 0; i < n; i++) {
            int bx = x + 8 + i * (bw + 4), by = y + 18;
            g.fillGradient(bx, by, bx + bw, by + 26, ButterScreen.WALLPAPERS[i][0], ButterScreen.WALLPAPERS[i][1]);
            if (ClientData.get().wallpaper == i) Ui.border(g, bx - 1, by - 1, bx + bw + 1, by + 27, 0xFF3D7BFF);
            area("wp" + i, bx, by, bw, 26);
        }
        int yy = y + 54;
        Ui.text(g, "§lO systemie", x + 8, yy, 0xFF222222);
        String dev = os.isPhone() ? "Telefon Butter Phone" : os.isTv() ? "Telewizor Butter TV" : "Komputer Butter PC";
        String[] info = {
                "System: ButterOS 1.0 (Masło Edition)",
                "Urządzenie: " + dev,
                "Aplikacje: " + AppRegistry.installed(os.device).size(),
                "Pamięć: 128 GB (wolne: " + (128 - AppRegistry.installed(os.device).size() * 2) + " GB)",
                os.isPc() ? "Procesor: Butter Core i9 • RAM: 32 GB" : "Bateria: 100%",
        };
        for (int i = 0; i < info.length; i++) Ui.text(g, info[i], x + 12, yy + 12 + i * 11, 0xFF505060);
        button(g, "reset", x + 8, y + h - 20, 130, 14, "Przywróć aplikacje", 0xFFD04040, mx, my);
    }

    @Override
    protected void onButton(String id, int button) {
        if (id.startsWith("wp")) {
            ClientData.get().wallpaper = Integer.parseInt(id.substring(2));
            ClientData.get().save();
        } else if (id.equals("reset")) {
            ClientData.get().installed.remove(AppRegistry.key(os.device));
            ClientData.get().save();
        }
        os.click();
    }
}
