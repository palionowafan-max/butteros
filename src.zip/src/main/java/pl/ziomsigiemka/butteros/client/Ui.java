package pl.ziomsigiemka.butteros.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.item.ItemStack;

/** Pomocnicze rysowanie. */
public class Ui {
    public static Font font() { return Minecraft.getInstance().font; }

    public static void round(GuiGraphics g, int x1, int y1, int x2, int y2, int c) {
        if (x2 - x1 < 3 || y2 - y1 < 3) { g.fill(x1, y1, x2, y2, c); return; }
        g.fill(x1 + 1, y1, x2 - 1, y1 + 1, c);
        g.fill(x1, y1 + 1, x2, y2 - 1, c);
        g.fill(x1 + 1, y2 - 1, x2 - 1, y2, c);
    }

    public static void round2(GuiGraphics g, int x1, int y1, int x2, int y2, int c) {
        if (x2 - x1 < 5 || y2 - y1 < 5) { round(g, x1, y1, x2, y2, c); return; }
        g.fill(x1 + 2, y1, x2 - 2, y1 + 1, c);
        g.fill(x1 + 1, y1 + 1, x2 - 1, y1 + 2, c);
        g.fill(x1, y1 + 2, x2, y2 - 2, c);
        g.fill(x1 + 1, y2 - 2, x2 - 1, y2 - 1, c);
        g.fill(x1 + 2, y2 - 1, x2 - 2, y2, c);
    }

    public static void border(GuiGraphics g, int x1, int y1, int x2, int y2, int c) {
        g.fill(x1, y1, x2, y1 + 1, c);
        g.fill(x1, y2 - 1, x2, y2, c);
        g.fill(x1, y1, x1 + 1, y2, c);
        g.fill(x2 - 1, y1, x2, y2, c);
    }

    public static int lighten(int c, int amount) {
        int a = (c >>> 24) & 255, r = Math.min(255, ((c >> 16) & 255) + amount),
                gr = Math.min(255, ((c >> 8) & 255) + amount), b = Math.min(255, (c & 255) + amount);
        return (a << 24) | (r << 16) | (gr << 8) | b;
    }

    public static int darken(int c, int amount) {
        int a = (c >>> 24) & 255, r = Math.max(0, ((c >> 16) & 255) - amount),
                gr = Math.max(0, ((c >> 8) & 255) - amount), b = Math.max(0, (c & 255) - amount);
        return (a << 24) | (r << 16) | (gr << 8) | b;
    }

    public static int mix(int a, int b, float t) {
        t = Math.max(0, Math.min(1, t));
        int ar = (a >> 16) & 255, ag = (a >> 8) & 255, ab = a & 255;
        int br = (b >> 16) & 255, bg = (b >> 8) & 255, bb = b & 255;
        return 0xFF000000 | ((int) (ar + (br - ar) * t) << 16) | ((int) (ag + (bg - ag) * t) << 8) | (int) (ab + (bb - ab) * t);
    }

    public static void text(GuiGraphics g, String s, int x, int y, int color) {
        g.drawString(font(), s, x, y, color, false);
    }

    public static void textShadow(GuiGraphics g, String s, int x, int y, int color) {
        g.drawString(font(), s, x, y, color, true);
    }

    public static void center(GuiGraphics g, String s, int cx, int y, int color) {
        g.drawString(font(), s, cx - font().width(s) / 2, y, color, false);
    }

    public static void centerShadow(GuiGraphics g, String s, int cx, int y, int color) {
        g.drawCenteredString(font(), s, cx, y, color);
    }

    public static void scaledText(GuiGraphics g, String s, int x, int y, float scale, int color, boolean centered) {
        g.pose().pushPose();
        g.pose().translate(x, y, 0);
        g.pose().scale(scale, scale, 1);
        int w = font().width(s);
        g.drawString(font(), s, centered ? -w / 2 : 0, 0, color, true);
        g.pose().popPose();
    }

    public static void item(GuiGraphics g, ItemStack stack, int x, int y, float scale) {
        g.pose().pushPose();
        g.pose().translate(x, y, 0);
        g.pose().scale(scale, scale, 1);
        g.renderItem(stack, 0, 0);
        g.pose().popPose();
    }

    public static String trim(String s, int width) {
        if (font().width(s) <= width) return s;
        return font().plainSubstrByWidth(s, width - font().width("..")) + "..";
    }

    /** Kontrolka do wpisywania tekstu. */
    public static class TextInput {
        public final StringBuilder sb = new StringBuilder();
        public boolean focused = false;
        public final int max;
        public final boolean multiline;

        public TextInput(int max, boolean multiline) { this.max = max; this.multiline = multiline; }

        public String get() { return sb.toString(); }
        public void set(String s) { sb.setLength(0); sb.append(s == null ? "" : s); }

        public boolean charTyped(char c) {
            if (!focused || c < 32 || c == 127) return false;
            if (sb.length() < max) sb.append(c);
            return true;
        }

        /** Zwraca true jeśli klawisz został obsłużony. Enter w polu jednoliniowym zwraca też true (sprawdź enterPressed). */
        public boolean enterPressed = false;

        public boolean keyPressed(int key) {
            enterPressed = false;
            if (!focused) return false;
            if (key == 259) { if (sb.length() > 0) sb.deleteCharAt(sb.length() - 1); return true; }   // backspace
            if (key == 257 || key == 335) {                                                         // enter
                if (multiline) { if (sb.length() < max) sb.append('\n'); }
                else enterPressed = true;
                return true;
            }
            return key != 256; // ESC przepuszczamy
        }

        public void render(GuiGraphics g, int x, int y, int w, int h, String placeholder) {
            Ui.round(g, x, y, x + w, y + h, focused ? 0xFFFFFFFF : 0xFFE6E6EA);
            Ui.border(g, x, y, x + w, y + h, focused ? 0xFF3D7BFF : 0xFFB0B0BA);
            String s = get();
            boolean blink = (System.currentTimeMillis() / 500) % 2 == 0;
            if (s.isEmpty() && !focused) {
                Ui.text(g, Ui.trim(placeholder, w - 6), x + 3, y + (h - 8) / 2, 0xFF8A8A95);
            } else {
                String shown = s;
                while (font().width(shown + "_") > w - 6 && shown.length() > 0) shown = shown.substring(1);
                Ui.text(g, shown + (focused && blink ? "_" : ""), x + 3, y + (h - 8) / 2, 0xFF202028);
            }
        }

        public boolean hit(double mx, double my, int x, int y, int w, int h) {
            return mx >= x && mx < x + w && my >= y && my < y + h;
        }
    }
}
