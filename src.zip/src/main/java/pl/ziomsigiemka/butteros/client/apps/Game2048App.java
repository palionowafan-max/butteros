package pl.ziomsigiemka.butteros.client.apps;

import net.minecraft.client.gui.GuiGraphics;
import pl.ziomsigiemka.butteros.client.App;
import pl.ziomsigiemka.butteros.client.ClientData;
import pl.ziomsigiemka.butteros.client.Ui;

import java.util.Random;

public class Game2048App extends App {
    private final int[][] b = new int[4][4];
    private int score = 0;
    private boolean over = false;
    private final Random rnd = new Random();

    @Override
    protected void onOpen() { reset(); }

    private void reset() {
        for (int[] row : b) java.util.Arrays.fill(row, 0);
        score = 0; over = false;
        spawn(); spawn();
    }

    private void spawn() {
        int empty = 0;
        for (int[] row : b) for (int v : row) if (v == 0) empty++;
        if (empty == 0) return;
        int k = rnd.nextInt(empty);
        for (int i = 0; i < 4; i++) for (int j = 0; j < 4; j++) if (b[i][j] == 0 && k-- == 0) b[i][j] = rnd.nextInt(10) == 0 ? 4 : 2;
    }

    /** Przesuwa w lewo wiersz (po obrotach), zwraca czy coś się zmieniło. */
    private boolean slideLeft() {
        boolean moved = false;
        for (int i = 0; i < 4; i++) {
            int[] row = new int[4];
            int p = 0;
            int last = 0;
            for (int j = 0; j < 4; j++) {
                int v = b[i][j];
                if (v == 0) continue;
                if (last == v) { row[p - 1] = v * 2; score += v * 2; last = 0; }
                else { row[p++] = v; last = v; }
            }
            for (int j = 0; j < 4; j++) { if (b[i][j] != row[j]) moved = true; b[i][j] = row[j]; }
        }
        return moved;
    }

    private void rotate() {
        int[][] t = new int[4][4];
        for (int i = 0; i < 4; i++) for (int j = 0; j < 4; j++) t[j][3 - i] = b[i][j];
        for (int i = 0; i < 4; i++) b[i] = t[i];
    }

    private void move(int dir) { // 0 lewo, 1 dół, 2 prawo, 3 góra
        if (over) { reset(); return; }
        for (int i = 0; i < dir; i++) rotate();
        boolean moved = slideLeft();
        for (int i = 0; i < (4 - dir) % 4; i++) rotate();
        if (moved) { spawn(); os.click(); }
        if (score > ClientData.get().best2048) { ClientData.get().best2048 = score; ClientData.get().save(); }
        over = !canMove();
    }

    private boolean canMove() {
        for (int i = 0; i < 4; i++) for (int j = 0; j < 4; j++) {
            if (b[i][j] == 0) return true;
            if (j < 3 && b[i][j] == b[i][j + 1]) return true;
            if (i < 3 && b[i][j] == b[i + 1][j]) return true;
        }
        return false;
    }

    private static int color(int v) {
        return switch (v) {
            case 0 -> 0xFFCDC1B4; case 2 -> 0xFFEEE4DA; case 4 -> 0xFFEDE0C8; case 8 -> 0xFFF2B179; case 16 -> 0xFFF59563;
            case 32 -> 0xFFF67C5F; case 64 -> 0xFFF65E3B; case 128 -> 0xFFEDCF72; case 256 -> 0xFFEDCC61; case 512 -> 0xFFEDC850;
            case 1024 -> 0xFFEDC53F; case 2048 -> 0xFFEDC22E; default -> 0xFF3C3A32;
        };
    }

    @Override
    protected void render(GuiGraphics g, int mx, int my, float pt) {
        g.fill(x, y, x + w, y + h, 0xFFFAF8EF);
        Ui.text(g, "§lWynik: " + score, x + 6, y + 5, 0xFF776E65);
        Ui.text(g, "Rekord: " + ClientData.get().best2048, x + w - 80, y + 5, 0xFF776E65);
        int size = Math.min(w - 12, h - 26), cell = (size - 10) / 4;
        int bx = x + (w - size) / 2, by = y + 18;
        Ui.round(g, bx, by, bx + size, by + size, 0xFFBBADA0);
        for (int i = 0; i < 4; i++) for (int j = 0; j < 4; j++) {
            int cx = bx + 2 + j * (cell + 2), cy = by + 2 + i * (cell + 2);
            int v = b[i][j];
            Ui.round(g, cx, cy, cx + cell, cy + cell, color(v));
            if (v > 0) {
                float s = Math.max(0.6F, Math.min(2.0F, cell / 18f)) * (v >= 1000 ? 0.7F : v >= 100 ? 0.85F : 1F);
                Ui.scaledText(g, String.valueOf(v), cx + cell / 2, cy + cell / 2 - (int) (4 * s), s, v <= 4 ? 0xFF776E65 : 0xFFFFFFFF, true);
            }
        }
        if (over) {
            g.fill(bx, by, bx + size, by + size, 0xA0FAF8EF);
            Ui.center(g, "§lKoniec gry!", x + w / 2, by + size / 2 - 8, 0xFF776E65);
            Ui.center(g, "Naciśnij strzałkę - od nowa", x + w / 2, by + size / 2 + 4, 0xFF776E65);
        }
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (key == 263 || key == 65) { move(0); return true; }
        if (key == 264 || key == 83) { move(1); return true; }
        if (key == 262 || key == 68) { move(2); return true; }
        if (key == 265 || key == 87) { move(3); return true; }
        return false;
    }
}
