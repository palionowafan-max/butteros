package pl.ziomsigiemka.butteros.client.apps;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.sounds.SoundEvents;
import pl.ziomsigiemka.butteros.client.App;
import pl.ziomsigiemka.butteros.client.Ui;

/** Odtwarzacz muzyki grający na dźwiękach bloku nutowego. */
public class MusicApp extends App {
    // nuty bloku nutowego: 0 = F#3, 6 = C4, 8 = D4, 10 = E4, 11 = F4, 13 = G4, 15 = A4, 17 = H4, 18 = C5; -1 = pauza
    private record Song(String title, String artist, int[] notes, int tempo) {}

    private static final Song[] SONGS = {
            new Song("Panie Janie", "Tradycyjna", new int[]{
                    6, 8, 10, 6, 6, 8, 10, 6, 10, 11, 13, -1, 10, 11, 13, -1,
                    13, 15, 13, 11, 10, 6, 13, 15, 13, 11, 10, 6, 6, 1, 6, -1, 6, 1, 6, -1}, 5),
            new Song("Wlazł kotek na płotek", "Tradycyjna", new int[]{
                    13, 10, 10, 11, 8, 8, 6, 10, 13, -1, 13, 10, 10, 11, 8, 8, 6, 10, 6, -1}, 6),
            new Song("Oda do radości", "L. van Beethoven", new int[]{
                    10, 10, 11, 13, 13, 11, 10, 8, 6, 6, 8, 10, 10, 8, 8, -1,
                    10, 10, 11, 13, 13, 11, 10, 8, 6, 6, 8, 10, 8, 6, 6, -1}, 5),
            new Song("Mrugaj gwiazdko", "Tradycyjna", new int[]{
                    6, 6, 13, 13, 15, 15, 13, -1, 11, 11, 10, 10, 8, 8, 6, -1,
                    13, 13, 11, 11, 10, 10, 8, -1, 13, 13, 11, 11, 10, 10, 8, -1,
                    6, 6, 13, 13, 15, 15, 13, -1, 11, 11, 10, 10, 8, 8, 6, -1}, 5),
    };

    private int song = 0, pos = 0, timer = 0;
    private boolean playing = false;
    private final float[] bars = new float[16];

    @Override
    public void tick() {
        for (int i = 0; i < bars.length; i++) bars[i] *= 0.85F;
        if (!playing) return;
        Song s = SONGS[song];
        if (++timer < s.tempo) return;
        timer = 0;
        int n = s.notes[pos];
        if (n >= 0) {
            float pitch = (float) Math.pow(2, (n - 12) / 12.0);
            os.sound(SoundEvents.NOTE_BLOCK_HARP.value(), pitch, 0.9F);
            os.sound(SoundEvents.NOTE_BLOCK_BASS.value(), pitch, 0.35F);
            bars[n % bars.length] = 1F;
            bars[(n * 7) % bars.length] = Math.max(bars[(n * 7) % bars.length], 0.7F);
        }
        pos++;
        if (pos >= s.notes.length) { pos = 0; song = (song + 1) % SONGS.length; }
    }

    @Override
    protected void render(GuiGraphics g, int mx, int my, float pt) {
        g.fillGradient(x, y, x + w, y + h, 0xFF2A0A4A, 0xFF0A0A1A);
        Song s = SONGS[song];
        int cover = Math.min(w / 3, h / 2 - 10);
        int cx = x + w / 2;
        g.fillGradient(cx - cover / 2, y + 8, cx + cover / 2, y + 8 + cover, 0xFF9B3AE0, 0xFFE03A8A);
        Ui.scaledText(g, "♫", cx, y + 8 + cover / 2 - cover / 6, cover / 30f, 0xFFFFFFFF, true);
        int ty = y + 14 + cover;
        Ui.center(g, "§l" + s.title, cx, ty, 0xFFFFFFFF);
        Ui.center(g, s.artist, cx, ty + 11, 0xFFB0A0C0);
        int pbw = w - 40;
        g.fill(x + 20, ty + 24, x + 20 + pbw, ty + 26, 0xFF404050);
        g.fill(x + 20, ty + 24, x + 20 + pbw * pos / s.notes.length, ty + 26, 0xFFE03A8A);
        int by = ty + 32;
        button(g, "prev", cx - 52, by, 30, 16, "<<", 0xFF4A3A6A, mx, my);
        button(g, "play", cx - 18, by, 36, 16, playing ? "||" : "▶", 0xFFE03A8A, mx, my);
        button(g, "next", cx + 22, by, 30, 16, ">>", 0xFF4A3A6A, mx, my);
        int bw = (w - 20) / bars.length;
        for (int i = 0; i < bars.length; i++) {
            int bh = (int) (bars[i] * (y + h - by - 26));
            g.fill(x + 10 + i * bw, y + h - 4 - bh, x + 10 + i * bw + bw - 1, y + h - 4, Ui.mix(0xFF9B3AE0, 0xFF3AD0FF, i / (float) bars.length));
        }
    }

    @Override
    protected void onButton(String id, int button) {
        switch (id) {
            case "play" -> playing = !playing;
            case "next" -> { song = (song + 1) % SONGS.length; pos = 0; }
            case "prev" -> { song = (song + SONGS.length - 1) % SONGS.length; pos = 0; }
        }
        os.click();
    }
}
