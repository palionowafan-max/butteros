package pl.ziomsigiemka.butteros.client.apps;

import com.mojang.blaze3d.platform.NativeImage;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import pl.ziomsigiemka.butteros.ButterOSMod;
import pl.ziomsigiemka.butteros.client.App;
import pl.ziomsigiemka.butteros.client.Ui;

import java.util.HashSet;
import java.util.Random;
import java.util.Set;

/** Mini Minecraft 3D - własny silnik 3D (raycasting), kopanie i stawianie bloków. */
public class MinecraftApp extends App {
    private static final int SX = 40, SY = 26, SZ = 40;
    private static final String[] NAMES = {"", "Trawa", "Ziemia", "Kamień", "Drewno", "Liście", "Deski", "Piasek", "Bruk", "Cegły"};
    private static final int[] HOTBAR = {6, 8, 9, 4, 2, 3, 7, 5, 1};
    private final byte[] world = new byte[SX * SY * SZ];
    private final int[][] tex = new int[10 * 3][]; // [blok*3 + strona(0 góra,1 bok,2 dół)] -> 8x8

    private double px = 20.5, py = 20, pz = 20.5, vy = 0;
    private float yaw = 0.6F, pitch = 0.25F;
    private boolean onGround = false, dragged = false;
    private int slot = 0;
    private final Set<Integer> keys = new HashSet<>();

    private NativeImage image;
    private DynamicTexture texture;
    private ResourceLocation rl;
    private int rw, rh;
    private int[] target = null; // x,y,z,nx,ny,nz

    // ------------------------------------------------------------ świat
    @Override
    protected void onOpen() {
        Random r = new Random(1234);
        for (int x = 0; x < SX; x++) for (int z = 0; z < SZ; z++) {
            int hgt = (int) (9 + 3 * Math.sin(x * 0.22) + 2 * Math.cos(z * 0.27) + 2 * Math.sin((x + z) * 0.13));
            for (int y = 0; y <= hgt; y++) {
                int b = y < hgt - 3 ? 3 : (y < hgt ? 2 : (hgt <= 8 ? 7 : 1));
                set(x, y, z, b);
            }
        }
        for (int i = 0; i < 14; i++) {
            int tx = 3 + r.nextInt(SX - 6), tz = 3 + r.nextInt(SZ - 6), ty = top(tx, tz) + 1;
            if (get(tx, ty - 1, tz) != 1) continue;
            int th = 4 + r.nextInt(2);
            for (int y = 0; y < th; y++) set(tx, ty + y, tz, 4);
            for (int dx = -2; dx <= 2; dx++) for (int dz = -2; dz <= 2; dz++) for (int dy = th - 2; dy <= th; dy++) {
                if (Math.abs(dx) == 2 && Math.abs(dz) == 2) continue;
                if (dy == th && (Math.abs(dx) == 2 || Math.abs(dz) == 2)) continue;
                if (get(tx + dx, ty + dy, tz + dz) == 0) set(tx + dx, ty + dy, tz + dz, 5);
            }
        }
        // mały domek
        int hx = 26, hz = 14, hy = top(hx, hz) + 1;
        for (int x = 0; x < 5; x++) for (int z = 0; z < 5; z++) for (int y = 0; y < 4; y++) {
            boolean wall = x == 0 || x == 4 || z == 0 || z == 4;
            set(hx + x, hy + y, hz + z, y == 3 ? 6 : (wall ? (y == 1 && (x == 2 || z == 2) ? 0 : 8) : 0));
        }
        set(hx + 2, hy, hz, 0); set(hx + 2, hy + 1, hz, 0);
        py = top((int) px, (int) pz) + 1;
        makeTextures();
    }

    private int idx(int x, int y, int z) { return (y * SZ + z) * SX + x; }
    private int get(int x, int y, int z) {
        if (x < 0 || z < 0 || x >= SX || z >= SZ || y < 0) return 3;
        if (y >= SY) return 0;
        return world[idx(x, y, z)];
    }
    private void set(int x, int y, int z, int b) { if (x >= 0 && y >= 0 && z >= 0 && x < SX && y < SY && z < SZ) world[idx(x, y, z)] = (byte) b; }
    private int top(int x, int z) { for (int y = SY - 1; y >= 0; y--) if (get(x, y, z) != 0) return y; return 0; }

    private void makeTextures() {
        Random r = new Random(7);
        for (int b = 1; b <= 9; b++) for (int s = 0; s < 3; s++) {
            int[] t = new int[64];
            for (int i = 0; i < 64; i++) {
                int x = i % 8, y = i / 8, n = r.nextInt(24) - 12, c;
                switch (b) {
                    case 1 -> c = s == 0 ? rgb(95 + n, 170 + n, 60 + n) : s == 2 ? rgb(134 + n, 96 + n, 67 + n) : (y < 2 || (y == 2 && r.nextBoolean()) ? rgb(95 + n, 170 + n, 60 + n) : rgb(134 + n, 96 + n, 67 + n));
                    case 2 -> c = rgb(134 + n, 96 + n, 67 + n);
                    case 3 -> c = rgb(125 + n, 125 + n, 125 + n);
                    case 4 -> c = s == 1 ? (x % 3 == 0 ? rgb(80 + n / 2, 60, 36) : rgb(110 + n, 84 + n, 50 + n)) : ((Math.abs(x - 3.5) + Math.abs(y - 3.5)) % 3 < 1 ? rgb(120, 90, 55) : rgb(170 + n, 135 + n, 85 + n));
                    case 5 -> c = r.nextInt(5) == 0 ? rgb(30, 80, 25) : rgb(55 + n, 125 + n, 40 + n);
                    case 6 -> c = y % 4 == 3 ? rgb(120, 90, 50) : rgb(176 + n / 2, 140 + n / 2, 88 + n / 2);
                    case 7 -> c = rgb(220 + n / 2, 205 + n / 2, 150 + n / 2);
                    case 8 -> c = (x % 4 == 0 || y % 3 == 0) ? rgb(90 + n, 90 + n, 90 + n) : rgb(140 + n, 140 + n, 140 + n);
                    default -> c = (y % 3 == 2 || (x + (y / 3 % 2) * 4) % 8 == 0) ? rgb(200, 190, 180) : rgb(160 + n, 70 + n / 2, 55 + n / 2);
                }
                t[i] = c;
            }
            tex[b * 3 + s] = t;
        }
    }

    private static int rgb(int r, int g, int b) {
        return (Math.max(0, Math.min(255, r)) << 16) | (Math.max(0, Math.min(255, g)) << 8) | Math.max(0, Math.min(255, b));
    }

    // ------------------------------------------------------------ fizyka
    private boolean collides(double x, double y, double z) {
        for (int bx = (int) Math.floor(x - 0.3); bx <= (int) Math.floor(x + 0.3); bx++)
            for (int by = (int) Math.floor(y); by <= (int) Math.floor(y + 1.79); by++)
                for (int bz = (int) Math.floor(z - 0.3); bz <= (int) Math.floor(z + 0.3); bz++)
                    if (get(bx, by, bz) != 0) return true;
        return false;
    }

    @Override
    public void tick() {
        if (world.length == 0) return;
        if (keys.contains(263)) yaw -= 0.08F;
        if (keys.contains(262)) yaw += 0.08F;
        if (keys.contains(265)) pitch = Math.max(-1.5F, pitch - 0.06F);
        if (keys.contains(264)) pitch = Math.min(1.5F, pitch + 0.06F);
        double fwd = 0, side = 0;
        if (keys.contains(87)) fwd += 1;
        if (keys.contains(83)) fwd -= 1;
        if (keys.contains(65)) side += 1;
        if (keys.contains(68)) side -= 1;
        double speed = keys.contains(341) ? 0.28 : 0.18;
        double len = Math.sqrt(fwd * fwd + side * side);
        if (len > 0) { fwd /= len; side /= len; }
        double fx = -Math.sin(yaw), fz = Math.cos(yaw);
        double rx = -fz, rz = fx;
        double mx = (fx * fwd - rx * side) * speed, mz = (fz * fwd - rz * side) * speed;
        if (!collides(px + mx, py, pz)) px += mx;
        if (!collides(px, py, pz + mz)) pz += mz;
        if (keys.contains(32) && onGround) vy = 0.42;
        vy = (vy - 0.08) * 0.98;
        if (!collides(px, py + vy, pz)) { py += vy; onGround = false; }
        else { if (vy < 0) onGround = true; vy = 0; }
        if (py < -5) { py = top((int) px, (int) pz) + 2; vy = 0; }
    }

    // ------------------------------------------------------------ raycasting
    /** Zwraca: [odległość, blok, ściana(0x,1y,2z), krokZnak, bx, by, bz] w tablicy hit. */
    private final double[] hit = new double[7];

    private boolean cast(double ox, double oy, double oz, double dx, double dy, double dz, double max) {
        int ix = (int) Math.floor(ox), iy = (int) Math.floor(oy), iz = (int) Math.floor(oz);
        int stepX = dx > 0 ? 1 : -1, stepY = dy > 0 ? 1 : -1, stepZ = dz > 0 ? 1 : -1;
        double tdx = dx == 0 ? 1e30 : Math.abs(1 / dx), tdy = dy == 0 ? 1e30 : Math.abs(1 / dy), tdz = dz == 0 ? 1e30 : Math.abs(1 / dz);
        double tmx = dx == 0 ? 1e30 : (dx > 0 ? (ix + 1 - ox) : (ox - ix)) * tdx;
        double tmy = dy == 0 ? 1e30 : (dy > 0 ? (iy + 1 - oy) : (oy - iy)) * tdy;
        double tmz = dz == 0 ? 1e30 : (dz > 0 ? (iz + 1 - oz) : (oz - iz)) * tdz;
        double t = 0;
        int face = 0, sign = 0;
        while (t < max) {
            if (tmx < tmy && tmx < tmz) { ix += stepX; t = tmx; tmx += tdx; face = 0; sign = stepX; }
            else if (tmy < tmz) { iy += stepY; t = tmy; tmy += tdy; face = 1; sign = stepY; }
            else { iz += stepZ; t = tmz; tmz += tdz; face = 2; sign = stepZ; }
            if (iy >= SY && dy > 0) return false;
            if (ix < -1 || iz < -1 || ix > SX || iz > SZ) return false;
            int b = (ix < 0 || iz < 0 || ix >= SX || iz >= SZ) ? 0 : get(ix, iy, iz);
            if (b != 0) {
                hit[0] = t; hit[1] = b; hit[2] = face; hit[3] = sign; hit[4] = ix; hit[5] = iy; hit[6] = iz;
                return true;
            }
        }
        return false;
    }

    private void renderView() {
        double eye = py + 1.6;
        double cp = Math.cos(pitch);
        double fx = -Math.sin(yaw) * cp, fy = -Math.sin(pitch), fz = Math.cos(yaw) * cp;
        double rx = -fz, rz = fx, rl2 = Math.sqrt(rx * rx + rz * rz);
        rx /= rl2; rz /= rl2;
        double ux = -rz * fy, uy = rz * fx - rx * fz, uz = rx * fy;
        double tanF = Math.tan(Math.toRadians(35)), aspect = rw / (double) rh;

        // cel (środek ekranu)
        target = null;
        if (cast(px, eye, pz, fx, fy, fz, 5)) {
            int face = (int) hit[2], sign = (int) hit[3];
            target = new int[]{(int) hit[4], (int) hit[5], (int) hit[6], face == 0 ? -sign : 0, face == 1 ? -sign : 0, face == 2 ? -sign : 0};
        }

        for (int j = 0; j < rh; j++) {
            double sy = (j + 0.5) / rh * 2 - 1;
            for (int i = 0; i < rw; i++) {
                double sx = (i + 0.5) / rw * 2 - 1;
                double dx = fx + rx * sx * tanF * aspect - ux * sy * tanF;
                double dy = fy - uy * sy * tanF;
                double dz = fz + rz * sx * tanF * aspect - uz * sy * tanF;
                double inv = 1 / Math.sqrt(dx * dx + dy * dy + dz * dz);
                dx *= inv; dy *= inv; dz *= inv;
                int sky = dy > 0 ? rgb((int) (120 - dy * 60), (int) (175 - dy * 60), 255) : rgb(170, 205, 255);
                int col = sky;
                if (cast(px, eye, pz, dx, dy, dz, 34)) {
                    double t = hit[0];
                    int face = (int) hit[2], sign = (int) hit[3], b = (int) hit[1];
                    double hx = px + dx * t, hy = eye + dy * t, hz = pz + dz * t;
                    double u, v;
                    int side;
                    if (face == 1) { u = hx - Math.floor(hx); v = hz - Math.floor(hz); side = sign > 0 ? 2 : 0; }
                    else if (face == 0) { u = hz - Math.floor(hz); v = 1 - (hy - Math.floor(hy)); side = 1; }
                    else { u = hx - Math.floor(hx); v = 1 - (hy - Math.floor(hy)); side = 1; }
                    int tc = tex[b * 3 + side][Math.min(7, (int) (v * 8)) * 8 + Math.min(7, (int) (u * 8))];
                    double shade = face == 1 ? (sign > 0 ? 0.5 : 1.0) : (face == 0 ? 0.8 : 0.65);
                    int r = (int) (((tc >> 16) & 255) * shade), g = (int) (((tc >> 8) & 255) * shade), bl = (int) ((tc & 255) * shade);
                    if (target != null && (int) hit[4] == target[0] && (int) hit[5] == target[1] && (int) hit[6] == target[2]
                            && (u < 0.05 || u > 0.95 || v < 0.05 || v > 0.95)) { r = g = bl = 20; }
                    double fog = Math.max(0, Math.min(1, (t - 14) / 18));
                    r = (int) (r + (((sky >> 16) & 255) - r) * fog);
                    g = (int) (g + (((sky >> 8) & 255) - g) * fog);
                    bl = (int) (bl + ((sky & 255) - bl) * fog);
                    col = rgb(r, g, bl);
                }
                image.setPixelRGBA(i, j, 0xFF000000 | ((col & 255) << 16) | (col & 0xFF00) | ((col >> 16) & 255));
            }
        }
        texture.upload();
    }

    @Override
    protected void render(GuiGraphics g, int mx, int my, float pt) {
        int nw = Math.max(64, Math.min(200, w / 2)), nh = Math.max(36, nw * h / Math.max(1, w));
        if (image == null || nw != rw || nh != rh) {
            if (texture != null) texture.close();
            rw = nw; rh = nh;
            image = new NativeImage(rw, rh, false);
            texture = new DynamicTexture(image);
            rl = new ResourceLocation(ButterOSMod.MODID, "dyn/minecraft_view");
            Minecraft.getInstance().getTextureManager().register(rl, texture);
        }
        renderView();
        g.blit(rl, x, y, w, h, 0, 0, rw, rh, rw, rh);

        // celownik
        int cx = x + w / 2, cy = y + h / 2;
        g.fill(cx - 4, cy, cx + 5, cy + 1, 0xFFFFFFFF);
        g.fill(cx, cy - 4, cx + 1, cy + 5, 0xFFFFFFFF);

        // pasek bloków
        int cell = Math.max(12, Math.min(18, w / 12));
        int hbx = x + w / 2 - cell * 9 / 2, hby = y + h - cell - 4;
        g.fill(hbx - 1, hby - 1, hbx + cell * 9 + 1, hby + cell + 1, 0x90000000);
        for (int i = 0; i < 9; i++) {
            int b = HOTBAR[i];
            int bx = hbx + i * cell;
            int c = tex[b * 3 + (b == 1 ? 1 : 0)][27];
            g.fill(bx + 2, hby + 2, bx + cell - 2, hby + cell - 2, 0xFF000000 | c);
            g.fill(bx + 2, hby + 2, bx + cell - 2, hby + 4, 0xFF000000 | tex[b * 3][9]);
            if (i == slot) Ui.border(g, bx, hby, bx + cell, hby + cell, 0xFFFFFFFF);
        }
        Ui.textShadow(g, NAMES[HOTBAR[slot]], x + w / 2 - font().width(NAMES[HOTBAR[slot]]) / 2, hby - 11, 0xFFFFFFFF);
        Ui.textShadow(g, "WASD ruch • spacja skok • przeciągnij myszą = rozglądanie", x + 3, y + 3, 0xFFE0E0E0);
        Ui.textShadow(g, "LPM kop • PPM stawiaj • 1-9 bloki", x + 3, y + 13, 0xFFE0E0E0);
    }

    // ------------------------------------------------------------ wejście
    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        dragged = false;
        return true;
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (Math.abs(dx) + Math.abs(dy) > 0.5) dragged = true;
        yaw += (float) dx * 0.012F;
        pitch = Math.max(-1.5F, Math.min(1.5F, pitch + (float) dy * 0.012F));
        return true;
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        if (!dragged && target != null && inside(mx, my, x, y, w, h)) {
            if (button == 0) {
                set(target[0], target[1], target[2], 0);
                os.sound(SoundEvents.GRAVEL_BREAK, 1.0F, 0.6F);
            } else if (button == 1) {
                int nx = target[0] + target[3], ny = target[1] + target[4], nz = target[2] + target[5];
                set(nx, ny, nz, HOTBAR[slot]);
                if (collides(px, py, pz)) set(nx, ny, nz, 0);
                else os.sound(SoundEvents.WOOD_PLACE, 1.0F, 0.6F);
            }
        }
        dragged = false;
        return true;
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double d) {
        slot = Math.floorMod(slot - (int) Math.signum(d), 9);
        return true;
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (key >= 49 && key <= 57) { slot = key - 49; return true; }
        if (key == 256) return false;
        keys.add(key);
        return true;
    }

    @Override
    public boolean keyReleased(int key, int scan, int mods) {
        keys.remove(key);
        return true;
    }

    @Override
    public void close() {
        if (texture != null) {
            Minecraft.getInstance().getTextureManager().release(rl);
            texture = null;
        }
    }
}
