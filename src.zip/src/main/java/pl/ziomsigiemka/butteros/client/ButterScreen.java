package pl.ziomsigiemka.butteros.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import pl.ziomsigiemka.butteros.client.apps.MusicApp;
import pl.ziomsigiemka.butteros.network.OpenDevicePacket;

import java.time.LocalTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Ekran ButterOS dla komputera, telefonu i telewizora. */
public class ButterScreen extends Screen {
    public static final int[][] WALLPAPERS = {
            {0xFF2B1A4E, 0xFF0F4C75}, {0xFFF2A03A, 0xFFE0573A}, {0xFF1E8C5A, 0xFF0B3D2E},
            {0xFF3A6EE0, 0xFF8AC4FF}, {0xFF202028, 0xFF4A4A5A}, {0xFFE04890, 0xFF6A2AC0}
    };

    public final int device;
    public final OpenDevicePacket weather;
    private App current;
    private String currentId;
    private final Map<String, App> apps = new HashMap<>();
    private int boot = 18;
    private int sx, sy, sw, sh;      // ekran urządzenia
    private int ax, ay, aw, ah;      // obszar aplikacji
    private int homeScroll = 0;

    public ButterScreen(OpenDevicePacket pkt) {
        super(Component.literal("ButterOS"));
        this.device = pkt.device;
        this.weather = pkt;
    }

    public boolean isPhone() { return device == OpenDevicePacket.PHONE; }
    public boolean isTv() { return device == OpenDevicePacket.TV; }
    public boolean isPc() { return device == OpenDevicePacket.PC; }

    @Override
    protected void init() {
        if (isPhone()) {
            sh = height - 36;
            sw = sh * 9 / 19;
            sx = (width - sw) / 2;
            sy = 18;
        } else {
            int maxW = width - (isTv() ? 60 : 50);
            int maxH = height - (isTv() ? 60 : 70);
            sw = Math.min(maxW, maxH * 16 / 9);
            sh = sw * 9 / 16;
            sx = (width - sw) / 2;
            sy = (height - sh) / 2 - (isTv() ? 6 : 10);
        }
        int top = isPhone() ? 10 : 0;
        int bottom = isPc() ? 14 : (isPhone() ? 8 : 0);
        ax = sx;
        ay = sy + top + 12;
        aw = sw;
        ah = sh - top - bottom - 12;
    }

    // ------------------------------------------------------------ aplikacje
    public void openApp(String id) {
        AppRegistry.Info info = AppRegistry.APPS.get(id);
        if (info == null) return;
        App app = apps.get(id);
        if (app == null) {
            app = info.factory().get();
            apps.put(id, app);
            app.open(this);
        }
        current = app;
        currentId = id;
        click();
    }

    public void goHome() {
        current = null;
        currentId = null;
    }

    /** Zamyka aplikację całkowicie (np. przeglądarkę). */
    public void closeApp() {
        if (current != null) {
            current.close();
            apps.remove(currentId);
        }
        goHome();
        click();
    }

    public void click() {
        if (minecraft != null) minecraft.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.UI_BUTTON_CLICK.value(), 1.6F, 0.4F));
    }

    public void sound(net.minecraft.sounds.SoundEvent s, float pitch, float volume) {
        if (minecraft != null) minecraft.getSoundManager().play(SimpleSoundInstance.forUI(s, pitch, volume));
    }

    @Override
    public void removed() {
        for (App a : apps.values()) a.close();
        apps.clear();
        super.removed();
    }

    @Override
    public void tick() {
        if (boot > 0) {
            boot--;
            if (boot == 0) sound(SoundEvents.NOTE_BLOCK_CHIME.value(), 1.2F, 0.6F);
        }
        if (current != null) current.tick();
        for (App a : apps.values()) if (a != current && a instanceof MusicApp m) m.tick();
    }

    // ------------------------------------------------------------ rysowanie
    public static String clock() {
        LocalTime t = LocalTime.now();
        return String.format("%02d:%02d", t.getHour(), t.getMinute());
    }

    private void drawFrame(GuiGraphics g) {
        if (isPhone()) {
            Ui.round2(g, sx - 7, sy - 14, sx + sw + 7, sy + sh + 14, 0xFF0A0A0E);
            Ui.round2(g, sx - 5, sy - 12, sx + sw + 5, sy + sh + 12, 0xFF2A2A33);
            g.fill(sx + sw / 2 - 10, sy - 8, sx + sw / 2 + 10, sy - 6, 0xFF111116);    // głośnik
            g.fill(sx + sw / 2 - 12, sy + sh + 5, sx + sw / 2 + 12, sy + sh + 7, 0xFF55555F);
            g.fill(sx + sw + 5, sy + 30, sx + sw + 7, sy + 50, 0xFF3A3A44);            // przycisk
        } else if (isTv()) {
            Ui.round(g, sx - 9, sy - 9, sx + sw + 9, sy + sh + 9, 0xFF050507);
            g.fill(sx - 9, sy + sh + 6, sx + sw + 9, sy + sh + 9, 0xFF1A1A22);
            Ui.center(g, "BUTTER TV", sx + sw / 2, sy + sh + 1, 0xFF8A7A30);
            g.fill(sx + sw / 2 - 30, sy + sh + 9, sx + sw / 2 + 30, sy + sh + 13, 0xFF15151B);
            g.fill(sx + sw / 2 - 45, sy + sh + 13, sx + sw / 2 + 45, sy + sh + 16, 0xFF15151B);
            g.fill(sx + sw - 14, sy + sh + 2, sx + sw - 11, sy + sh + 5, 0xFFE03030);  // dioda
        } else {
            Ui.round(g, sx - 7, sy - 7, sx + sw + 7, sy + sh + 7, 0xFF0C0C10);
            g.fill(sx - 7, sy - 7, sx + sw + 7, sy - 6, 0xFF2A2A33);
            g.fill(sx + sw / 2 - 6, sy + sh + 7, sx + sw / 2 + 6, sy + sh + 18, 0xFF1E1E26);
            g.fill(sx + sw / 2 - 40, sy + sh + 18, sx + sw / 2 + 40, sy + sh + 22, 0xFF1E1E26);
        }
    }

    public void drawWallpaper(GuiGraphics g, int x1, int y1, int x2, int y2) {
        int[] wp = WALLPAPERS[Mth.clamp(ClientData.get().wallpaper, 0, WALLPAPERS.length - 1)];
        g.fillGradient(x1, y1, x2, y2, wp[0], wp[1]);
    }

    public static void drawIcon(GuiGraphics g, AppRegistry.Info info, int x, int y, int size) {
        Ui.round2(g, x, y, x + size, y + size, info.color());
        g.fill(x + 2, y + 1, x + size - 2, y + 2, 0x40FFFFFF);
        if (info.id().equals("mc")) {
            int p = size / 5;
            g.fill(x + p, y + p, x + size - p, y + size - p, 0xFF8B5E3C);
            g.fill(x + p, y + p, x + size - p, y + p + (size - 2 * p) / 3, 0xFF5DAA3A);
            g.fill(x + p + 2, y + size / 2, x + p + 4, y + size / 2 + 2, 0xFF6E4A2E);
            g.fill(x + size - p - 5, y + size / 2 + 3, x + size - p - 3, y + size / 2 + 5, 0xFF6E4A2E);
            return;
        }
        if (info.id().equals("store")) {
            int p = size / 5;
            g.fill(x + p, y + size / 3, x + size - p, y + size - p, 0xFFFFF3B0);
            g.fill(x + p, y + size / 3, x + size - p, y + size / 3 + 2, 0xFFFFFFFF);
            Ui.scaledText(g, "M", x + size / 2, y + size / 3 + 2, size / 22f, 0xFFC08A00, true);
            return;
        }
        if (info.id().equals("insta")) {
            g.fillGradient(x + 1, y + 1, x + size - 1, y + size - 1, 0xFF8A3AB9, 0xFFF77737);
            int c = size / 2, r = size / 4;
            Ui.border(g, x + c - r, y + c - r, x + c + r, y + c + r, 0xFFFFFFFF);
            Ui.border(g, x + c - r / 2, y + c - r / 2, x + c + r / 2, y + c + r / 2, 0xFFFFFFFF);
            g.fill(x + c + r - 4, y + c - r + 2, x + c + r - 2, y + c - r + 4, 0xFFFFFFFF);
            return;
        }
        float scale = info.glyph().length() > 1 ? size / 22f : size / 14f;
        Ui.scaledText(g, info.glyph(), x + size / 2, y + size / 2 - (int) (4 * scale), scale, 0xFFFFFFFF, true);
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        renderBackground(g);
        drawFrame(g);
        drawWallpaper(g, sx, sy, sx + sw, sy + sh);

        if (boot > 0) {
            renderBoot(g, pt);
            return;
        }

        if (current == null) renderHome(g, mx, my);
        else {
            AppRegistry.Info info = AppRegistry.APPS.get(currentId);
            g.enableScissor(ax, ay, ax + aw, ay + ah);
            g.fill(ax, ay, ax + aw, ay + ah, 0xFF101014);
            current.renderApp(g, ax, ay, aw, ah, mx, my, pt);
            g.disableScissor();
            // pasek tytułu
            int ty = ay - 12;
            g.fill(sx, ty, sx + sw, ay, info.color());
            g.fill(sx, ay - 1, sx + sw, ay, 0x40000000);
            int tx = sx + 4;
            if (isPhone()) {
                boolean hb = mx >= sx && mx < sx + 14 && my >= ty && my < ay;
                Ui.text(g, "<", sx + 4, ty + 2, hb ? 0xFFFFFF00 : 0xFFFFFFFF);
                tx = sx + 14;
            }
            Ui.text(g, info.name(), tx, ty + 2, 0xFFFFFFFF);
            boolean hx = mx >= sx + sw - 14 && mx < sx + sw && my >= ty && my < ay;
            g.fill(sx + sw - 14, ty, sx + sw, ay, hx ? 0xFFE04040 : 0x30000000);
            Ui.text(g, "x", sx + sw - 9, ty + 1, 0xFFFFFFFF);
        }

        renderBars(g, mx, my);
        super.render(g, mx, my, pt);
    }

    private void renderBoot(GuiGraphics g, float pt) {
        float p = Mth.clamp(1.0F - (boot - pt) / 18F, 0, 1);
        g.fill(sx, sy, sx + sw, sy + sh, 0xFF0B0B10);
        int cx = sx + sw / 2, cy = sy + sh / 2;
        int bs = Math.min(sw, sh) / 5;
        // logo: kostka masła
        Ui.round2(g, cx - bs / 2, cy - bs / 2 - 10, cx + bs / 2, cy + bs / 3 - 10, 0xFFFFE680);
        g.fill(cx - bs / 2, cy - bs / 2 - 10, cx + bs / 2, cy - bs / 2 - 6, 0xFFFFF6C8);
        Ui.scaledText(g, "ButterOS", cx, cy + bs / 3 - 2, 1.5F, 0xFFFFD84A, true);
        int bw = sw / 3;
        g.fill(cx - bw / 2, cy + bs / 3 + 14, cx + bw / 2, cy + bs / 3 + 17, 0xFF2A2A33);
        g.fill(cx - bw / 2, cy + bs / 3 + 14, cx - bw / 2 + (int) (bw * p), cy + bs / 3 + 17, 0xFFFFD84A);
    }

    private void renderBars(GuiGraphics g, int mx, int my) {
        if (isPhone()) {
            g.fill(sx, sy, sx + sw, sy + 10, 0xC0000000);
            Ui.text(g, clock(), sx + 3, sy + 1, 0xFFFFFFFF);
            g.fill(sx + sw - 14, sy + 2, sx + sw - 3, sy + 7, 0xFFEEEEEE);
            g.fill(sx + sw - 13, sy + 3, sx + sw - 5, sy + 6, 0xFF4CD964);
            Ui.text(g, "5G", sx + sw - 28, sy + 1, 0xFFFFFFFF);
            // dolny pasek - powrót do ekranu głównego
            g.fill(sx, sy + sh - 8, sx + sw, sy + sh, 0xC0000000);
            boolean hh = mx >= sx + sw / 2 - 20 && mx < sx + sw / 2 + 20 && my >= sy + sh - 8;
            g.fill(sx + sw / 2 - 16, sy + sh - 5, sx + sw / 2 + 16, sy + sh - 3, hh ? 0xFFFFFFFF : 0xFFAAAAAA);
        } else if (isPc()) {
            int ty = sy + sh - 14;
            g.fill(sx, ty, sx + sw, sy + sh, 0xE0141418);
            boolean hs = mx >= sx && mx < sx + 40 && my >= ty;
            Ui.round(g, sx + 2, ty + 2, sx + 40, sy + sh - 2, hs ? 0xFFFFE680 : 0xFFF2C230);
            Ui.text(g, "Butter", sx + 5, ty + 3, 0xFF3A2A00);
            if (currentId != null) {
                AppRegistry.Info info = AppRegistry.APPS.get(currentId);
                Ui.round(g, sx + 44, ty + 2, sx + 46 + font.width(info.name()) + 14, sy + sh - 2, 0xFF2E2E38);
                g.fill(sx + 46, ty + 4, sx + 54, ty + 12, info.color());
                Ui.text(g, info.name(), sx + 57, ty + 3, 0xFFFFFFFF);
            }
            Ui.text(g, clock(), sx + sw - 32, ty + 3, 0xFFFFFFFF);
        } else if (current == null) {
            Ui.textShadow(g, clock(), sx + sw - 34, sy + 4, 0xFFFFFFFF);
        }
    }

    private int iconSize() { return isPhone() ? Math.max(20, sw / 6) : Math.max(22, Math.min(32, sh / 7)); }

    private void renderHome(GuiGraphics g, int mx, int my) {
        List<AppRegistry.Info> list = AppRegistry.installed(device);
        int top = sy + (isPhone() ? 16 : 8);
        if (!isPc()) {
            // zegar na ekranie głównym
            Ui.scaledText(g, clock(), sx + sw / 2, top + 2, isPhone() ? 2.2F : 2.5F, 0xFFFFFFFF, true);
            top += isPhone() ? 30 : 34;
        }
        int size = iconSize();
        int cellW = size + (isPhone() ? 12 : 22), cellH = size + 16;
        int cols = Math.max(1, (sw - 8) / cellW);
        int startX = sx + (sw - cols * cellW) / 2;
        int bottom = sy + sh - (isPc() ? 14 : isPhone() ? 8 : 0);
        int rowsVisible = Math.max(1, (bottom - top) / cellH);
        int maxScroll = Math.max(0, (list.size() + cols - 1) / cols - rowsVisible);
        homeScroll = Mth.clamp(homeScroll, 0, maxScroll);

        for (int i = homeScroll * cols; i < list.size(); i++) {
            int k = i - homeScroll * cols;
            int col = k % cols, row = k / cols;
            if (row >= rowsVisible) break;
            int ix = startX + col * cellW + (cellW - size) / 2;
            int iy = top + row * cellH;
            boolean hover = mx >= ix - 4 && mx < ix + size + 4 && my >= iy && my < iy + size + 12;
            if (hover) Ui.round(g, ix - 4, iy - 2, ix + size + 4, iy + size + 12, 0x40FFFFFF);
            drawIcon(g, list.get(i), ix, iy, size);
            String name = Ui.trim(list.get(i).name(), cellW - 2);
            Ui.centerShadow(g, name, ix + size / 2, iy + size + 2, 0xFFFFFF);
        }
        if (maxScroll > 0) Ui.center(g, "§7przewiń kółkiem myszy", sx + sw / 2, bottom - 10, 0xFFFFFFFF);
    }

    private String iconAt(double mx, double my) {
        List<AppRegistry.Info> list = AppRegistry.installed(device);
        int top = sy + (isPhone() ? 16 : 8);
        if (!isPc()) top += isPhone() ? 30 : 34;
        int size = iconSize();
        int cellW = size + (isPhone() ? 12 : 22), cellH = size + 16;
        int cols = Math.max(1, (sw - 8) / cellW);
        int startX = sx + (sw - cols * cellW) / 2;
        int bottom = sy + sh - (isPc() ? 14 : isPhone() ? 8 : 0);
        int rowsVisible = Math.max(1, (bottom - top) / cellH);
        for (int i = homeScroll * cols; i < list.size(); i++) {
            int k = i - homeScroll * cols;
            int col = k % cols, row = k / cols;
            if (row >= rowsVisible) break;
            int ix = startX + col * cellW + (cellW - size) / 2;
            int iy = top + row * cellH;
            if (mx >= ix - 4 && mx < ix + size + 4 && my >= iy && my < iy + size + 12) return list.get(i).id();
        }
        return null;
    }

    // ------------------------------------------------------------ wejście
    private boolean inApp(double mx, double my) {
        return mx >= ax && mx < ax + aw && my >= ay && my < ay + ah;
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (boot > 0) return true;
        // pasek telefonu (powrót)
        if (isPhone() && my >= sy + sh - 8 && my < sy + sh && mx >= sx && mx < sx + sw) { goHome(); click(); return true; }
        if (isPc() && my >= sy + sh - 14 && my < sy + sh && mx >= sx && mx < sx + 40) { goHome(); click(); return true; }
        if (current != null) {
            int ty = ay - 12;
            if (my >= ty && my < ay) {
                if (mx >= sx + sw - 14 && mx < sx + sw) { closeApp(); return true; }
                if (isPhone() && mx >= sx && mx < sx + 14) { goHome(); click(); return true; }
                return true;
            }
            if (inApp(mx, my)) return current.mouseClicked(mx, my, button);
            return super.mouseClicked(mx, my, button);
        }
        String id = iconAt(mx, my);
        if (id != null) { openApp(id); return true; }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        if (current != null && current.mouseReleased(mx, my, button)) return true;
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (current != null && current.mouseDragged(mx, my, button, dx, dy)) return true;
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public void mouseMoved(double mx, double my) {
        if (current != null) current.mouseMoved(mx, my);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double delta) {
        if (current != null) return current.mouseScrolled(mx, my, delta);
        homeScroll -= (int) Math.signum(delta);
        return true;
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (boot > 0) return true;
        if (current != null) {
            if (current.keyPressed(key, scan, mods)) return true;
            if (key == 256) { goHome(); click(); return true; } // ESC = ekran główny
            return true;
        }
        return super.keyPressed(key, scan, mods);
    }

    @Override
    public boolean keyReleased(int key, int scan, int mods) {
        if (current != null && current.keyReleased(key, scan, mods)) return true;
        return super.keyReleased(key, scan, mods);
    }

    @Override
    public boolean charTyped(char c, int mods) {
        if (current != null && current.charTyped(c, mods)) return true;
        return super.charTyped(c, mods);
    }

    @Override
    public boolean isPauseScreen() { return false; }

    public int appX() { return ax; }
    public int appY() { return ay; }
    public int appW() { return aw; }
    public int appH() { return ah; }
}
