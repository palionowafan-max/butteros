package pl.ziomsigiemka.butteros.client;

import pl.ziomsigiemka.butteros.client.apps.*;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;

/** Lista wszystkich aplikacji ButterOS. */
public class AppRegistry {
    public static final int PC = 1, PHONE = 2, TV = 4, ALL = 7;

    public record Info(String id, String name, int color, String glyph, Supplier<App> factory,
                       int devices, int preinstalled, boolean game, int sizeMb, String desc) {}

    public static final Map<String, Info> APPS = new LinkedHashMap<>();

    private static void add(String id, String name, int color, String glyph, Supplier<App> f, int devices, int pre, boolean game, int size, String desc) {
        APPS.put(id, new Info(id, name, color, glyph, f, devices, pre, game, size, desc));
    }

    static {
        add("calc", "Kalkulator", 0xFF3A3A48, "±", CalculatorApp::new, ALL, ALL, false, 2, "Liczy wszystko: dodawanie, odejmowanie, mnożenie, dzielenie.");
        add("insta", "Instagram", 0xFFD6336C, "IG", InstagramApp::new, PC | PHONE, PC | PHONE, false, 80, "Zdjęcia, serduszka, komentarze i obserwujący.");
        add("mc", "Minecraft", 0xFF4F8A2E, "", MinecraftApp::new, ALL, ALL, true, 300, "Kopanie i budowanie w świecie z bloków 3D.");
        add("notes", "Notatki", 0xFFE8B400, "✎", NotesApp::new, ALL, ALL, false, 3, "Zapisuj różne rzeczy.");
        add("snake", "Snake", 0xFF2E9E5A, "S", SnakeApp::new, ALL, ALL, true, 5, "Klasyczny wąż. Zjadaj jabłka i rośnij!");
        add("weather", "Pogoda", 0xFF3A8EE0, "☀", WeatherApp::new, ALL, ALL, false, 4, "Pogoda teraz i prognoza na cały dzień.");
        add("browser", "Przeglądarka", 0xFF2D6CDF, "◎", BrowserApp::new, ALL, ALL, false, 120, "Prawdziwy internet (wymaga moda MCEF).");
        add("store", "Sklep Masło", 0xFFF2C230, "M", StoreApp::new, ALL, ALL, false, 10, "Sklep z aplikacjami i grami.");
        add("settings", "Ustawienia", 0xFF6B6B78, "⚙", SettingsApp::new, ALL, ALL, false, 1, "Tapeta i informacje o systemie.");
        add("tv", "Telewizja", 0xFFC0392B, "TV", TvApp::new, TV, TV, false, 50, "Programy od 1 do 15.");
        // ze sklepu Masło
        add("flappy", "Flappy Gucio", 0xFF6EC6FF, "F", FlappyApp::new, ALL, 0, true, 25, "Lataj Guciem między rurami!");
        add("saper", "Saper", 0xFF8E8E9E, "✸", SaperApp::new, ALL, 0, true, 8, "Znajdź wszystkie miny i nie wybuchnij.");
        add("g2048", "2048", 0xFFEDC22E, "2K", Game2048App::new, ALL, 0, true, 6, "Łącz kafelki aż dojdziesz do 2048.");
        add("paint", "Paint", 0xFFE0573A, "✐", PaintApp::new, ALL, 0, false, 15, "Rysuj obrazki i zapisuj je do galerii.");
        add("music", "Muzyka", 0xFF9B3AE0, "♫", MusicApp::new, ALL, 0, false, 40, "Słuchaj piosenek.");
        add("gallery", "Galeria", 0xFF3AC0B0, "▣", GalleryApp::new, ALL, 0, false, 12, "Wszystkie twoje zdjęcia i rysunki.");
        add("clock", "Zegar", 0xFF22222A, "⌚", ClockApp::new, ALL, 0, false, 3, "Zegar, czas w grze i stoper.");
        add("camera", "Kamera", 0xFF505060, "◙", CameraApp::new, PC | PHONE, 0, false, 20, "Rób zdjęcia świata.");
        add("calendar", "Kalendarz", 0xFFE04848, "31", CalendarApp::new, ALL, 0, false, 4, "Kalendarz z dzisiejszą datą.");
    }

    public static int bit(int device) {
        return device == 0 ? PC : device == 1 ? PHONE : TV;
    }

    public static String key(int device) {
        return device == 0 ? "pc" : device == 1 ? "phone" : "tv";
    }

    /** Zainstalowane aplikacje na danym urządzeniu (w kolejności). */
    public static List<Info> installed(int device) {
        ClientData d = ClientData.get();
        List<String> ids = d.installed.get(key(device));
        if (ids == null) {
            ids = new ArrayList<>();
            for (Info i : APPS.values()) if ((i.preinstalled & bit(device)) != 0) ids.add(i.id);
            d.installed.put(key(device), ids);
            d.save();
        }
        List<Info> out = new ArrayList<>();
        for (String id : ids) {
            Info i = APPS.get(id);
            if (i != null && (i.devices & bit(device)) != 0) out.add(i);
        }
        return out;
    }

    public static boolean isInstalled(int device, String id) {
        for (Info i : installed(device)) if (i.id.equals(id)) return true;
        return false;
    }

    public static void install(int device, String id) {
        installed(device);
        List<String> ids = ClientData.get().installed.get(key(device));
        if (!ids.contains(id)) ids.add(id);
        ClientData.get().save();
    }

    public static void uninstall(int device, String id) {
        installed(device);
        ClientData.get().installed.get(key(device)).remove(id);
        ClientData.get().save();
    }
}
