package pl.ziomsigiemka.butteros.client.apps;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.sounds.SoundEvents;
import pl.ziomsigiemka.butteros.client.App;
import pl.ziomsigiemka.butteros.client.ClientData;
import pl.ziomsigiemka.butteros.client.Photos;
import pl.ziomsigiemka.butteros.client.Ui;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

/** Instagram: konto, zdjęcia, serduszka i komentarze od botów, weryfikacja od 1000 obserwujących. */
public class InstagramApp extends App {
    private enum View { SIGNUP, FEED, PROFILE, NEW_POST, CAPTION, POST }

    public static final int VERIFY_AT = 1000;

    private record Bot(String name, int color, int followers, boolean verified) {}

    private static final Bot[] BOTS = {
            new Bot("kasia_gotuje", 0xFFE0573A, 24300, true),
            new Bot("mati_podroze", 0xFF3A8EE0, 8800, false),
            new Bot("kot_filemon", 0xFFE8923A, 152000, true),
            new Bot("blokowy_bartek", 0xFF4F8A2E, 3100, false),
            new Bot("gwiazdy_nocy", 0xFF3A2A8A, 41200, true),
            new Bot("lesna_ola", 0xFF2E8B3A, 1900, false),
            new Bot("pizza_master_pl", 0xFFD8442A, 12700, false),
            new Bot("gucio_official", 0xFFF2A03A, 99900, true),
            new Bot("zosia_tanczy", 0xFFD6336C, 5600, false),
            new Bot("kuba_gamer", 0xFF6A2AC0, 33000, true),
    };

    private record BotPost(int bot, int type, String caption, int likes, long seed) {}

    private static final BotPost[] BOT_POSTS = {
            new BotPost(7, 9, "Dzisiaj moje urodziny! Kto przyjdzie na tort?", 15400, 11),
            new BotPost(0, 4, "Domowa pizza na kolację. Przepis w komentarzu!", 2310, 21),
            new BotPost(2, 5, "Pan Filemon ocenia twoje zdjęcia.", 18750, 31),
            new BotPost(1, 1, "Widok z samego szczytu. Warto było!", 980, 41),
            new BotPost(3, 7, "Nowa baza w Minecrafcie gotowa", 450, 51),
            new BotPost(4, 8, "Galaktyka z mojego teleskopu", 5200, 61),
            new BotPost(1, 6, "Wakacje!!! Kto zazdrości?", 1200, 71),
            new BotPost(5, 2, "Spacer po lesie o poranku", 310, 81),
            new BotPost(6, 4, "Pizza z ananasem: tak czy nie?", 1780, 91),
            new BotPost(4, 3, "Miasto nocą wygląda magicznie", 3900, 101),
            new BotPost(1, 0, "Najpiękniejszy zachód słońca w życiu", 1430, 111),
            new BotPost(9, 7, "Speedrun w 10 minut?! Link w bio", 6100, 121),
            new BotPost(0, 9, "Tort dla Gucia", 2800, 131),
            new BotPost(2, 5, "Drzemka numer 5 dzisiaj", 22100, 141),
    };

    private static final String[] COMMENTS = {
            "Super zdjęcie!", "Wow, piękne <3", "Gdzie to jest?", "Ale fajnie!!!", "Mega klimat",
            "Też tak chcę :D", "Najlepsze zdjęcie dzisiaj", "Obserwuję!", "Hahaha super", "Kocham to <3",
            "Jakim telefonem robione?", "10/10", "Niesamowite!", "Zazdro :P", "Więcej takich!",
            "Pozdrawiam serdecznie!", "To jest sztos", "Ładne kolory", "O kurczę, ale widok", "Gucio by to polubił",
            "Wbijaj na mój profil!", "Brawo!", "Czekałem na to", "Piękne <3 <3 <3", "Daj więcej zdjęć!"
    };

    private View view;
    private final Ui.TextInput nameInput = new Ui.TextInput(20, false);
    private final Ui.TextInput captionInput = new Ui.TextInput(80, false);
    private String chosenPic = null;
    private int openPost = -1;          // indeks własnego posta (>=0) albo -(indeks bota+1)
    private int scroll = 0;
    private final Set<Integer> likedBots = new HashSet<>();

    private ClientData.Insta insta() { return ClientData.get().insta; }

    @Override
    protected void onOpen() {
        view = insta().username == null ? View.SIGNUP : View.FEED;
        nameInput.focused = true;
    }

    // ------------------------------------------------------------ liczby
    private static double growth(long time, double minutes) {
        double m = (System.currentTimeMillis() - time) / 60000.0;
        return Math.max(0.05, Math.min(1.0, m / minutes));
    }

    private int likes(ClientData.Post p) {
        return (int) (p.likesTarget * Math.sqrt(growth(p.time, 8))) + (p.liked ? 1 : 0);
    }

    public int followers() {
        int f = 0;
        for (ClientData.Post p : insta().posts) f += (int) (p.followersTarget * growth(p.time, 10));
        return f;
    }

    private int commentCount(ClientData.Post p) {
        int max = 2 + (int) (p.seed % 6) + p.likesTarget / 120;
        long secs = (System.currentTimeMillis() - p.time) / 1000;
        return (int) Math.min(max, 1 + secs / 25);
    }

    private static String fmt(int n) {
        if (n >= 1_000_000) return String.format(java.util.Locale.ROOT, "%.1f mln", n / 1_000_000.0).replace('.', ',');
        if (n >= 10_000) return (n / 1000) + " tys.";
        if (n >= 1000) return String.format(java.util.Locale.ROOT, "%.1f tys.", n / 1000.0).replace('.', ',');
        return String.valueOf(n);
    }

    private static String ago(long time) {
        long m = (System.currentTimeMillis() - time) / 60000;
        if (m < 1) return "przed chwilą";
        if (m < 60) return m + " min temu";
        if (m < 1440) return (m / 60) + " godz. temu";
        return (m / 1440) + " dni temu";
    }

    // ------------------------------------------------------------ rysowanie elementów
    private void avatar(GuiGraphics g, int ax, int ay, int size, int color, String name) {
        Ui.round2(g, ax - 1, ay - 1, ax + size + 1, ay + size + 1, 0xFFF77737);
        Ui.round2(g, ax, ay, ax + size, ay + size, color);
        Ui.center(g, name.substring(0, 1).toUpperCase(), ax + size / 2, ay + (size - 8) / 2 + 1, 0xFFFFFFFF);
    }

    private void verified(GuiGraphics g, int vx, int vy) {
        Ui.round2(g, vx, vy, vx + 9, vy + 9, 0xFF3897F0);
        Ui.text(g, "✓", vx + 2, vy + 1, 0xFFFFFFFF);
    }

    private void heart(GuiGraphics g, int hx, int hy, boolean full) {
        int c = full ? 0xFFED4956 : 0xFF262626;
        g.fill(hx + 1, hy, hx + 4, hy + 1, c); g.fill(hx + 6, hy, hx + 9, hy + 1, c);
        g.fill(hx, hy + 1, hx + 10, hy + 4, c);
        g.fill(hx + 1, hy + 4, hx + 9, hy + 5, c);
        g.fill(hx + 2, hy + 5, hx + 8, hy + 6, c);
        g.fill(hx + 3, hy + 6, hx + 7, hy + 7, c);
        g.fill(hx + 4, hy + 7, hx + 6, hy + 8, c);
        if (!full) { g.fill(hx + 2, hy + 2, hx + 8, hy + 4, 0xFFFFFFFF); g.fill(hx + 3, hy + 4, hx + 7, hy + 5, 0xFFFFFFFF); g.fill(hx + 4, hy + 5, hx + 6, hy + 6, 0xFFFFFFFF); }
    }

    private void navBar(GuiGraphics g, int mx, int my) {
        int ny = y + h - 18;
        g.fill(x, ny, x + w, y + h, 0xFFFFFFFF);
        g.fill(x, ny, x + w, ny + 1, 0xFFDBDBDB);
        int third = w / 3;
        String[] labels = {"Główna", "+ Dodaj", "Profil"};
        View[] views = {View.FEED, View.NEW_POST, View.PROFILE};
        for (int i = 0; i < 3; i++) {
            boolean active = view == views[i];
            boolean hover = inside(mx, my, x + i * third, ny, third, 18);
            Ui.center(g, (active ? "§l" : "") + labels[i], x + i * third + third / 2, ny + 5, hover ? 0xFF3897F0 : 0xFF262626);
            area("nav" + i, x + i * third, ny, third, 18);
        }
    }

    private void header(GuiGraphics g, String title) {
        g.fill(x, y, x + w, y + 16, 0xFFFFFFFF);
        g.fill(x, y + 16, x + w, y + 17, 0xFFDBDBDB);
        Ui.text(g, title, x + 6, y + 4, 0xFF262626);
    }

    // ------------------------------------------------------------ widoki
    @Override
    protected void render(GuiGraphics g, int mx, int my, float pt) {
        g.fill(x, y, x + w, y + h, 0xFFFAFAFA);
        switch (view) {
            case SIGNUP -> renderSignup(g, mx, my);
            case FEED -> { renderFeed(g, mx, my); header(g, "§lInstagram"); navBar(g, mx, my); }
            case PROFILE -> { renderProfile(g, mx, my); navBar(g, mx, my); }
            case NEW_POST -> { renderNewPost(g, mx, my); navBar(g, mx, my); }
            case CAPTION -> renderCaption(g, mx, my);
            case POST -> renderPost(g, mx, my);
        }
    }

    private void renderSignup(GuiGraphics g, int mx, int my) {
        g.fillGradient(x, y, x + w, y + h, 0xFF8A3AB9, 0xFFF77737);
        int cx = x + w / 2;
        Ui.scaledText(g, "Instagram", cx, y + 20, 2.0F, 0xFFFFFFFF, true);
        Ui.center(g, "Załóż konto, żeby dodawać zdjęcia", cx, y + 46, 0xFFFFFFFF);
        int fw = Math.min(160, w - 20);
        nameInput.render(g, cx - fw / 2, y + 62, fw, 16, "Nazwa użytkownika");
        area("name", cx - fw / 2, y + 62, fw, 16);
        button(g, "signup", cx - fw / 2, y + 84, fw, 16, "Załóż konto", 0xFF3897F0, mx, my);
        Ui.center(g, "§7(3-20 znaków: litery, cyfry, _ i .)", cx, y + 106, 0xFFFFFFFF);
    }

    private int postHeight() { return 22 + (w - 8) * 9 / 16 + 40; }

    private void renderFeed(GuiGraphics g, int mx, int my) {
        // lista: najpierw moje nowe posty, potem boty
        List<int[]> items = feedItems();
        g.enableScissor(x, y + 17, x + w, y + h - 18);
        int yy = y + 20 - scroll;
        int ph = postHeight();
        for (int[] it : items) {
            if (yy + ph > y + 17 && yy < y + h - 18) renderPostCard(g, it[0], it[1], yy, mx, my);
            yy += ph + 4;
        }
        g.disableScissor();
    }

    private List<int[]> feedItems() {
        List<int[]> items = new ArrayList<>();
        List<ClientData.Post> posts = insta().posts;
        int i = 0;
        for (int bi = 0; bi < BOT_POSTS.length; bi++) {
            if (bi % 3 == 0 && i < posts.size()) items.add(new int[]{0, i++});
            items.add(new int[]{1, bi});
        }
        while (i < posts.size()) items.add(new int[]{0, i++});
        return items;
    }

    private void renderPostCard(GuiGraphics g, int kind, int idx, int yy, int mx, int my) {
        String name; int color; boolean ver; String pic; String caption; int likes; boolean liked; int comments; String when;
        if (kind == 0) {
            ClientData.Post p = insta().posts.get(idx);
            name = insta().username; color = 0xFF3897F0; ver = followers() >= VERIFY_AT; pic = p.image; caption = p.caption;
            likes = likes(p); liked = p.liked; comments = commentCount(p); when = ago(p.time);
        } else {
            BotPost b = BOT_POSTS[idx];
            Bot bot = BOTS[b.bot];
            name = bot.name; color = bot.color; ver = bot.verified; pic = "bot:" + b.seed + ":" + b.type; caption = b.caption;
            liked = likedBots.contains(idx); likes = b.likes + (liked ? 1 : 0); comments = 3 + (int) (b.seed % 7); when = (1 + idx) + " godz. temu";
        }
        g.fill(x, yy, x + w, yy + postHeight(), 0xFFFFFFFF);
        avatar(g, x + 5, yy + 4, 14, color, name);
        Ui.text(g, "§l" + name, x + 23, yy + 7, 0xFF262626);
        if (ver) verified(g, x + 25 + font().width("§l" + name), yy + 6);
        int iw = w - 8, ih = iw * 9 / 16;
        Photos.draw(g, Photos.photo(pic), x + 4, yy + 22, iw, ih);
        String key = (kind == 0 ? "my" : "bot") + idx;
        area("open" + key, x + 4, yy + 22, iw, ih);
        int by = yy + 26 + ih;
        heart(g, x + 6, by, liked);
        area("like" + key, x + 4, by - 2, 14, 12);
        Ui.text(g, "§l" + fmt(likes) + " polubień", x + 22, by, 0xFF262626);
        Ui.text(g, Ui.trim("§l" + name + "§r " + caption, w - 12), x + 6, by + 11, 0xFF262626);
        Ui.text(g, "Zobacz komentarze (" + comments + ") • " + when, x + 6, by + 22, 0xFF8E8E8E);
        area("open" + key, x + 4, by + 20, w - 8, 10);
    }

    private void renderProfile(GuiGraphics g, int mx, int my) {
        header(g, "§l" + insta().username);
        int f = followers();
        boolean ver = f >= VERIFY_AT;
        if (ver) verified(g, x + 8 + font().width("§l" + insta().username), y + 3);
        avatar(g, x + 8, y + 24, 32, 0xFF3897F0, insta().username);
        int cw = (w - 50) / 3;
        String[][] stats = {{String.valueOf(insta().posts.size()), "posty"}, {fmt(f), "obserwujący"}, {"" + BOTS.length, "obserwowani"}};
        for (int i = 0; i < 3; i++) {
            int sx = x + 48 + i * cw + cw / 2;
            Ui.center(g, "§l" + stats[i][0], sx, y + 28, 0xFF262626);
            Ui.center(g, Ui.trim(stats[i][1], cw), sx, y + 40, 0xFF8E8E8E);
        }
        int yy = y + 62;
        if (ver) {
            Ui.text(g, "§9✓ Konto zweryfikowane!", x + 8, yy, 0xFFFFFFFF);
        } else {
            Ui.text(g, "Do weryfikacji: " + (VERIFY_AT - f) + " obserwujących", x + 8, yy, 0xFF8E8E8E);
            int bw = w - 16;
            g.fill(x + 8, yy + 11, x + 8 + bw, yy + 14, 0xFFDBDBDB);
            g.fill(x + 8, yy + 11, x + 8 + bw * f / VERIFY_AT, yy + 14, 0xFF3897F0);
        }
        yy += 20;
        int cols = 3, tw = (w - 8) / cols - 2, th = tw * 9 / 16;
        g.enableScissor(x, yy, x + w, y + h - 18);
        if (insta().posts.isEmpty()) Ui.center(g, "Nie masz jeszcze postów. Kliknij + Dodaj!", x + w / 2, yy + 20, 0xFF8E8E8E);
        for (int i = 0; i < insta().posts.size(); i++) {
            int tx = x + 4 + (i % cols) * (tw + 2), ty = yy + (i / cols) * (th + 2) - scroll;
            Photos.draw(g, Photos.photo(insta().posts.get(i).image), tx, ty, tw, th);
            area("openmy" + i, tx, ty, tw, th);
        }
        g.disableScissor();
    }

    private void renderNewPost(GuiGraphics g, int mx, int my) {
        header(g, "§lNowy post");
        button(g, "shot", x + 6, y + 22, w - 12, 16, "Zrób zdjęcie świata", 0xFF3897F0, mx, my);
        Ui.text(g, "albo wybierz z galerii:", x + 6, y + 44, 0xFF8E8E8E);
        List<String> pics = ClientData.get().gallery;
        int cols = 3, tw = (w - 8) / cols - 2, th = tw * 9 / 16;
        g.enableScissor(x, y + 55, x + w, y + h - 18);
        if (pics.isEmpty()) Ui.center(g, "Galeria jest pusta.", x + w / 2, y + 70, 0xFFAAAAAA);
        for (int i = 0; i < pics.size(); i++) {
            int tx = x + 4 + (i % cols) * (tw + 2), ty = y + 56 + (i / cols) * (th + 2) - scroll;
            Photos.draw(g, Photos.photo(pics.get(i)), tx, ty, tw, th);
            if (inside(mx, my, tx, ty, tw, th)) Ui.border(g, tx, ty, tx + tw, ty + th, 0xFF3897F0);
            area("pick" + i, tx, ty, tw, th);
        }
        g.disableScissor();
    }

    private void renderCaption(GuiGraphics g, int mx, int my) {
        header(g, "§lNowy post");
        int iw = w - 8, ih = Math.min(iw * 9 / 16, h - 80);
        iw = ih * 16 / 9;
        Photos.draw(g, Photos.photo(chosenPic), x + (w - iw) / 2, y + 20, iw, ih);
        int fy = y + 24 + ih;
        captionInput.render(g, x + 6, fy, w - 12, 16, "Dodaj opis...");
        area("caption", x + 6, fy, w - 12, 16);
        button(g, "cancel", x + 6, fy + 20, 60, 16, "Anuluj", 0xFF8E8E8E, mx, my);
        button(g, "publish", x + w - 86, fy + 20, 80, 16, "Opublikuj", 0xFF3897F0, mx, my);
    }

    private void renderPost(GuiGraphics g, int mx, int my) {
        boolean mine = openPost >= 0;
        String name, pic, caption; int color; long seed; int count;
        if (mine) {
            ClientData.Post p = insta().posts.get(openPost);
            name = insta().username; pic = p.image; caption = p.caption; color = 0xFF3897F0; seed = p.seed; count = commentCount(p);
        } else {
            BotPost b = BOT_POSTS[-openPost - 1];
            name = BOTS[b.bot].name; pic = "bot:" + b.seed + ":" + b.type; caption = b.caption; color = BOTS[b.bot].color; seed = b.seed; count = 3 + (int) (b.seed % 7);
        }
        header(g, "§lPost");
        button(g, "back", x + w - 46, y + 2, 42, 12, "< Wróć", 0xFF8E8E8E, mx, my);
        int iw = Math.min(w - 8, (h / 2 - 20) * 16 / 9), ih = iw * 9 / 16;
        Photos.draw(g, Photos.photo(pic), x + (w - iw) / 2, y + 20, iw, ih);
        int yy = y + 24 + ih - scroll;
        g.enableScissor(x, y + 22 + ih, x + w, y + h);
        avatar(g, x + 6, yy, 12, color, name);
        Ui.text(g, Ui.trim("§l" + name + "§r " + caption, w - 30), x + 22, yy + 2, 0xFF262626);
        yy += 16;
        Ui.text(g, "§lKomentarze", x + 6, yy, 0xFF262626);
        yy += 12;
        Random r = new Random(seed * 31);
        for (int i = 0; i < count; i++) {
            Bot bot = BOTS[r.nextInt(BOTS.length)];
            String text = COMMENTS[r.nextInt(COMMENTS.length)];
            avatar(g, x + 6, yy, 10, bot.color, bot.name);
            Ui.text(g, Ui.trim("§l" + bot.name + "§r " + text, w - 28), x + 20, yy + 1, 0xFF262626);
            yy += 14;
        }
        if (mine && count < 2 + (int) (seed % 6) + insta().posts.get(openPost).likesTarget / 120)
            Ui.text(g, "§7... ktoś właśnie pisze komentarz", x + 6, yy, 0xFFFFFFFF);
        g.disableScissor();
    }

    // ------------------------------------------------------------ akcje
    private void publish() {
        if (chosenPic == null) return;
        ClientData.Post p = new ClientData.Post();
        p.image = chosenPic;
        p.caption = captionInput.get();
        p.time = System.currentTimeMillis();
        Random r = new Random();
        p.seed = r.nextLong() & 0xFFFFFFFL;
        int f = followers();
        p.likesTarget = 40 + f * 2 / 5 + r.nextInt(160);
        p.followersTarget = 120 + r.nextInt(200);
        insta().posts.add(0, p);
        ClientData.get().save();
        captionInput.set("");
        chosenPic = null;
        view = View.PROFILE;
        scroll = 0;
        os.sound(SoundEvents.PLAYER_LEVELUP, 1.8F, 0.4F);
    }

    @Override
    protected void onButton(String id, int button) {
        os.click();
        switch (id) {
            case "name" -> nameInput.focused = true;
            case "signup" -> signup();
            case "nav0" -> { view = View.FEED; scroll = 0; }
            case "nav1" -> { view = View.NEW_POST; scroll = 0; }
            case "nav2" -> { view = View.PROFILE; scroll = 0; }
            case "shot" -> Photos.capture(Minecraft.getInstance().screen, name -> {
                if (name != null) { chosenPic = name; view = View.CAPTION; captionInput.focused = true; }
            });
            case "caption" -> captionInput.focused = true;
            case "cancel" -> { view = View.NEW_POST; chosenPic = null; }
            case "publish" -> publish();
            case "back" -> { view = openPost >= 0 ? View.PROFILE : View.FEED; scroll = 0; }
            default -> {
                if (id.startsWith("pick")) {
                    chosenPic = ClientData.get().gallery.get(Integer.parseInt(id.substring(4)));
                    view = View.CAPTION;
                    captionInput.focused = true;
                } else if (id.startsWith("likemy")) {
                    ClientData.Post p = insta().posts.get(Integer.parseInt(id.substring(6)));
                    p.liked = !p.liked;
                    ClientData.get().save();
                } else if (id.startsWith("likebot")) {
                    int b = Integer.parseInt(id.substring(7));
                    if (!likedBots.remove(b)) likedBots.add(b);
                } else if (id.startsWith("openmy")) {
                    openPost = Integer.parseInt(id.substring(6));
                    view = View.POST;
                    scroll = 0;
                } else if (id.startsWith("openbot")) {
                    openPost = -Integer.parseInt(id.substring(7)) - 1;
                    view = View.POST;
                    scroll = 0;
                }
            }
        }
    }

    private void signup() {
        String n = nameInput.get().trim();
        if (n.length() < 3 || !n.matches("[A-Za-z0-9_.]+")) return;
        insta().username = n;
        ClientData.get().save();
        view = View.FEED;
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double d) {
        scroll = Math.max(0, scroll - (int) (d * 25));
        return true;
    }

    @Override
    public boolean charTyped(char c, int mods) {
        if (view == View.SIGNUP) return nameInput.charTyped(c);
        if (view == View.CAPTION) return captionInput.charTyped(c);
        return false;
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (view == View.SIGNUP) {
            boolean r = nameInput.keyPressed(key);
            if (nameInput.enterPressed) signup();
            return r;
        }
        if (view == View.CAPTION) {
            boolean r = captionInput.keyPressed(key);
            if (captionInput.enterPressed) publish();
            return r;
        }
        return false;
    }
}
