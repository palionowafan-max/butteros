package pl.ziomsigiemka.butteros.client.apps;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import pl.ziomsigiemka.butteros.client.App;
import pl.ziomsigiemka.butteros.client.Ui;

import java.time.LocalTime;

public class ClockApp extends App {
    private boolean running = false;
    private long startMs = 0, elapsed = 0;

    private long stopwatch() { return running ? elapsed + (System.currentTimeMillis() - startMs) : elapsed; }

    @Override
    protected void render(GuiGraphics g, int mx, int my, float pt) {
        g.fill(x, y, x + w, y + h, 0xFF101016);
        LocalTime t = LocalTime.now();
        int cx = x + w / 2;
        // tarcza
        int r = Math.min(w, h) / 5;
        int cy = y + r + 10;
        for (int i = 0; i < 60; i++) {
            double a = i * Math.PI / 30;
            int px = cx + (int) (Math.sin(a) * r), py = cy - (int) (Math.cos(a) * r);
            g.fill(px, py, px + 1, py + 1, i % 5 == 0 ? 0xFFFFFFFF : 0xFF55555F);
        }
        hand(g, cx, cy, (t.getHour() % 12 + t.getMinute() / 60.0) / 12.0, r * 0.5, 0xFFFFFFFF);
        hand(g, cx, cy, (t.getMinute() + t.getSecond() / 60.0) / 60.0, r * 0.8, 0xFFCCCCCC);
        hand(g, cx, cy, t.getSecond() / 60.0, r * 0.9, 0xFFE04040);
        Ui.scaledText(g, String.format("%02d:%02d:%02d", t.getHour(), t.getMinute(), t.getSecond()), cx, cy + r + 8, 2.0F, 0xFFFFFFFF, true);

        if (Minecraft.getInstance().level != null) {
            long dt = (Minecraft.getInstance().level.getDayTime() + 6000L) % 24000L;
            Ui.center(g, String.format("Czas w Minecrafcie: %02d:%02d", dt / 1000, (dt % 1000) * 60 / 1000), cx, cy + r + 28, 0xFFFFD84A);
        }
        long s = stopwatch();
        int sy = y + h - 34;
        Ui.center(g, String.format("Stoper: %02d:%02d.%d", s / 60000, (s / 1000) % 60, (s / 100) % 10), cx, sy, 0xFF8AE08A);
        button(g, "start", cx - 62, sy + 12, 60, 14, running ? "Stop" : "Start", running ? 0xFFD04040 : 0xFF2EAE4E, mx, my);
        button(g, "reset", cx + 2, sy + 12, 60, 14, "Zeruj", 0xFF55555F, mx, my);
    }

    private void hand(GuiGraphics g, int cx, int cy, double frac, double len, int color) {
        double a = frac * Math.PI * 2;
        for (int i = 0; i < len; i++) {
            int px = cx + (int) (Math.sin(a) * i), py = cy - (int) (Math.cos(a) * i);
            g.fill(px, py, px + 1, py + 1, color);
        }
    }

    @Override
    protected void onButton(String id, int button) {
        if (id.equals("start")) {
            if (running) { elapsed = stopwatch(); running = false; }
            else { startMs = System.currentTimeMillis(); running = true; }
        } else { running = false; elapsed = 0; }
        os.click();
    }
}
