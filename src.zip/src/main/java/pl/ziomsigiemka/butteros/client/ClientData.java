package pl.ziomsigiemka.butteros.client;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.minecraft.client.Minecraft;

import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Dane ButterOS zapisane na komputerze gracza (folder .minecraft/butteros). */
public class ClientData {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static ClientData instance;

    public Map<String, List<String>> installed = new HashMap<>();
    public List<Note> notes = new ArrayList<>();
    public Insta insta = new Insta();
    public List<String> gallery = new ArrayList<>();
    public int wallpaper = 0;
    public int snakeBest = 0, flappyBest = 0, best2048 = 0;

    public static class Note {
        public String title = "Nowa notatka";
        public String text = "";
    }

    public static class Insta {
        public String username = null;
        public String bio = "";
        public List<Post> posts = new ArrayList<>();
    }

    public static class Post {
        public String image;
        public String caption = "";
        public long time;
        public int likesTarget;
        public int followersTarget;
        public long seed;
        public boolean liked = false;
    }

    public static Path dir() {
        Path p = Minecraft.getInstance().gameDirectory.toPath().resolve("butteros");
        try { Files.createDirectories(p.resolve("photos")); } catch (Exception ignored) {}
        return p;
    }

    public static ClientData get() {
        if (instance == null) {
            Path f = dir().resolve("dane.json");
            try (Reader r = Files.newBufferedReader(f, StandardCharsets.UTF_8)) {
                instance = GSON.fromJson(r, ClientData.class);
            } catch (Exception e) {
                instance = null;
            }
            if (instance == null) instance = new ClientData();
            if (instance.installed == null) instance.installed = new HashMap<>();
            if (instance.notes == null) instance.notes = new ArrayList<>();
            if (instance.insta == null) instance.insta = new Insta();
            if (instance.insta.posts == null) instance.insta.posts = new ArrayList<>();
            if (instance.gallery == null) instance.gallery = new ArrayList<>();
        }
        return instance;
    }

    public void save() {
        try (Writer w = Files.newBufferedWriter(dir().resolve("dane.json"), StandardCharsets.UTF_8)) {
            GSON.toJson(this, w);
        } catch (Exception ignored) {}
    }
}
