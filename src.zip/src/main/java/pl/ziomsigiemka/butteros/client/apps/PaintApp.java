package pl.ziomsigiemka.butteros.client.apps;

import com.mojang.blaze3d.platform.NativeImage;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.sounds.SoundEvents;
import pl.ziomsigiemka.butteros.client.App;
import pl.ziomsigiemka.butteros.client.Photos;
import pl.ziomsigiemka.butteros.client.Ui;

import java.util.ArrayDeque;
import java.util.Arrays;

public class PaintApp extends App {
    private static final int CW = 96, CH = 54;
    private static final int[] PALETTE = {0xFF000000, 0xFFFFFFFF, 0xFF7F7F7F, 0xFFE03030, 0xFFFF8A20, 0xFFFFE040,
            0xFF4CD964, 0xFF2E8B3A, 0xFF3AB0FF, 0xFF2D4CDF, 0xFFA040FF, 0xFFFF7AC0, 0xFF8B5E3C, 0xFFF2D0A0};
    private final int[] canvas = new int[CW * CH];
    private int color = 0xFF000000, size = 1, tool = 0; // 0 pędzel, 1 gumka, 2 wiadro
    private int cx0, cy0, cell;
    private String saved = null;
    private int savedTimer = 0;

    public PaintApp() { Arrays.fill(canvas, 0xFFFFFFFF); }

    @Override
    public void tick() { if (savedTimer > 0) savedTimer--; }

    @Override
    protected void render(GuiGraphics g, int mx, int my, float pt) {
        g.fill(x, y, x + w, y + h, 0xFFD8D8E0);
        // narzędzia
        int ty = y + 2;
        button(g, "t0", x + 2, ty, 40, 13, "Pędzel", tool == 0 ? 0xFF3A6EE0 : 0xFF6B6B78, mx, my);
        button(g, "t1", x + 44, ty, 40, 13, "Gumka", tool == 1 ? 0xFF3A6EE0 : 0xFF6B6B78, mx, my);
        button(g, "t2", x + 86, ty, 40, 13, "Wiadro", tool == 2 ? 0xFF3A6EE0 : 0xFF6B6B78, mx, my);
        button(g, "size", x + 128, ty, 40, 13, "Gr: " + size, 0xFF6B6B78, mx, my);
        button(g, "clear", x + w - 88, ty, 42, 13, "Wyczyść", 0xFFD04040, mx, my);
        button(g, "save", x + w - 44, ty, 42, 13, "Zapisz", 0xFF2EAE4E, mx, my);
        // paleta
        int py = y + h - 14;
        int pw = Math.min(14, (w - 4) / PALETTE.length);
        for (int i = 0; i < PALETTE.length; i++) {
            int px = x + 2 + i * pw;
            g.fill(px, py, px + pw - 1, py + 12, PALETTE[i]);
            if (PALETTE[i] == color) Ui.border(g, px - 1, py - 1, px + pw, py + 13, 0xFF3A6EE0);
            area("p" + i, px, py, pw - 1, 12);
        }
        // płótno
        cell = Math.max(1, Math.min((w - 4) / CW, (h - 34) / CH));
        cx0 = x + (w - cell * CW) / 2;
        cy0 = y + 17 + (h - 34 - cell * CH) / 2;
        g.fill(cx0 - 1, cy0 - 1, cx0 + cell * CW + 1, cy0 + cell * CH + 1, 0xFF505058);
        for (int j = 0; j < CH; j++) {
            int run = 0, start = 0;
            for (int i = 0; i <= CW; i++) {
                int c = i < CW ? canvas[j * CW + i] : 0;
                if (i == CW || (i > 0 && c != canvas[j * CW + i - 1])) {
                    g.fill(cx0 + start * cell, cy0 + j * cell, cx0 + i * cell, cy0 + (j + 1) * cell, canvas[j * CW + start]);
                    start = i;
                }
            }
        }
        if (savedTimer > 0) Ui.center(g, "§2Zapisano w Galerii!", x + w / 2, cy0 + 4, 0xFFFFFFFF);
    }

    private void paintAt(double mx, double my) {
        int i = (int) ((mx - cx0) / cell), j = (int) ((my - cy0) / cell);
        if (i < 0 || j < 0 || i >= CW || j >= CH) return;
        if (tool == 2) { fill(i, j, color); return; }
        int c = tool == 1 ? 0xFFFFFFFF : color;
        int r = size - 1;
        for (int a = -r; a <= r; a++) for (int b = -r; b <= r; b++) {
            int ii = i + a, jj = j + b;
            if (ii >= 0 && jj >= 0 && ii < CW && jj < CH && a * a + b * b <= r * r + r) canvas[jj * CW + ii] = c;
        }
    }

    private void fill(int i, int j, int c) {
        int target = canvas[j * CW + i];
        if (target == c) return;
        ArrayDeque<int[]> q = new ArrayDeque<>();
        q.add(new int[]{i, j});
        while (!q.isEmpty()) {
            int[] p = q.poll();
            if (p[0] < 0 || p[1] < 0 || p[0] >= CW || p[1] >= CH || canvas[p[1] * CW + p[0]] != target) continue;
            canvas[p[1] * CW + p[0]] = c;
            q.add(new int[]{p[0] + 1, p[1]}); q.add(new int[]{p[0] - 1, p[1]});
            q.add(new int[]{p[0], p[1] + 1}); q.add(new int[]{p[0], p[1] - 1});
        }
    }

    private void save() {
        NativeImage img = new NativeImage(Photos.PW, Photos.PH, false);
        for (int yy = 0; yy < Photos.PH; yy++) for (int xx = 0; xx < Photos.PW; xx++) {
            int c = canvas[(yy * CH / Photos.PH) * CW + (xx * CW / Photos.PW)];
            img.setPixelRGBA(xx, yy, 0xFF000000 | ((c & 255) << 16) | (c & 0xFF00) | ((c >> 16) & 255));
        }
        saved = Photos.saveImage(img);
        img.close();
        savedTimer = 50;
        os.sound(SoundEvents.UI_CARTOGRAPHY_TABLE_TAKE_RESULT, 1.4F, 0.6F);
    }

    @Override
    protected void onButton(String id, int button) {
        switch (id) {
            case "t0" -> tool = 0;
            case "t1" -> tool = 1;
            case "t2" -> tool = 2;
            case "size" -> size = size % 4 + 1;
            case "clear" -> Arrays.fill(canvas, 0xFFFFFFFF);
            case "save" -> save();
            default -> { if (id.startsWith("p")) { color = PALETTE[Integer.parseInt(id.substring(1))]; if (tool == 1) tool = 0; } }
        }
        os.click();
    }

    @Override
    protected boolean click(double mx, double my, int button) { paintAt(mx, my); return true; }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (tool != 2) paintAt(mx, my);
        return true;
    }
}
