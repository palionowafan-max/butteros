package pl.ziomsigiemka.butteros.client;

import com.mojang.blaze3d.platform.NativeImage;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Screenshot;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import pl.ziomsigiemka.butteros.ButterOSMod;

import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.function.Consumer;

/** Zdjęcia: robienie zdjęć ze świata, wczytywanie ich jako tekstury i obrazki botów. */
@Mod.EventBusSubscriber(modid = ButterOSMod.MODID, value = Dist.CLIENT)
public class Photos {
    public static final int PW = 320, PH = 180;
    private static final Map<String, ResourceLocation> CACHE = new HashMap<>();
    private static int counter = 0;

    // ------------------------------------------------------------- rysowanie
    public static void draw(GuiGraphics g, ResourceLocation rl, int x, int y, int w, int h) {
        if (rl == null) { g.fill(x, y, x + w, y + h, 0xFF333333); return; }
        g.blit(rl, x, y, w, h, 0, 0, 16, 9, 16, 9);
    }

    // ------------------------------------------------------------- zdjęcia gracza
    public static ResourceLocation photo(String file) {
        if (file == null) return null;
        if (file.startsWith("bot:")) {
            String[] p = file.split(":");
            return botImage(Long.parseLong(p[1]), Integer.parseInt(p[2]));
        }
        ResourceLocation cached = CACHE.get(file);
        if (cached != null) return cached;
        Path path = ClientData.dir().resolve("photos").resolve(file);
        try (InputStream in = Files.newInputStream(path)) {
            NativeImage img = NativeImage.read(in);
            return register("photo_" + (counter++), img, file);
        } catch (Exception e) {
            CACHE.put(file, null);
            return null;
        }
    }

    private static ResourceLocation register(String name, NativeImage img, String key) {
        ResourceLocation rl = new ResourceLocation(ButterOSMod.MODID, "dyn/" + name);
        Minecraft.getInstance().getTextureManager().register(rl, new DynamicTexture(img));
        CACHE.put(key, rl);
        return rl;
    }

    public static String saveImage(NativeImage small) {
        String name = "zdj_" + System.currentTimeMillis() + ".png";
        try {
            small.writeToFile(ClientData.dir().resolve("photos").resolve(name));
        } catch (Exception e) {
            return null;
        }
        ClientData d = ClientData.get();
        d.gallery.add(0, name);
        d.save();
        return name;
    }

    private static NativeImage shrink(NativeImage full) {
        int fw = full.getWidth(), fh = full.getHeight();
        int cw = fw, ch = fw * 9 / 16;
        if (ch > fh) { ch = fh; cw = fh * 16 / 9; }
        int ox = (fw - cw) / 2, oy = (fh - ch) / 2;
        NativeImage small = new NativeImage(PW, PH, false);
        for (int y = 0; y < PH; y++) {
            for (int x = 0; x < PW; x++) {
                small.setPixelRGBA(x, y, full.getPixelRGBA(ox + x * cw / PW, oy + y * ch / PH) | 0xFF000000);
            }
        }
        return small;
    }

    // ------------------------------------------------------------- aparat
    private static int captureTicks = -1;
    private static Screen returnTo;
    private static Consumer<String> callback;
    private static boolean oldHideGui;

    /** Chowa ekran na chwilę, robi zdjęcie świata i wraca. */
    public static void capture(Screen back, Consumer<String> onDone) {
        Minecraft mc = Minecraft.getInstance();
        returnTo = back;
        callback = onDone;
        oldHideGui = mc.options.hideGui;
        mc.options.hideGui = true;
        mc.setScreen(null);
        captureTicks = 4;
    }

    @SubscribeEvent
    public static void onTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END || captureTicks < 0) return;
        if (--captureTicks > 0) return;
        captureTicks = -1;
        Minecraft mc = Minecraft.getInstance();
        String saved = null;
        try (NativeImage full = Screenshot.takeScreenshot(mc.getMainRenderTarget())) {
            NativeImage small = shrink(full);
            saved = saveImage(small);
            small.close();
        } catch (Exception ignored) {}
        mc.options.hideGui = oldHideGui;
        if (mc.player != null) mc.player.playSound(net.minecraft.sounds.SoundEvents.UI_CARTOGRAPHY_TABLE_TAKE_RESULT, 1.0F, 1.5F);
        if (returnTo != null) mc.setScreen(returnTo);
        if (callback != null) callback.accept(saved);
        returnTo = null;
        callback = null;
    }

    // ------------------------------------------------------------- obrazki botów
    private static int abgr(int rgb) {
        int r = (rgb >> 16) & 255, g = (rgb >> 8) & 255, b = rgb & 255;
        return 0xFF000000 | (b << 16) | (g << 8) | r;
    }

    public static ResourceLocation botImage(long seed, int type) {
        String key = "bot:" + seed + ":" + type;
        if (CACHE.containsKey(key)) return CACHE.get(key);
        int W = 160, H = 90;
        int[] px = new int[W * H];
        Random r = new Random(seed);
        paintScene(px, W, H, type % 10, r);
        NativeImage img = new NativeImage(W, H, false);
        for (int y = 0; y < H; y++) for (int x = 0; x < W; x++) img.setPixelRGBA(x, y, abgr(px[y * W + x]));
        return register("bot_" + (counter++), img, key);
    }

    private static void rect(int[] px, int W, int H, int x0, int y0, int x1, int y1, int c) {
        for (int y = Math.max(0, y0); y < Math.min(H, y1); y++)
            for (int x = Math.max(0, x0); x < Math.min(W, x1); x++) px[y * W + x] = c;
    }

    private static void circle(int[] px, int W, int H, int cx, int cy, int rad, int c) {
        for (int y = cy - rad; y <= cy + rad; y++)
            for (int x = cx - rad; x <= cx + rad; x++)
                if (x >= 0 && y >= 0 && x < W && y < H && (x - cx) * (x - cx) + (y - cy) * (y - cy) <= rad * rad) px[y * W + x] = c;
    }

    private static int grad(int a, int b, float t) {
        t = Math.max(0, Math.min(1, t));
        int ar = (a >> 16) & 255, ag = (a >> 8) & 255, ab = a & 255;
        int br = (b >> 16) & 255, bg = (b >> 8) & 255, bb = b & 255;
        return ((int) (ar + (br - ar) * t) << 16) | ((int) (ag + (bg - ag) * t) << 8) | (int) (ab + (bb - ab) * t);
    }

    private static void sky(int[] px, int W, int H, int top, int bottom, int until) {
        for (int y = 0; y < until; y++) rect(px, W, H, 0, y, W, y + 1, grad(top, bottom, y / (float) until));
    }

    private static void paintScene(int[] px, int W, int H, int type, Random r) {
        switch (type) {
            case 0 -> { // zachód słońca nad morzem
                sky(px, W, H, 0x2B1B5A, 0xFF8A3D, 55);
                circle(px, W, H, 80 + r.nextInt(30) - 15, 52, 16, 0xFFD45A);
                for (int y = 55; y < H; y++) rect(px, W, H, 0, y, W, y + 1, grad(0xE0603A, 0x1B2B5A, (y - 55) / 35f));
                for (int i = 0; i < 25; i++) { int y = 57 + r.nextInt(30); int x = r.nextInt(W); rect(px, W, H, x, y, x + 6 + r.nextInt(10), y + 1, 0xFFB070); }
            }
            case 1 -> { // góry
                sky(px, W, H, 0x5AA0E8, 0xCFE8FF, H);
                for (int m = 0; m < 4; m++) {
                    int cx = r.nextInt(W), h = 35 + r.nextInt(30), base = H, col = grad(0x4A5A70, 0x2A3445, m / 4f);
                    for (int y = base - h; y < base; y++) {
                        int half = (y - (base - h)) * 3 / 2;
                        rect(px, W, H, cx - half, y, cx + half, y + 1, (y < base - h + 10) ? 0xF2F6FF : col);
                    }
                }
                rect(px, W, H, 0, 78, W, H, 0x3C8A3A);
            }
            case 2 -> { // las
                sky(px, W, H, 0x88C8F0, 0xE8F6FF, 60);
                rect(px, W, H, 0, 60, W, H, 0x3E8E3A);
                for (int i = 0; i < 14; i++) {
                    int x = r.nextInt(W), y = 40 + r.nextInt(30);
                    rect(px, W, H, x - 1, y, x + 2, y + 18, 0x6B4423);
                    for (int k = 0; k < 4; k++) rect(px, W, H, x - 8 + k * 2, y - k * 5, x + 9 - k * 2, y - k * 5 + 6, grad(0x1E6B2A, 0x2E8B3A, k / 4f));
                }
            }
            case 3 -> { // miasto nocą
                sky(px, W, H, 0x0A0A25, 0x2A1A50, H);
                for (int i = 0; i < 40; i++) rect(px, W, H, r.nextInt(W), r.nextInt(40), 0, 0, 0);
                for (int i = 0; i < 30; i++) { int x = r.nextInt(W), y = r.nextInt(40); px[y * W + x] = 0xFFFFFF; }
                circle(px, W, H, 130, 15, 7, 0xF0F0D0);
                int x = 0;
                while (x < W) {
                    int bw = 12 + r.nextInt(16), bh = 25 + r.nextInt(50);
                    rect(px, W, H, x, H - bh, x + bw, H, 0x15152A);
                    for (int wy = H - bh + 3; wy < H - 3; wy += 5)
                        for (int wx = x + 2; wx < x + bw - 2; wx += 4)
                            if (r.nextInt(3) > 0) rect(px, W, H, wx, wy, wx + 2, wy + 2, r.nextBoolean() ? 0xFFE08A : 0xFFF4C0);
                    x += bw + 1;
                }
            }
            case 4 -> { // pizza
                rect(px, W, H, 0, 0, W, H, 0x8B5A3C);
                for (int i = 0; i < 200; i++) { int xx = r.nextInt(W), yy = r.nextInt(H); px[yy * W + xx] = 0x7A4E33; }
                circle(px, W, H, 80, 45, 38, 0xD9A050);
                circle(px, W, H, 80, 45, 33, 0xD8442A);
                circle(px, W, H, 80, 45, 31, 0xF2D36B);
                for (int i = 0; i < 12; i++) circle(px, W, H, 80 + r.nextInt(44) - 22, 45 + r.nextInt(44) - 22, 4, 0xB0281E);
                for (int i = 0; i < 10; i++) circle(px, W, H, 80 + r.nextInt(44) - 22, 45 + r.nextInt(44) - 22, 2, 0x2F7A2F);
            }
            case 5 -> { // kot
                rect(px, W, H, 0, 0, W, H, grad(0xF7D9E8, 0xE8C8F0, r.nextFloat()));
                int fur = r.nextBoolean() ? 0xE8923A : 0x8A8A8A;
                circle(px, W, H, 80, 52, 30, fur);
                for (int s = -1; s <= 1; s += 2) for (int y = 0; y < 18; y++) rect(px, W, H, 80 + s * 22 - (18 - y) / 2 * (s > 0 ? 0 : 1), 18 + y, 80 + s * 22 + (18 - y) / 2 * (s > 0 ? 1 : 0) + 1, 19 + y, fur);
                circle(px, W, H, 69, 48, 5, 0xFFFFFF); circle(px, W, H, 91, 48, 5, 0xFFFFFF);
                circle(px, W, H, 69, 49, 3, 0x2A9A3A); circle(px, W, H, 91, 49, 3, 0x2A9A3A);
                circle(px, W, H, 80, 60, 3, 0xF08AA0);
                rect(px, W, H, 52, 60, 70, 61, 0x333333); rect(px, W, H, 90, 60, 108, 61, 0x333333);
            }
            case 6 -> { // plaża z palmą
                sky(px, W, H, 0x3AA8F0, 0xBFE9FF, 50);
                rect(px, W, H, 0, 50, W, 65, 0x2FA7C9);
                rect(px, W, H, 0, 65, W, H, 0xF1D9A0);
                circle(px, W, H, 135, 15, 9, 0xFFE860);
                for (int y = 30; y < 75; y++) rect(px, W, H, 40 + (75 - y) / 6, y, 44 + (75 - y) / 6, y + 1, 0x8B5A2B);
                for (int k = -3; k <= 3; k++) for (int t = 0; t < 22; t++) rect(px, W, H, 47 + k * t / 3, 30 + Math.abs(k) * t / 6 - t / 4 + t / 3, 47 + k * t / 3 + 3, 32 + Math.abs(k) * t / 6 - t / 4 + t / 3, 0x2E8B3A);
            }
            case 7 -> { // blokowy świat
                sky(px, W, H, 0x7EB8FF, 0xC8E2FF, H);
                for (int bx = 0; bx < W; bx += 10) {
                    int top = 45 + r.nextInt(3) * 10;
                    for (int by = top; by < H; by += 10) {
                        int c = by == top ? 0x5DAA3A : (by < top + 30 ? 0x8B5E3C : 0x7D7D7D);
                        rect(px, W, H, bx, by, bx + 10, by + 10, c);
                        rect(px, W, H, bx, by, bx + 10, by + 1, grad(c, 0xFFFFFF, 0.2f));
                    }
                }
                rect(px, W, H, 30, 20, 60, 26, 0xFFFFFF); rect(px, W, H, 100, 12, 125, 18, 0xFFFFFF);
            }
            case 8 -> { // kosmos
                rect(px, W, H, 0, 0, W, H, 0x05030F);
                for (int i = 0; i < 120; i++) { int xx = r.nextInt(W), yy = r.nextInt(H); px[yy * W + xx] = r.nextBoolean() ? 0xFFFFFF : 0x9AB0FF; }
                for (int i = 0; i < 300; i++) { int xx = 20 + r.nextInt(120), yy = 30 + r.nextInt(30) + (xx - 80) / 4; if (yy >= 0 && yy < H) px[yy * W + xx] = grad(0x7A3AD0, 0xF07AD0, r.nextFloat()); }
                circle(px, W, H, 120, 65, 16, 0xD08A3A);
                rect(px, W, H, 96, 64, 144, 66, 0xE8C88A);
            }
            default -> { // tort urodzinowy
                rect(px, W, H, 0, 0, W, H, 0xFDE7F0);
                rect(px, W, H, 45, 45, 115, 80, 0xF6B8D0);
                rect(px, W, H, 45, 45, 115, 50, 0xFFFFFF);
                rect(px, W, H, 55, 25, 105, 45, 0xF9D0E0);
                rect(px, W, H, 55, 25, 105, 29, 0xFFFFFF);
                for (int i = 0; i < 5; i++) { rect(px, W, H, 62 + i * 9, 13, 64 + i * 9, 25, 0x5AB0F0); circle(px, W, H, 63 + i * 9, 10, 2, 0xFFB020); }
                for (int i = 0; i < 20; i++) { int xx = 47 + r.nextInt(66), yy = 52 + r.nextInt(26); px[yy * W + xx] = new int[]{0xE03A3A, 0x3A8AE0, 0xF0D020}[r.nextInt(3)]; }
            }
        }
    }
}
