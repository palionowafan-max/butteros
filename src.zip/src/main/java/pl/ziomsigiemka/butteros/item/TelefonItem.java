package pl.ziomsigiemka.butteros.item;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import pl.ziomsigiemka.butteros.network.OpenDevicePacket;

import javax.annotation.Nullable;
import java.util.List;

/** Telefon z ButterOS - PPM żeby go odblokować. */
public class TelefonItem extends Item {
    public TelefonItem(Properties props) { super(props); }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        if (!level.isClientSide && player instanceof ServerPlayer sp) OpenDevicePacket.sendTo(sp, OpenDevicePacket.PHONE);
        return InteractionResultHolder.sidedSuccess(player.getItemInHand(hand), level.isClientSide);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tip, TooltipFlag flag) {
        tip.add(Component.literal("Telefon z systemem ButterOS").withStyle(ChatFormatting.GOLD));
        tip.add(Component.literal("PPM = odblokuj telefon").withStyle(ChatFormatting.GRAY));
    }
}
