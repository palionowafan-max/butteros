package pl.ziomsigiemka.butteros.item;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import javax.annotation.Nullable;
import java.util.List;

/** Część komputera - PPM na obudowę żeby ją włożyć. */
public class PartItem extends Item {
    public final int slot;
    public final String partName;

    public PartItem(Properties props, int slot, String partName) {
        super(props);
        this.slot = slot;
        this.partName = partName;
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tip, TooltipFlag flag) {
        tip.add(Component.literal("Część komputera (1 z 5)").withStyle(ChatFormatting.GRAY));
        tip.add(Component.literal("PPM na obudowę komputera = włóż").withStyle(ChatFormatting.YELLOW));
    }
}
