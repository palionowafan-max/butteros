package pl.ziomsigiemka.butteros;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;
import pl.ziomsigiemka.butteros.block.ObudowaBlockEntity;
import pl.ziomsigiemka.butteros.network.OpenDevicePacket;

import java.util.ArrayList;
import java.util.List;

/** Sprawdza, czy komputer jest kompletny: obudowa z 5 częściami + monitor + klawiatura, max 6 kratek od siebie. */
public class Computer {
    public static final int RANGE = 6;
    private static final String[] NAMES = {"Procesor", "Karta graficzna", "RAM", "Dysk", "Zasilacz"};

    public static String missingParts(ObudowaBlockEntity be) {
        List<String> m = new ArrayList<>();
        for (int i = 0; i < 5; i++) if (!be.has(i)) m.add(NAMES[i]);
        return String.join(", ", m);
    }

    private static int dist(BlockPos a, BlockPos b) {
        return Math.max(Math.abs(a.getX() - b.getX()), Math.max(Math.abs(a.getY() - b.getY()), Math.abs(a.getZ() - b.getZ())));
    }

    public static void tryOpen(Level level, BlockPos from, ServerPlayer player) {
        BlockPos monitor = null, keyboard = null, caseFull = null, caseAny = null;
        for (BlockPos p : BlockPos.betweenClosed(from.offset(-RANGE, -RANGE, -RANGE), from.offset(RANGE, RANGE, RANGE))) {
            if (monitor == null && level.getBlockState(p).is(ModRegistry.MONITOR.get())) monitor = p.immutable();
            else if (keyboard == null && level.getBlockState(p).is(ModRegistry.KLAWIATURA.get())) keyboard = p.immutable();
            else if (level.getBlockEntity(p) instanceof ObudowaBlockEntity be) {
                if (caseAny == null) caseAny = p.immutable();
                if (caseFull == null && be.complete()) caseFull = p.immutable();
            }
        }

        List<String> missing = new ArrayList<>();
        if (monitor == null) missing.add("monitora");
        if (keyboard == null) missing.add("klawiatury");
        if (caseAny == null) missing.add("obudowy komputera");
        if (!missing.isEmpty()) {
            player.displayClientMessage(Component.literal("§cBrakuje " + String.join(", ", missing) + " (max " + RANGE + " kratek od siebie)."), false);
            return;
        }
        if (caseFull == null) {
            ObudowaBlockEntity be = (ObudowaBlockEntity) level.getBlockEntity(caseAny);
            player.displayClientMessage(Component.literal("§cKomputer nie jest złożony! Brakuje części: " + missingParts(be)), false);
            return;
        }
        if (dist(monitor, keyboard) > RANGE || dist(monitor, caseFull) > RANGE || dist(keyboard, caseFull) > RANGE) {
            player.displayClientMessage(Component.literal("§cMonitor, klawiatura i obudowa muszą być max " + RANGE + " kratek od siebie!"), false);
            return;
        }
        OpenDevicePacket.sendTo(player, OpenDevicePacket.PC);
    }
}
