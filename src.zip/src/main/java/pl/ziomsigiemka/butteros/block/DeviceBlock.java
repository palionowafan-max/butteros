package pl.ziomsigiemka.butteros.block;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;
import pl.ziomsigiemka.butteros.Computer;
import pl.ziomsigiemka.butteros.network.OpenDevicePacket;

/** Monitor, klawiatura i telewizor - obracają się w stronę gracza. */
public class DeviceBlock extends HorizontalDirectionalBlock {
    public enum Kind { MONITOR, KLAWIATURA, TELEWIZOR }

    private final Kind kind;
    private final VoxelShape shapeNS, shapeEW;

    public DeviceBlock(Properties props, Kind kind) {
        super(props);
        this.kind = kind;
        registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.NORTH));
        switch (kind) {
            case MONITOR -> { shapeNS = Block.box(0, 0, 6, 16, 14, 10); shapeEW = Block.box(6, 0, 0, 10, 14, 16); }
            case KLAWIATURA -> { shapeNS = Block.box(1, 0, 4, 15, 2, 12); shapeEW = Block.box(4, 0, 1, 12, 2, 15); }
            default -> { shapeNS = Block.box(0, 0, 6, 16, 16, 10); shapeEW = Block.box(6, 0, 0, 10, 16, 16); }
        }
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FACING);
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext ctx) {
        return defaultBlockState().setValue(FACING, ctx.getHorizontalDirection().getOpposite());
    }

    @Override
    @SuppressWarnings("deprecation")
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
        return state.getValue(FACING).getAxis() == Direction.Axis.Z ? shapeNS : shapeEW;
    }

    @Override
    @SuppressWarnings("deprecation")
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        if (level.isClientSide) return InteractionResult.SUCCESS;
        if (player instanceof ServerPlayer sp) {
            if (kind == Kind.TELEWIZOR) OpenDevicePacket.sendTo(sp, OpenDevicePacket.TV);
            else Computer.tryOpen(level, pos, sp);
        }
        return InteractionResult.CONSUME;
    }
}
