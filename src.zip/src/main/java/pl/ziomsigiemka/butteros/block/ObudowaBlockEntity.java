package pl.ziomsigiemka.butteros.block;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import pl.ziomsigiemka.butteros.ModRegistry;

/** Obudowa komputera - pamięta, które z 5 części są włożone. */
public class ObudowaBlockEntity extends BlockEntity {
    public static final int ALL = 0b11111;
    private int parts = 0;

    public ObudowaBlockEntity(BlockPos pos, BlockState state) {
        super(ModRegistry.OBUDOWA_BE.get(), pos, state);
    }

    public boolean has(int slot) { return (parts & (1 << slot)) != 0; }
    public boolean complete() { return parts == ALL; }
    public int count() { return Integer.bitCount(parts); }

    public void add(int slot) {
        parts |= (1 << slot);
        setChanged();
    }

    public int takeAll() {
        int p = parts;
        parts = 0;
        setChanged();
        return p;
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        tag.putInt("Parts", parts);
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        parts = tag.getInt("Parts");
    }
}
