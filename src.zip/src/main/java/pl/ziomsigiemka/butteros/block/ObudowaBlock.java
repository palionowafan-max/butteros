package pl.ziomsigiemka.butteros.block;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.Containers;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.phys.BlockHitResult;
import pl.ziomsigiemka.butteros.Computer;
import pl.ziomsigiemka.butteros.ModRegistry;
import pl.ziomsigiemka.butteros.item.PartItem;

/** Obudowa komputera: PPM częścią = włóż ją. Potrzeba 5 części. */
public class ObudowaBlock extends BaseEntityBlock {
    public static final DirectionProperty FACING = HorizontalDirectionalBlock.FACING;

    public ObudowaBlock(Properties props) {
        super(props);
        registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.NORTH));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FACING);
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext ctx) {
        return defaultBlockState().setValue(FACING, ctx.getHorizontalDirection().getOpposite());
    }

    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) { return new ObudowaBlockEntity(pos, state); }

    @Override
    @SuppressWarnings("deprecation")
    public RenderShape getRenderShape(BlockState state) { return RenderShape.MODEL; }

    @Override
    @SuppressWarnings("deprecation")
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        if (level.isClientSide) return InteractionResult.SUCCESS;
        if (!(level.getBlockEntity(pos) instanceof ObudowaBlockEntity be)) return InteractionResult.PASS;
        ItemStack stack = player.getItemInHand(hand);

        if (stack.getItem() instanceof PartItem part) {
            if (be.has(part.slot)) {
                player.displayClientMessage(Component.literal("§eTa część już jest w komputerze!"), true);
            } else {
                be.add(part.slot);
                if (!player.getAbilities().instabuild) stack.shrink(1);
                level.playSound(null, pos, SoundEvents.IRON_TRAPDOOR_CLOSE, SoundSource.BLOCKS, 0.8F, 1.4F);
                if (be.complete()) {
                    player.displayClientMessage(Component.literal("§aKomputer złożony! (5/5) Postaw monitor i klawiaturę max 6 kratek od niego."), false);
                } else {
                    player.displayClientMessage(Component.literal("§bWłożono: " + part.partName + " (" + be.count() + "/5). Brakuje: " + Computer.missingParts(be)), true);
                }
            }
            return InteractionResult.CONSUME;
        }

        if (!be.complete()) {
            player.displayClientMessage(Component.literal("§eKomputer: " + be.count() + "/5 części. Brakuje: " + Computer.missingParts(be)), true);
            return InteractionResult.CONSUME;
        }
        if (player instanceof ServerPlayer sp) Computer.tryOpen(level, pos, sp);
        return InteractionResult.CONSUME;
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean moved) {
        if (!state.is(newState.getBlock()) && level.getBlockEntity(pos) instanceof ObudowaBlockEntity be) {
            int p = be.takeAll();
            for (int i = 0; i < 5; i++) {
                if ((p & (1 << i)) != 0) {
                    Containers.dropItemStack(level, pos.getX() + 0.5D, pos.getY() + 0.5D, pos.getZ() + 0.5D, new ItemStack(ModRegistry.partItem(i)));
                }
            }
        }
        super.onRemove(state, level, pos, newState, moved);
    }
}
