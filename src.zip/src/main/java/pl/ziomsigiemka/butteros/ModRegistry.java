package pl.ziomsigiemka.butteros;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import pl.ziomsigiemka.butteros.block.DeviceBlock;
import pl.ziomsigiemka.butteros.block.ObudowaBlock;
import pl.ziomsigiemka.butteros.block.ObudowaBlockEntity;
import pl.ziomsigiemka.butteros.item.PartItem;
import pl.ziomsigiemka.butteros.item.TelefonItem;

public class ModRegistry {
    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, ButterOSMod.MODID);
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, ButterOSMod.MODID);
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES = DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, ButterOSMod.MODID);
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, ButterOSMod.MODID);

    private static BlockBehaviour.Properties tech() {
        return BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_BLACK).strength(1.5F).sound(SoundType.METAL).noOcclusion();
    }

    // BLOKI
    public static final RegistryObject<Block> OBUDOWA = BLOCKS.register("obudowa", () -> new ObudowaBlock(tech()));
    public static final RegistryObject<Block> MONITOR = BLOCKS.register("monitor", () -> new DeviceBlock(tech(), DeviceBlock.Kind.MONITOR));
    public static final RegistryObject<Block> KLAWIATURA = BLOCKS.register("klawiatura", () -> new DeviceBlock(tech(), DeviceBlock.Kind.KLAWIATURA));
    public static final RegistryObject<Block> TELEWIZOR = BLOCKS.register("telewizor", () -> new DeviceBlock(tech(), DeviceBlock.Kind.TELEWIZOR));

    public static final RegistryObject<BlockEntityType<ObudowaBlockEntity>> OBUDOWA_BE = BLOCK_ENTITIES.register("obudowa",
            () -> BlockEntityType.Builder.of(ObudowaBlockEntity::new, OBUDOWA.get()).build(null));

    // ITEMY
    public static final RegistryObject<Item> OBUDOWA_ITEM = ITEMS.register("obudowa", () -> new BlockItem(OBUDOWA.get(), new Item.Properties()));
    public static final RegistryObject<Item> MONITOR_ITEM = ITEMS.register("monitor", () -> new BlockItem(MONITOR.get(), new Item.Properties()));
    public static final RegistryObject<Item> KLAWIATURA_ITEM = ITEMS.register("klawiatura", () -> new BlockItem(KLAWIATURA.get(), new Item.Properties()));
    public static final RegistryObject<Item> TELEWIZOR_ITEM = ITEMS.register("telewizor", () -> new BlockItem(TELEWIZOR.get(), new Item.Properties()));

    public static final RegistryObject<Item> PROCESOR = ITEMS.register("procesor", () -> new PartItem(new Item.Properties(), 0, "Procesor"));
    public static final RegistryObject<Item> KARTA_GRAFICZNA = ITEMS.register("karta_graficzna", () -> new PartItem(new Item.Properties(), 1, "Karta graficzna"));
    public static final RegistryObject<Item> RAM = ITEMS.register("ram", () -> new PartItem(new Item.Properties(), 2, "Pamięć RAM"));
    public static final RegistryObject<Item> DYSK = ITEMS.register("dysk", () -> new PartItem(new Item.Properties(), 3, "Dysk SSD"));
    public static final RegistryObject<Item> ZASILACZ = ITEMS.register("zasilacz", () -> new PartItem(new Item.Properties(), 4, "Zasilacz"));

    public static final RegistryObject<Item> TELEFON = ITEMS.register("telefon", () -> new TelefonItem(new Item.Properties().stacksTo(1)));

    public static final RegistryObject<CreativeModeTab> TAB = TABS.register("butteros_tab", () -> CreativeModeTab.builder()
            .title(Component.literal("ButterOS"))
            .icon(() -> new ItemStack(MONITOR_ITEM.get()))
            .displayItems((params, out) -> {
                for (RegistryObject<Item> item : ITEMS.getEntries()) out.accept(item.get());
            })
            .build());

    public static Item partItem(int slot) {
        return switch (slot) {
            case 0 -> PROCESOR.get();
            case 1 -> KARTA_GRAFICZNA.get();
            case 2 -> RAM.get();
            case 3 -> DYSK.get();
            default -> ZASILACZ.get();
        };
    }

    public static void register(IEventBus bus) {
        BLOCKS.register(bus);
        ITEMS.register(bus);
        BLOCK_ENTITIES.register(bus);
        TABS.register(bus);
    }
}
