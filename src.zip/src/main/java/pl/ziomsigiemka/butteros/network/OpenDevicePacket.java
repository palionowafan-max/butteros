package pl.ziomsigiemka.butteros.network;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.storage.LevelData;
import net.minecraft.world.level.storage.ServerLevelData;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.PacketDistributor;
import pl.ziomsigiemka.butteros.client.ClientHooks;

import java.util.function.Supplier;

/** Serwer -> klient: "otwórz ButterOS" + dane pogody z gry. */
public class OpenDevicePacket {
    public static final int PC = 0, PHONE = 1, TV = 2;

    public final int device;
    public final boolean raining, thundering;
    public final int clearTime, rainTime, thunderTime;
    public final long dayTime;

    public OpenDevicePacket(int device, boolean raining, boolean thundering, int clearTime, int rainTime, int thunderTime, long dayTime) {
        this.device = device;
        this.raining = raining;
        this.thundering = thundering;
        this.clearTime = clearTime;
        this.rainTime = rainTime;
        this.thunderTime = thunderTime;
        this.dayTime = dayTime;
    }

    public OpenDevicePacket(FriendlyByteBuf buf) {
        this(buf.readVarInt(), buf.readBoolean(), buf.readBoolean(), buf.readVarInt(), buf.readVarInt(), buf.readVarInt(), buf.readLong());
    }

    public void encode(FriendlyByteBuf buf) {
        buf.writeVarInt(device);
        buf.writeBoolean(raining);
        buf.writeBoolean(thundering);
        buf.writeVarInt(clearTime);
        buf.writeVarInt(rainTime);
        buf.writeVarInt(thunderTime);
        buf.writeLong(dayTime);
    }

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientHooks.openDevice(this));
    }

    public static void sendTo(ServerPlayer player, int device) {
        ServerLevel level = player.serverLevel();
        LevelData data = level.getLevelData();
        int clear = 0, rain = 0, thunder = 0;
        if (data instanceof ServerLevelData sd) {
            clear = sd.getClearWeatherTime();
            rain = sd.getRainTime();
            thunder = sd.getThunderTime();
        }
        OpenDevicePacket pkt = new OpenDevicePacket(device, level.isRaining(), level.isThundering(), clear, rain, thunder, level.getDayTime());
        ModNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), pkt);
    }
}
