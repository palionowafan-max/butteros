package pl.ziomsigiemka.butteros.network;

import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;
import pl.ziomsigiemka.butteros.ButterOSMod;

public class ModNetwork {
    private static final String VERSION = "1";
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(ButterOSMod.MODID, "main"), () -> VERSION, VERSION::equals, VERSION::equals);

    public static void register() {
        CHANNEL.messageBuilder(OpenDevicePacket.class, 0, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(OpenDevicePacket::encode)
                .decoder(OpenDevicePacket::new)
                .consumerMainThread(OpenDevicePacket::handle)
                .add();
    }
}
